.. highlight:: shell

============
Installation
============


Stable release
--------------

TODO

From sources
------------

The sources for HMS Predictive Modeling can be downloaded from the `Azure DevOps repo`_.

You can clone the repository:

.. code-block:: console

    $ git clone https://dev.azure.com/analyticalsoftware-vis/00773-003_KF_ML/_git/hmsPM_Python

Once you have a copy of the source, you can install it with:

.. code-block:: console

    $ python setup.py install


.. _Azure DevOps repo: https://dev.azure.com/analyticalsoftware-vis/00773-003_KF_ML/_git/hmsPM_Python
.. _tarball: https://TODO_FIX-URL/hmsPM/tarball/master
