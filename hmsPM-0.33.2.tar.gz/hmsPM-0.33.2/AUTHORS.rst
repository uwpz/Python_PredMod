=======
Credits
=======


Maintainer
------------

* Arno Becker <arno.becker@analytical-software.de>


Contributors
------------

* Uwe Pritzsche <uwe.pritzsche@analytical-software.de>
* Lena Mangold <lena.mangold@analytical-software.de>
