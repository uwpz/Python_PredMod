"""Partial dependency calculators"""

from typing import List, Optional, Union, Dict

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from hmsPM.preprocessing.convert import MatrixConverter
from hmsPM.calculation.scale import scale_predictions
from hmsPM.datatypes import (
    TargetType,
)


class PartialDependencyCalculator:
    """
    Creates a dataframe with partial dependencies for given features.

    :param n_bins: Number of bins used to create grid for numerical features
    :param n_jobs: Maximum number of concurrently running jobs for parallel processing
    """
    def __init__(self,
                 n_bins: int = 10,
                 n_jobs: int = 4):
        self.n_bins = n_bins
        self.n_jobs = n_jobs

        self.matrix_converter = MatrixConverter()

    def calculate(self,
                  fit: object,
                  X_test: pd.DataFrame,
                  X_train: Optional[Union[pd.DataFrame, np.ndarray]],
                  b_sample: Optional[np.ndarray] = None,
                  b_all: Optional[np.ndarray] = None,
                  feature_names: Optional[Union[str, List[str]]] = None) -> pd.DataFrame:
        """
        Calculates partial dependencies for each feature.

        By default, partial dependencies are calculated for all features in :attr:`X_test`. Alternatively, the user
        can specify the feature names for which partial dependencies should be plotted in using the
        :attr:`feature_names` parameter.

        :param fit: An estimator that has already been fitted
        :param X_test: Pandas dataframe for which partial dependencies should be calculated
        :param X_train: Pandas dataframe or numpy array with original data used for training
        :param b_sample: Numpy array with proportions of target class in undersampled data
        :param b_all: Numpy array with proportions of target class in original data
        :param feature_names: Feature or list of feature for which partial dependencies should be calculated;
            default = ``None``
        :return: Dataframe with partial dependencies
        """
        target_type = self._get_target_type(fit=fit)

        self.matrix_converter.fit(X_train)

        column_names_num = self.matrix_converter.column_names_num
        column_names_cat = self.matrix_converter.column_names_cat

        feature_values = self._prepare_feature_values(X_test=X_test,
                                                      column_names_cat=column_names_cat,
                                                      column_names_num=column_names_num)

        target_labels = self._create_target_labels(fit=fit, target_type=target_type)

        feature_names = self._get_feature_names(column_names_cat=column_names_cat,
                                                column_names_num=column_names_num,
                                                feature_names=feature_names)

        # Create mean predictions for each feature in parallel
        pd_by_feature = (Parallel(n_jobs = self.n_jobs, max_nbytes = '100M')
                         (delayed(self._calculate_mean_predictions_by_feature)
                          (feature_name=feature_name,
                           feature_values=feature_values[feature_name],
                           X_test=X_test,
                           fit=fit,
                           target_type=target_type,
                           target_labels=target_labels,
                           b_all=b_all,
                           b_sample=b_sample)
                          for feature_name in feature_names))
        df_pd = pd.concat(pd_by_feature)

        df_pd = df_pd.reset_index(drop = True)
        return df_pd

    def _calculate_mean_predictions_by_feature(self,
                                               feature_name: str,
                                               feature_values: List[Union[str, int, float]],
                                               X_test: pd.DataFrame,
                                               fit,
                                               target_type: TargetType,
                                               target_labels: Union[str, np.ndarray],
                                               b_sample: Optional[np.ndarray] = None,
                                               b_all: Optional[np.ndarray] = None
                                               ) -> pd.DataFrame:
        # set index for creation of partial dependency dataframes
        index: Optional[List[int]] = [0]
        if target_type == TargetType.multiclass:
            index = None

        df_pd_feature = pd.DataFrame()
        for feature_value in feature_values:
            X_test = X_test.copy()
            X_test[feature_name] = feature_value

            yhat_mean = self._calculate_mean_prediction(X_test=X_test,
                                                        fit=fit,
                                                        target_type=target_type,
                                                        b_sample=b_sample,
                                                        b_all=b_all)

            df_category = pd.DataFrame({"feature": feature_name, "value": str(feature_value),
                                        "target": target_labels, "yhat_mean": yhat_mean}, index = index)
            df_pd_feature = pd.concat([df_pd_feature,
                                       df_category])
        return df_pd_feature

    def _calculate_mean_prediction(self,
                                   fit,
                                   X_test: pd.DataFrame,
                                   target_type: TargetType,
                                   b_sample: Optional[np.ndarray] = None,
                                   b_all: Optional[np.ndarray] = None) -> Union[float, np.ndarray]:
        if target_type == TargetType.regression:
            y_hat = fit.predict(self.matrix_converter.transform(X_test))
            yhat_mean = np.mean(y_hat)
        else:
            y_hat = fit.predict_proba(self.matrix_converter.transform(X_test))
            if b_sample is not None:
                y_hat = scale_predictions(y_hat = y_hat, b_sample = b_sample, b_all = b_all)
            yhat_mean = np.mean(y_hat, axis = 0)
            if target_type == TargetType.classification:
                yhat_mean = yhat_mean[1]
        return yhat_mean

    @staticmethod
    def _create_target_labels(fit, target_type: TargetType) -> Union[str, np.ndarray]:
        target_labels = "target"
        if target_type == TargetType.multiclass:
            target_labels = fit.classes_
        return target_labels

    @staticmethod
    def _get_feature_names(column_names_cat: List[str],
                           column_names_num: List[str],
                           feature_names: Optional[Union[str, List[str]]] = None) -> List[str]:
        if feature_names is None:
            return column_names_cat + column_names_num
        if isinstance(feature_names, str):
            return [feature_names]
        return feature_names

    @staticmethod
    def _get_target_type(fit) -> TargetType:
        if hasattr(fit, 'classes_'):
            n_classes = len(fit.classes_)
            if n_classes == 2:
                return TargetType.classification
            return TargetType.multiclass
        return TargetType.regression

    def _prepare_feature_values(self,
                                X_test: pd.DataFrame,
                                column_names_cat: List[str],
                                column_names_num: List[str]) -> Dict[str, list]:
        """
        For all specified features this method creates a dictionary of values at which partial dependency will be
        calculated.

        For all numerical features in :attr:`column_names_num` this method calculates quantiles according to the
        number of bins which can be specified by the user using the :attr:`n_bins` parameter.

        For all categorical feature in :attr:`column_names_num` this extracts the unique classes.
        """
        quantiles = np.arange(0, 1.1, 1 / self.n_bins)
        quantiles_num_features = X_test[column_names_num].quantile(quantiles).to_dict(orient = "list")
        categories_cat_features = {x: X_test[x].unique().tolist() for x in column_names_cat}
        return dict(quantiles_num_features, **categories_cat_features)
