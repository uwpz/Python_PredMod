from abc import ABC
from typing import Union, Tuple

import pandas as pd

from hmsPM.datatypes import CorrelationType
from hmsPM.preprocessing import Imputer


class ICorrelationMatrixCalculator(ABC):

    def __init__(self,
                 corr_type: Union[CorrelationType, str],
                 cutoff: float = 0,
                 n_cluster: int = 5):
        self.cutoff = cutoff
        self.n_cluster = n_cluster
        self.corr_type = corr_type
        """
        :param corr_type: Correlation type
        :param cutoff: Cutoff threshold for features to be included in correlation plot; default = 0
        :param n_cluster: Number of clusters for reordering of correlation matrix; default = 5
        """

    def create_matrix(self, features: pd.DataFrame) -> Tuple[pd.DataFrame, CorrelationType]:
        raise NotImplementedError


class IUnivariateFeatureImportanceCalculator(ABC):

    def __init__(self,
                 n_bins: int = 10,
                 n_digits: int = 3,
                 imputer: Imputer = None):
        """
        :param n_bins: Number of bins
        :param n_digits: Number of digits to which variable importance is rounded
        :param imputer: Imputer for removing missing values
        """
        self.n_bins = n_bins
        self.n_digits = n_digits
        self.imputer = imputer

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        """
        Perform calculation of variable importances for each feature in features.

        :param feature: Pandas series with feature for which variable importance is calculated
        :param target: Pandas series of target variable
        :return: Pandas series with variable importances with an entry for the value of each feature in features
        """
        raise NotImplementedError
