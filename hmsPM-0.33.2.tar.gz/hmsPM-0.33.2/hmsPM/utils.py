"""Utilities"""

import warnings
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
from itertools import compress

import numpy as np
import pandas as pd

from hmsPM.datatypes import (
    FeatureScale,
    TargetType,
    InputDataType,
)


# Method ######################################################################


def call_method(o, name, *args, **kwargs):
    return getattr(o, name)(*args, **kwargs)


# Feature Scale utilities #####################################################


def detect_feature_scale(x: Union[pd.Series, np.ndarray]) -> FeatureScale:
    """
    Detect feature scale of input series (numerical or categorical)

    :param x: Series for which to detect feature type
    :return: FeatureScale.numerical or FeatureScale.categorical
    """

    if np.issubdtype(x.dtype, np.number):
        return FeatureScale.numerical
    else:
        return FeatureScale.categorical


def detect_feature_scales(features: pd.DataFrame) -> List[FeatureScale]:
    """
    Detect feature scales of all features in dataframe

    :param features: Pandas dataframe with features to be detected
    :return: List of feature scales with an entry for each feature in features
    """
    detected_feature_scales = [detect_feature_scale(feature) for _, feature in features.iteritems()]
    return detected_feature_scales


def get_column_names_by_scale(features: pd.DataFrame,
                              feature_scale: Union[FeatureScale, str]) -> List[str]:
    """
    Select all column names from a dataframe which have the scale of input feature_scale

    :param features: Pandas dataframe with features from which to select column names
    :param feature_scale: Feature scale to be selected
    :return: List with selected column names
    """
    feature_scale = FeatureScale(feature_scale)
    detected_feature_scales = detect_feature_scales(features)
    select_feature_idx = [detected_feature_scale == FeatureScale(feature_scale)
                          for detected_feature_scale in detected_feature_scales]
    column_names = list(features.columns)
    column_names = list(compress(column_names, select_feature_idx))
    return column_names


def select_features_by_scale(features: pd.DataFrame,
                             feature_scale: Union[FeatureScale, str]) -> pd.DataFrame:
    """
    Select all features from a dataframe which have the scale of input feature_scale

    :param features: Pandas dataframe with features from which to select
    :param feature_scale: Feature scale to be selected
    :return: Pandas dataframe with selected features
    """
    detected_feature_scales = detect_feature_scales(features)
    select_feature_idx = [detected_feature_scale == FeatureScale(feature_scale)
                          for detected_feature_scale in detected_feature_scales]
    selected_features = features.iloc[:, select_feature_idx]
    return selected_features


# Target Type utilities #######################################################


def detect_target_type(x: Union[pd.Series, np.ndarray]) -> TargetType:
    """
    Detect target type of input series (classification,
    multiclass classification, or regression)

    :param x: Series for which to detect target type
    :return: TargetType.classification, TargetType.multiclass, or TargetType.regression
    """
    count_unique_values = len(np.unique(x))

    if any(pd.isnull(x)):
        count_unique_values -= 1

    if count_unique_values == 1:
        raise ValueError("Target variable has zero variance.")

    if count_unique_values == 2:
        return TargetType.classification
    elif count_unique_values <= 10:
        return TargetType.multiclass
    else:
        return TargetType.regression


def check_target_type(target: pd.Series, target_type: Optional[Union[TargetType, str]] = None) -> TargetType:
    if target_type is None:
        target_type = detect_target_type(target)
    else:
        target_type = TargetType(target_type)
    return target_type


def check_multiclass_levels(target: pd.Series, target_type: Optional[Union[TargetType, str]] = None):
    detected_target_type = detect_target_type(target)
    if target_type is not None and TargetType(target_type) != detected_target_type:
        target_type = TargetType(target_type)
        target_type_combination = (detected_target_type, target_type)

        if target_type_combination == (TargetType.regression, TargetType.multiclass):
            if target.nunique() > 100:
                raise ValueError(f"Too many levels in target_type {target_type} to be used for plotting of "
                                 f"the detected target type {detected_target_type}")
            if target.nunique() > 10:
                warnings.warn("Number of levels higher than expected for plotting functionality; "
                              "may lead to style issues in plots.")


# Input Data utilities ########################################################


def detect_input_data_type(x: Union[pd.DataFrame, pd.Series, np.ndarray]) -> InputDataType:
    if isinstance(x, pd.DataFrame):
        input_type = InputDataType.pd_dataframe
    elif isinstance(x, np.ndarray):
        input_type = InputDataType.np_ndarray
    elif isinstance(x, pd.Series):
        input_type = InputDataType.pd_series
    else:
        raise TypeError(f"The data type {type(x)} is not supported. "
                        "Supported are pandas Series, pandas DataFrame, and numpy array.")
    return input_type


# Abstract catalogs ###########################################################

class TargetCatalog(ABC):
    """
    Abstract catalog class for three target type options (classification/multiclass/regression)

    This class provides a selection method which automatically calls the appropriate method from the catalog of methods
    for each target type.
    """

    def __init__(self):
        self._target_method_choices = {
            TargetType.classification: self._classification,
            TargetType.multiclass: self._multiclass,
            TargetType.regression: self._regression
        }

    def _select_case(self, target: pd.Series,
                     target_type: Optional[Union[TargetType, str]] = None):
        """Select suitable catalog method based on target type

        By default, the target type is detected automatically.
        The target type can be specified explicitly via the target_type parameter to specify the desired target
        type.
        """
        detected_target_type = detect_target_type(target)

        if target_type is None or TargetType(target_type) == detected_target_type:
            target_type = detected_target_type
        elif TargetType(target_type) != detected_target_type:
            target_type = TargetType(target_type)

            target_type_combination = (detected_target_type, target_type)
            if target_type_combination in [(TargetType.regression, TargetType.classification),
                                           (TargetType.multiclass, TargetType.classification)]:
                raise ValueError("The specified target_type {} cannot be used for the detected target type {}".
                                 format(target_type, detected_target_type))
            elif target_type_combination == (TargetType.classification, TargetType.multiclass):
                warnings.warn("Input target type 'multiclass' but only two classes detected; "
                              "consider removing target_type parameter")

        return self._target_method_choices[target_type]()

    @abstractmethod
    def _classification(self, **kwargs):
        """Method for classification target"""

    @abstractmethod
    def _multiclass(self, **kwargs):
        """Method for multiclass target"""

    @abstractmethod
    def _regression(self, **kwargs):
        """Method for regression target"""


class FeatureCatalog(ABC):
    """
    Abstract catalog class for both feature scale options (numerical/categorical)

    This class provides a selection method which automatically calls the appropriate method from the catalog of methods
    for each feature scale.
    """

    def __init__(self):
        self._feature_method_choices = {
            FeatureScale.numerical: self._numerical_feature,
            FeatureScale.categorical: self._categorical_feature,
        }

    def _select_case(self, features: pd.DataFrame,
                     feature_scale: Optional[Union[FeatureScale, str]] = None):
        """Select suitable catalog method based on feature scale

        By default, the feature scale is detected automatically.
        The feature scale can be specified explicitly via the feature_scale parameter to specify the desired feature
        scale when the features input contains both categorical and numerical features.
        """

        detected_feature_scales = set(detect_feature_scales(features))
        mixed_feature_scales = len(detected_feature_scales) > 1

        detected_feature_scale = detected_feature_scales.pop()
        final_feature_scale = detected_feature_scale

        if mixed_feature_scales:
            if feature_scale is None:
                raise ValueError("Input dataframe contains mixed feature scales. Specify feature_scale or input "
                                 "dataframe with only numerical or only categorical features.")
            final_feature_scale = FeatureScale(feature_scale)
        elif feature_scale is not None and FeatureScale(feature_scale) != detected_feature_scale:
            raise ValueError("Invalid feature_scale input for detected feature scale.")

        return self._feature_method_choices[final_feature_scale]()

    @abstractmethod
    def _categorical_feature(self, **kwargs):
        """Method for categorical features"""

    @abstractmethod
    def _numerical_feature(self, **kwargs):
        """Method for categorical features"""


class FeatureTargetCatalog(ABC):
    """
    Abstract catalog class for all feature scale and target type combinations

    This class provides a selection method which automatically calls the appropriate method from the catalog of methods
    for each combination of feature scale and target type.
    """

    def __init__(self):
        self._feature_target_method_choices = {
            (FeatureScale.numerical, TargetType.classification): self._numerical_feature_classification_target,
            (FeatureScale.numerical, TargetType.multiclass): self._numerical_feature_multiclass_target,
            (FeatureScale.numerical, TargetType.regression): self._numerical_feature_regression_target,
            (FeatureScale.categorical, TargetType.classification): self._categorical_feature_classification_target,
            (FeatureScale.categorical, TargetType.multiclass): self._categorical_feature_multiclass_target,
            (FeatureScale.categorical, TargetType.regression): self._categorical_feature_regression_target,
        }

    def _select_case(self,
                     feature: pd.Series, target: pd.Series,
                     target_type: Optional[Union[TargetType, str]] = None):
        """Select suitable catalog method based on feature scale and target type

        By default, the feature scale and target type are detected automatically.
        The target type can be specified explicitly via the target_type parameter.
        """
        detected_target_type = detect_target_type(target)

        if target_type is None or TargetType(target_type) == detected_target_type:
            target_type = detected_target_type
        elif TargetType(target_type) != detected_target_type:
            target_type = TargetType(target_type)

            target_type_combination = (detected_target_type, target_type)
            if target_type_combination in [(TargetType.regression, TargetType.classification),
                                           (TargetType.multiclass, TargetType.classification)]:
                raise ValueError("The specified target_type {} cannot be used for the detected target type {}".
                                 format(target_type, detected_target_type))
            elif target_type_combination == (TargetType.classification, TargetType.multiclass):
                warnings.warn("Input target type 'multiclass' but only two classes detected; "
                              "consider removing target_type parameter")

        feature_target_combination = (detect_feature_scale(feature), target_type)
        if feature_target_combination not in self._feature_target_method_choices.keys():
            raise ValueError("Unsupported feature-target combination")
        return self._feature_target_method_choices[feature_target_combination]()

    @abstractmethod
    def _numerical_feature_classification_target(self, **kwargs):
        """Method for numerical feature and classification target"""

    @abstractmethod
    def _numerical_feature_multiclass_target(self, **kwargs):
        """Method for numerical feature and multiclass target"""

    @abstractmethod
    def _numerical_feature_regression_target(self, **kwargs):
        """Method for numerical feature and regression target"""

    @abstractmethod
    def _categorical_feature_classification_target(self, **kwargs):
        """Method for categorical feature and classification target"""

    @abstractmethod
    def _categorical_feature_multiclass_target(self, **kwargs):
        """Method for categorical feature and multiclass target"""

    @abstractmethod
    def _categorical_feature_regression_target(self, **kwargs):
        """Method for categorical feature and regression target"""


# Data validation utilities ###################################################


def get_fields(data: Union[Dict[str, Any], pd.DataFrame]) -> List[str]:
    if isinstance(data, dict):
        return list(data.keys())
    if isinstance(data, pd.DataFrame):
        return list(data.columns)
    raise TypeError(f'Unsupported data type {type(data)}')


def check_fields(data: Union[Dict[str, Any], pd.DataFrame],
                 fields: List[str],
                 var_name: str = ''):
    missing_fields = set(fields) - set(get_fields(data))
    if missing_fields:
        raise KeyError('Field'
                       + ('s ' if len(missing_fields) > 1 else ' ')
                       + "{} ".format(", ".join(sorted(missing_fields)))
                       + ('are ' if len(missing_fields) > 1 else 'is ')
                       + 'missing in '
                       + (f'{var_name} ' if var_name else '')
                       + f'({str(type(data))})')
