"""Performance plotting"""

from typing import Callable, Iterable, List, Optional, Union

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib.axes import Axes
from matplotlib import colors as mcolors
from matplotlib.colors import ListedColormap
import sklearn.metrics as skmetrics
from sklearn.calibration import calibration_curve
from sklearn.preprocessing import LabelEncoder

from hmsPM.plotting.base import (
    IROCCurve,
    IConfusionMatrix,
    IPredictionDistribution,
    ICalibration,
    IPrecisionRecall,
    IPrecision,
    IScatterPlot,
    IScatterPlotRegression,
    IMulticlassModelMetrics,
    IMulticlassBarplot,
    IPerformancePlotter,
)
from hmsPM.utils import (
    TargetCatalog,
)
from hmsPM.datatypes import (
    Dimension,
    AxisLimits,
    Colors,
    PerformanceMeasure,
    PlotGrids,
    PlotFunctionCall,
    PlotFunctionCalls,
)
from hmsPM.plotting.axes import (
    create_axes,
    create_inset_axes,
    set_inset_axis_limits,
    set_grid,
    remove_tick_labels_below_min_value,
)
from hmsPM.plotting.distribution import (
    BoxPlot,
)
from hmsPM.plotting.output import save_plot_grids_to_pdf
from hmsPM.plotting.grid import PlotGridBuilder
from hmsPM.preprocessing import QuantileBinner


# Mixin classes #######


class PerformancePlotterMixin:

    @staticmethod
    def _check_numerical_target(target: pd.Series):
        is_numerical_target = np.issubdtype(target.dtype, np.number)
        if not is_numerical_target:
            target = LabelEncoder().fit_transform(y = target)
        return target

    @staticmethod
    def _check_target_labels(target: pd.Series,
                             target_labels: Optional[List[str]] = None) -> List[str]:
        if target_labels is None:
            target_labels = sorted(list(map(str, target.unique())))
        return target_labels


# ROC curve classes #######


class ROCCurve(TargetCatalog, IROCCurve):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 target_labels: Optional[List[str]] = None,
                 show_grid: bool = True):
        TargetCatalog.__init__(self)
        IROCCurve.__init__(self,
                           colors = colors,
                           target_labels = target_labels,
                           show_grid = show_grid)

        self.roccurve_classification = ROCCurveClassification
        self.roccurve_multiclass = ROCCurveMulticlass

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()
        plotter = self._select_case(target = y)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    def _classification(self):
        return self.roccurve_classification(colors=self.colors,
                                            target_labels=self.target_labels,
                                            show_grid=self.show_grid)

    def _multiclass(self):
        return self.roccurve_multiclass(colors=self.colors,
                                        target_labels=self.target_labels,
                                        show_grid=self.show_grid)

    def _regression(self):
        raise TypeError("Cannot create roc curve for regression target.")


class ROCCurveClassification(PerformancePlotterMixin, IROCCurve):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        y = self._check_numerical_target(target=y)

        # calculate false positive rates, true positive rates and cutoff used for computation of these rates
        fpr, tpr, cutoff = skmetrics.roc_curve(y, y_hat[:, 1])
        roc_auc = skmetrics.roc_auc_score(y, y_hat[:, 1])

        ax.plot(fpr, tpr, color = self.colors[0])

        ax.set(title="ROC (AUC = {0:.2f})".format(roc_auc),
               xlabel=r"fpr: P($\^y$=1|$y$=0)",
               ylabel=r"tpr: P($\^y$=1|$y$=1)")
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


class ROCCurveMulticlass(PerformancePlotterMixin, IROCCurve):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        target_labels = self._check_target_labels(target=y, target_labels=self.target_labels)

        y = self._check_numerical_target(target=y)

        n_target_categories = y_hat.shape[1]

        aucs = np.array([round(skmetrics.roc_auc_score(np.where(y == i, 1, 0), y_hat[:, i]), 2)
                         for i in np.arange(n_target_categories)])

        roc_curve_data = self._calculate_roc_curve_data(n_target_categories=n_target_categories, y=y, y_hat=y_hat)

        for i in np.arange(n_target_categories):
            new_label = str(target_labels[i]) + " (" + str(aucs[i]) + ")"
            ax.plot(roc_curve_data[i]['fpr'], roc_curve_data[i]['tpr'], color = self.colors[i], label = new_label)

        # calculate mean and weighted auc for plot title
        mean_auc = np.average(aucs).round(3)
        weighted_auc = np.average(aucs, weights = np.array(np.unique(y, return_counts = True))[1, :]).round(3)

        ax.set(title="ROC\n" + r"($AUC_{mean}$ = " + str(mean_auc) +
                     r", $AUC_{weighted}$ = " + str(weighted_auc) + ")",
               xlabel=r"fpr: P($\^y$=1|$y$=0)",
               ylabel=r"tpr: P($\^y$=1|$y$=1)")
        ax.legend(title = r"Target ($AUC_{OvR}$)", loc = 'best')
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax

    @staticmethod
    def _calculate_roc_curve_data(n_target_categories: int, y: pd.Series, y_hat: pd.Series) -> dict:
        roc_curve_data = {}
        for i in np.arange(n_target_categories):
            y_bin = np.where(y == i, 1, 0)
            fpr, tpr, _ = skmetrics.roc_curve(y_bin, y_hat[:, i])
            roc_curve_data[i] = {'fpr': fpr,
                                 'tpr': tpr}
        return roc_curve_data


# Confusion matrix classes #######


class ConfusionMatrix(TargetCatalog, IConfusionMatrix):

    def __init__(self,
                 target_labels: Optional[List[str]] = None):
        TargetCatalog.__init__(self)
        IConfusionMatrix.__init__(self,
                                  target_labels = target_labels)

        self.confusion_matrix_classification = ConfusionMatrixClassification
        self.confusion_matrix_multiclass = ConfusionMatrixMulticlass

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()
        plotter = self._select_case(target = y)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    def _classification(self):
        return self.confusion_matrix_classification(target_labels=self.target_labels)

    def _multiclass(self):
        return self.confusion_matrix_multiclass(target_labels=self.target_labels)

    def _regression(self):
        raise TypeError("Cannot create confusion matrix for regression target.")


class ConfusionMatrixClassification(PerformancePlotterMixin, IConfusionMatrix):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        y = self._check_numerical_target(target=y)
        df_conf = pd.DataFrame(skmetrics.confusion_matrix(y, np.where(y_hat[:, 1] > 0.5, 1, 0)))
        acc_score = skmetrics.accuracy_score(y, np.where(y_hat[:, 1] > 0.5, 1, 0))
        sns.heatmap(df_conf, annot = True, fmt = ".5g", cmap = "Greys", ax = ax)

        ax.set(title="Confusion Matrix (Acc ={0: .2f})".format(acc_score),
               xlabel="Predicted label",
               ylabel="True label")
        return ax


class ConfusionMatrixMulticlass(PerformancePlotterMixin, IConfusionMatrix):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        y_pred = y_hat.argmax(axis = 1)
        freq_true = np.unique(y, return_counts = True)[1]
        freqpct_true = np.round(np.divide(freq_true, len(y)) * 100, 1)
        freq_pred = np.unique(y_pred, return_counts = True)[1]
        freqpct_pred = np.round(np.divide(freq_pred, len(y)) * 100, 1)

        target_labels = self._check_target_labels(target=y, target_labels=self.target_labels)

        y = self._check_numerical_target(target=y)

        m_conf = skmetrics.confusion_matrix(y, y_pred)
        yticklabels = [str(target_labels[i]) + " (" + str(freq_true[i]) + ": " + str(freqpct_true[i]) + "%)"
                       for i in np.arange(len(target_labels))]
        xticklabels = [str(target_labels[i]) + " (" + str(freq_pred[i]) + ": " + str(freqpct_pred[i]) + "%)"
                       for i in np.arange(len(target_labels))]
        df_conf = (pd.DataFrame(m_conf, columns = target_labels, index = target_labels)
                   .rename_axis(index = "True label",
                                columns = "Predicted label"))
        acc_score = skmetrics.accuracy_score(y, y_pred)
        sns.heatmap(df_conf, annot = True, fmt = ".5g", cmap = "Blues", ax = ax,
                    xticklabels = True, yticklabels = True, cbar = False)
        ax.set_yticklabels(labels = yticklabels, rotation = 0)
        ax.set_xticklabels(labels = xticklabels, rotation = 90, ha = "center")

        ax.set(title="Confusion Matrix (Acc ={0: .2f})".format(acc_score),
               xlabel="Predicted label (#: %)",
               ylabel="True label (#: %)")

        for text in ax.texts[::len(target_labels) + 1]:
            text.set_weight('bold')
        return ax


# Prediction distribution classes #######


class PredictionDistribution(TargetCatalog, IPredictionDistribution):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 show_grid: bool = True):

        TargetCatalog.__init__(self)
        IPredictionDistribution.__init__(self,
                                         colors = colors,
                                         show_grid = show_grid)

        self.prediction_distribution_classification = PredictionDistributionClassification
        self.prediction_distribution_regression = PredictionDistributionRegression

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()
        plotter = self._select_case(target = y)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    def _classification(self):
        return self.prediction_distribution_classification(colors=self.colors,
                                                           show_grid=self.show_grid)

    def _regression(self):
        return self.prediction_distribution_regression(colors=self.colors,
                                                       show_grid=self.show_grid)

    def _multiclass(self):
        raise TypeError("Cannot create roc curve for multiclass target.")


class PredictionDistributionClassification(PerformancePlotterMixin, IPredictionDistribution):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        is_numerical_target = np.issubdtype(y.dtype, np.number)
        label_0 = 0
        label_1 = 1
        if not is_numerical_target:
            label_0 = y.unique()[1]
            label_1 = y.unique()[0]
        y_num = self._check_numerical_target(target=y)
        sns.distplot(y_hat[:, 1][y_num == 1], color = self.colors[0], label = label_1, bins = 20, ax = ax)
        sns.distplot(y_hat[:, 1][y_num == 0], color = self.colors[1], label = label_0, bins = 20, ax = ax)

        ax.set(title="Distribution of Predictions",
               xlabel=r"Predictions ($\^y$)",
               ylabel="Density",
               xlim=(0, 1))

        ax.legend(title = "Target", loc = "best")
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


class PredictionDistributionRegression(IPredictionDistribution):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 show_grid: bool = True):
        super().__init__(colors=colors,
                         show_grid=show_grid)

        self.boxplot = BoxPlot

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        sns.distplot(y, color = self.colors[0], label = "y", ax = ax)
        sns.distplot(y_hat, color = self.colors[1], label = r"$\^y$", ax = ax)

        remove_tick_labels_below_min_value(ax = ax, dim = Dimension.y)

        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = 0.3,
                                     dim = Dimension.y,
                                     color_separation_line = 'black')

        df_distr = pd.concat([pd.DataFrame({"type": "y", "values": y}),
                              pd.DataFrame({"type": "y_hat", "values": y_hat})])

        (self
         .boxplot(colors=self.colors)
         .plot(x = df_distr['values'],
               y = df_distr['type'],
               ax = ax_inset))

        ax.legend(title = "", loc = "best")
        ax.set(title="Distribution",
               xlabel="",
               ylabel="density")

        set_grid(ax=ax, show_grid=self.show_grid)

        return ax


# Calibration classes #######


class PredictionCalibration(TargetCatalog, ICalibration):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 n_bins: int = 10,
                 target_labels: Optional[List[str]] = None,
                 show_grid: bool = True):

        TargetCatalog.__init__(self)
        ICalibration.__init__(self,
                              colors = colors,
                              n_bins = n_bins,
                              target_labels = target_labels,
                              show_grid = show_grid)

        self.calibration_classification = CalibrationClassification
        self.calibration_multiclass = CalibrationMulticlass
        self.calibration_regression = CalibrationRegression

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()
        plotter = self._select_case(target = y)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    def _classification(self):
        return self.calibration_classification(colors = self.colors,
                                               n_bins = self.n_bins,
                                               target_labels = self.target_labels,
                                               show_grid = self.show_grid)

    def _multiclass(self):
        return self.calibration_multiclass(colors = self.colors,
                                           n_bins = self.n_bins,
                                           target_labels = self.target_labels,
                                           show_grid = self.show_grid)

    def _regression(self):
        return self.calibration_regression(colors = self.colors,
                                           n_bins = self.n_bins,
                                           target_labels = self.target_labels,
                                           show_grid = self.show_grid)


class CalibrationMixin:

    @staticmethod
    def _set_title(ax: Axes):
        ax.set_title('Calibration')

    @staticmethod
    def _set_axes_labels(ax: Axes):
        ax.set_xlabel(r'$\bar{\^y}$ in $\^y$-bin')
        ax.set_ylabel(r'$\bar{y}$ in $\^y$-bin')


class CalibrationClassification(ICalibration, CalibrationMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        true, predicted = calibration_curve(y_true=y,
                                            y_prob=y_hat[:, 1],
                                            n_bins = self.n_bins)
        ax.plot(predicted, true, "o-")

        self._set_title(ax)
        self._set_axes_labels(ax)
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


class CalibrationMulticlass(ICalibration, CalibrationMixin, PerformancePlotterMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        target_labels = self._check_target_labels(target=y, target_labels=self.target_labels)
        y = self._check_numerical_target(target=y)

        n_target_categories = y_hat.shape[1]
        for i in np.arange(n_target_categories):
            true, predicted = calibration_curve(y_true=np.where(y == i, 1, 0),
                                                y_prob=y_hat[:, i],
                                                n_bins = self.n_bins,
                                                strategy = "quantile")
            ax.plot(predicted, true, "o-",
                    color = self.colors[i],
                    label = target_labels[i],
                    markersize = 3)

        self._set_title(ax)
        self._set_axes_labels(ax)
        set_grid(ax = ax, show_grid = self.show_grid)
        ax.legend(title = "Target", loc = 'best')
        return ax


class CalibrationRegression(ICalibration, CalibrationMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        df_calib = (pd.DataFrame({"y": y, "yhat": y_hat})
                    .assign(bin = lambda x: QuantileBinner(n_bins=self.n_bins).fit_transform(x["yhat"]))
                    .groupby(["bin"], as_index = False).agg("mean")
                    .sort_values("yhat"))
        sns.lineplot("yhat", "y", data = df_calib, ax = ax, marker = "o")

        self._set_title(ax)
        self._set_axes_labels(ax)
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


# Precision curve classes #######


class PrecisionRecallCurveClassification(IPrecisionRecall, PerformancePlotterMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()
        y = self._check_numerical_target(target=y)
        prec, rec, cutoff = skmetrics.precision_recall_curve(y, y_hat[:, 1])
        prec_rec_auc = skmetrics.average_precision_score(y, y_hat[:, 1])
        ax.plot(rec, prec)

        ax.set(title="Precision Recall Curve (AUC = {0:.2f})".format(prec_rec_auc),
               xlabel=r"recall=tpr: P($\^y$=1|$y$=1)",
               ylabel=r"precision: P($y$=1|$\^y$=1)")

        # create labels and position of labels for thresholds of decision function used to compute precision and recall
        for threshold in np.arange(0.1, 1, 0.1):
            i_threshold = np.argmax(cutoff > threshold)
            ax.annotate("{0: .1f}".format(threshold), (rec[i_threshold], prec[i_threshold]),
                        fontsize = 6)
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


class PrecisionCurveClassification(IPrecision, PerformancePlotterMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()
        y = self._check_numerical_target(target=y)
        prec, rec, cutoff = skmetrics.precision_recall_curve(y, y_hat[:, 1])
        pct_tested = np.array([])
        for thres in cutoff:
            pct_tested = np.append(pct_tested, [np.sum(y_hat[:, 1] >= thres) / len(y_hat)])
        sns.lineplot(pct_tested, prec[:-1], ax = ax, palette = sns.xkcd_palette(["red"]))

        ax.set(title="Precision Curve",
               xlabel="% Samples Tested",
               ylabel=r"precision: P($y$=1|$\^y$=1)")

        for thres in np.arange(0.1, 1, 0.1):
            i_thres = np.argmax(cutoff > thres)
            ax.annotate("{0: .1f}".format(thres), (pct_tested[i_thres], prec[i_thres]),
                        fontsize = 6)
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


# Multiclass specific plots #######


class MetricsMulticlass(IMulticlassModelMetrics, PerformancePlotterMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        target_labels = self._check_target_labels(target=y, target_labels=self.target_labels)

        y = self._check_numerical_target(target=y)

        n_target_categories = y_hat.shape[1]
        aucs = np.array([round(skmetrics.roc_auc_score(np.where(y == i, 1, 0), y_hat[:, i]), 2)
                         for i in np.arange(n_target_categories)])

        y_pred = y_hat.argmax(axis = 1)
        m_conf = skmetrics.confusion_matrix(y, y_pred)
        prec = np.round(np.diag(m_conf) / m_conf.sum(axis = 0) * 100, 1)
        rec = np.round(np.diag(m_conf) / m_conf.sum(axis = 1) * 100, 1)
        f1 = np.round(2 * prec * rec / (prec + rec), 1)
        df_metrics = (pd.DataFrame(np.column_stack((y, np.flip(np.argsort(y_hat, axis = 1), axis = 1)[:, :3])),
                                   columns = ["y", "yhat1", "yhat2", "yhat3"])
                      .assign(acc_top1 = lambda x: (x["y"] == x["yhat1"]).astype("int"),
                              acc_top2 = lambda x: ((x["y"] == x["yhat1"]) | (x["y"] == x["yhat2"])).astype("int"),
                              acc_top3 = lambda x: ((x["y"] == x["yhat1"]) | (x["y"] == x["yhat2"]) |
                                                    (x["y"] == x["yhat3"])).astype("int"))
                      .assign(label = lambda x: np.array(target_labels, dtype = "object")[x["y"].values])
                      .groupby(["label"])["acc_top1", "acc_top2", "acc_top3"].agg("mean").round(2)
                      .join(pd.DataFrame(np.stack((aucs, rec, prec, f1), axis = 1),
                                         index = target_labels, columns = ["auc", "recall", "precision", "f1"])))
        sns.heatmap(df_metrics.T, annot = True, fmt = ".5g",
                    cmap = ListedColormap(['white']), linewidths = 1, linecolor = "black", cbar = False,
                    ax = ax, xticklabels = True, yticklabels = True)
        ax.set_yticklabels(labels = ['Accuracy\n Top1', 'Accuracy\n Top2', 'Accuracy\n Top3', "AUC\n 1-vs-all",
                                     'Recall\n' r"P($\^y$=k|$y$=k))", 'Precision\n' r"P($y$=k|$\^y$=k))", 'F1'])
        ax.xaxis.tick_top()  # x axis on top
        ax.xaxis.set_label_position('top')
        ax.tick_params(left = False, top = False)
        ax.set_xlabel("True label")
        return ax


class TrueLabelsMulticlass(IMulticlassBarplot, PerformancePlotterMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        target_labels = self._check_target_labels(target=y, target_labels=self.target_labels)

        y = self._check_numerical_target(target=y)

        y_pred = y_hat.argmax(axis = 1)
        m_conf = skmetrics.confusion_matrix(y, y_pred)
        df_conf = (pd.DataFrame(m_conf, columns = target_labels, index = target_labels)
                   .rename_axis(index = "True label",
                                columns = "Predicted label"))

        ax = df_conf.copy().T.iloc[:, ::-1].plot.bar(stacked = True, ax = ax,
                                                     color = self.colors[:len(target_labels)][::-1])
        handles, labels = ax.get_legend_handles_labels()
        ax.legend(handles[::-1], labels[::-1], title = "True label", loc = 'center left', bbox_to_anchor = (1, 0.5))
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


class PredictedLabelsMulticlass(IMulticlassBarplot, PerformancePlotterMixin):

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        target_labels = self._check_target_labels(target=y, target_labels=self.target_labels)

        y = self._check_numerical_target(target=y)

        y_pred = y_hat.argmax(axis = 1)
        m_conf = skmetrics.confusion_matrix(y, y_pred)
        df_conf = (pd.DataFrame(m_conf, columns = target_labels, index = target_labels)
                   .rename_axis(index = "True label",
                                columns = "Predicted label"))

        ax = df_conf.iloc[::-1].plot.barh(stacked = True, ax = ax, color = self.colors[:len(target_labels)])
        ax.legend(title = "Predicted label", loc = 'center left', bbox_to_anchor = (1, 0.5))
        set_grid(ax = ax, show_grid = self.show_grid)
        return ax


# Regression specific plots #######


class ScatterPlotRegression(IScatterPlot):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        super().__init__(title = title,
                         xlabel = xlabel,
                         ylabel = ylabel,
                         x_limits = x_limits,
                         y_limits = y_limits,
                         show_grid = show_grid,
                         show_regplot = show_regplot)

        self.boxplot = BoxPlot

    def plot(self,
             x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        grid_scale = self._update_grid_scale(x=x,
                                             x_limits=self.x_limits,
                                             y=y,
                                             y_limits=self.y_limits)

        tmp_cmap = mcolors.LinearSegmentedColormap.from_list("wh_bl_yl_rd",
                                                             [(1, 1, 1, 0), "blue", "yellow", "red"])
        p = ax.hexbin(x, y,
                      gridsize = grid_scale,
                      cmap = tmp_cmap)
        plt.colorbar(p, ax = ax)

        if self.show_regplot:
            sns.regplot(x = x, y = y,
                        lowess = True,
                        scatter = False,
                        color = "black",
                        line_kws = dict(linewidth = 1),
                        ax = ax)

        ax.set_facecolor('white')

        offset_ratio = 0.3
        inset_color = 'grey'
        boxplot = self.boxplot(colors = [inset_color])

        # Inner Histogram on y
        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = offset_ratio,
                                     dim = Dimension.x)
        sns.distplot(a = y,
                     color = inset_color,
                     vertical = True,
                     ax = ax_inset)

        # Inner-inner Boxplot on y
        ax_inset_nested = create_inset_axes(ax = ax_inset,
                                            offset_ratio = offset_ratio,
                                            dim = Dimension.x)
        boxplot.orientation = 'v'
        boxplot.plot(x=y, ax=ax_inset_nested)

        # Inner Histogram on x
        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = offset_ratio,
                                     dim = Dimension.y)
        sns.distplot(a = x,
                     color = inset_color,
                     ax = ax_inset)

        # Inner-inner Boxplot on x
        ax_inset_nested = create_inset_axes(ax = ax_inset,
                                            offset_ratio = offset_ratio,
                                            dim = Dimension.y)
        boxplot.orientation = 'h'
        boxplot.plot(x=x, ax=ax_inset_nested)

        set_inset_axis_limits(ax = ax, offset_ratio = offset_ratio, dim = Dimension.x)

        set_grid(ax = ax, show_grid = self.show_grid)

        if self.y_limits is not None:
            ax.set_ylim(self.y_limits)
        if self.x_limits is not None:
            ax.set_xlim(self.x_limits)

        return ax

    @staticmethod
    def _update_grid_scale(x: pd.Series,
                           y: pd.Series,
                           x_limits: Optional[AxisLimits],
                           y_limits: Optional[AxisLimits]):
        x_grid_scale = 1
        y_grid_scale = 1
        if x_limits is not None:
            x_grid_scale = 1.5 + ((x_limits[1] - x_limits[0]) / (np.max(x) - np.min(x)))
        if y_limits is not None:
            y_grid_scale = 1.5 + ((y_limits[1] - y_limits[0]) / (np.max(y) - np.min(y)))

        grid_scale = (int(50 * x_grid_scale), int(50 * y_grid_scale))
        return grid_scale


class ObservedDistributionRegression(IScatterPlotRegression):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        super().__init__(x_limits=x_limits,
                         y_limits=y_limits,
                         show_grid=show_grid,
                         show_regplot=show_regplot)
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.scatterplot = ScatterPlotRegression

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        corr_spear = pd.DataFrame({"y_true": y, "y_pred": y_hat}).corr(method = "spearman").values[0, 1]

        scatterplot = self.scatterplot(x_limits=self.x_limits,
                                       y_limits=self.y_limits,
                                       show_regplot=self.show_regplot,
                                       show_grid=self.show_grid)
        ax = scatterplot.plot(x = y_hat,
                              y = y,
                              ax = ax)

        ax.set(title=r"Observed vs. Fitted ($\rho_{Spearman}$ = " +
                     str(corr_spear.round(3)) + ")",
               xlabel=r"$\^y$",
               ylabel="y")

        return ax


class ResidualsDistributionRegression(IScatterPlotRegression):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        super().__init__(x_limits = x_limits,
                         y_limits=y_limits,
                         show_grid=show_grid,
                         show_regplot=show_regplot)
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.scatterplot = ScatterPlotRegression

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        scatterplot = self.scatterplot(x_limits=self.x_limits,
                                       y_limits=self.y_limits,
                                       show_regplot=self.show_regplot,
                                       show_grid=self.show_grid)
        ax = scatterplot.plot(x = y_hat,
                              y = y - y_hat,
                              ax = ax)

        ax.set(title="Residuals vs. Fitted",
               xlabel=r"$\^y$",
               ylabel=r"y-$\^y$")

        return ax


class AbsoluteResidualsDistributionRegression(IScatterPlotRegression):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        super().__init__(x_limits=x_limits,
                         y_limits=y_limits,
                         show_grid=show_grid,
                         show_regplot=show_regplot)
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.scatterplot = ScatterPlotRegression

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        scatterplot = self.scatterplot(x_limits=self.x_limits,
                                       y_limits=self.y_limits,
                                       show_regplot=self.show_regplot,
                                       show_grid=self.show_grid)
        ax = scatterplot.plot(x = y_hat,
                              y = abs(y - y_hat),
                              ax = ax)

        ax.set(title="Absolute Residuals vs. Fitted",
               xlabel=r"$\^y$",
               ylabel=r"|y-$\^y$|")

        return ax


class RelativeResidualsDistributionRegression(IScatterPlotRegression):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        super().__init__(x_limits = x_limits,
                         y_limits = y_limits,
                         show_grid = show_grid,
                         show_regplot = show_regplot)
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.scatterplot = ScatterPlotRegression

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        scatterplot = self.scatterplot(x_limits=self.x_limits,
                                       y_limits=self.y_limits,
                                       show_regplot=self.show_regplot,
                                       show_grid=self.show_grid)
        ax = scatterplot.plot(x = y_hat,
                              y = abs(y - y_hat) / abs(y),
                              ax = ax)

        ax.set(title="Relative Residuals vs. Fitted",
               xlabel=r"$\^y$",
               ylabel=r"|y-$\^y$|/|y|")

        return ax


# Target type performance plotter classes #######


class PerformancePlotterClassification(IPerformancePlotter):
    """
    Creates single performance plot for true target labels and target scores predicted from a classification model,
    according to given style parameter.

    An appropriate plot method is automatically generated by the :meth:`plot` method based on the :attr:`measure`
    parameter.
    """

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 n_bins: int = 10,
                 show_grid: bool = True):

        super().__init__(colors=colors,
                         n_bins=n_bins,
                         show_grid=show_grid)

        self.plotter_roc_curve = ROCCurve
        self.plotter_prediction_distribution = PredictionDistribution
        self.plotter_calibration = PredictionCalibration
        self.plotter_confusion_matrix = ConfusionMatrix
        self.plotter_precision_recall_curve = PrecisionRecallCurveClassification
        self.plotter_precision_curve = PrecisionCurveClassification

        self._measure_choices = {
            PerformanceMeasure.roc_curve: self._roc_curve_classification,
            PerformanceMeasure.confusion_matrix: self._confusion_matrix_classification,
            PerformanceMeasure.prediction_distribution: self._prediction_distribution_classification,
            PerformanceMeasure.calibration: self._calibration_classification,
            PerformanceMeasure.precision_recall: self._precision_recall_curve,
            PerformanceMeasure.precision: self._precision_curve,
        }

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             measure: PerformanceMeasure,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create performance plot appropriate for specified performance measure.

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param measure: Performance measure used to choose appropriate plot method
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        plotter = self._select_measure(measure = measure)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    # Implementation of select method  #####################

    def _select_measure(self,
                        measure: Union[PerformanceMeasure, int]):
        if isinstance(measure, int):
            measure = list(self._measure_choices.keys())[measure]
        if measure not in self._measure_choices.keys():
            raise ValueError("Unsupported measure choice for target type.")
        return self._measure_choices[measure]()

    # Implementation of plot methods ########################

    def _prediction_distribution_classification(self):
        return self.plotter_prediction_distribution(colors=self.colors,
                                                    show_grid=self.show_grid)

    def _roc_curve_classification(self):
        return self.plotter_roc_curve(colors=self.colors,
                                      show_grid=self.show_grid)

    def _calibration_classification(self):
        return self.plotter_calibration(colors=self.colors,
                                        n_bins=self.n_bins,
                                        show_grid=self.show_grid)

    def _confusion_matrix_classification(self):
        return self.plotter_confusion_matrix()

    def _precision_recall_curve(self):
        return self.plotter_precision_recall_curve(show_grid=self.show_grid)

    def _precision_curve(self):
        return self.plotter_precision_curve(show_grid=self.show_grid)


class PerformancePlotterMulticlass(IPerformancePlotter):
    """
    Creates single performance plot for true target labels and target scores predicted from a multiclass model,
    according to given style parameter.

    An appropriate plot method is automatically generated by the :meth:`plot` method based on the :attr:`measure`
    parameter.
    """

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 n_bins: int = 10,
                 show_grid: bool = True):
        self.plotter_roc_curve = ROCCurve
        self.plotter_calibration = PredictionCalibration
        self.plotter_confusion_matrix = ConfusionMatrix
        self.plotter_model_metrics = MetricsMulticlass
        self.plotter_barplot_true = TrueLabelsMulticlass
        self.plotter_barplot_predicted = PredictedLabelsMulticlass

        self._measure_choices = {
            PerformanceMeasure.roc_curve: self._roc_curve_multiclass,
            PerformanceMeasure.confusion_matrix: self._confusion_matrix_multiclass,
            PerformanceMeasure.barplot_true: self._barplot_true,
            PerformanceMeasure.calibration: self._calibration_multiclass,
            PerformanceMeasure.barplot_pred: self._barplot_predicted,
            PerformanceMeasure.model_metrics: self._model_metrics,
        }

        super().__init__(colors=colors,
                         n_bins=n_bins,
                         show_grid=show_grid)

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             measure: PerformanceMeasure,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create performance plot appropriate for specified performance measure.

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param measure: Performance measure used to choose appropriate plot method
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        plotter = self._select_measure(measure = measure)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    # Implementation of select method  #####################

    def _select_measure(self,
                        measure: Union[PerformanceMeasure, int]):
        if isinstance(measure, int):
            measure = list(self._measure_choices.keys())[measure]
        if measure not in self._measure_choices.keys():
            raise ValueError("Unsupported measure choice for target type.")
        return self._measure_choices[measure]()

    # Implementation of target measure catalog methods ########################

    def _roc_curve_multiclass(self):
        return self.plotter_roc_curve(colors=self.colors,
                                      show_grid=self.show_grid)

    def _calibration_multiclass(self):
        return self.plotter_calibration(colors=self.colors,
                                        n_bins=self.n_bins,
                                        show_grid=self.show_grid)

    def _confusion_matrix_multiclass(self):
        return self.plotter_confusion_matrix()

    def _model_metrics(self):
        return self.plotter_model_metrics()

    def _barplot_true(self):
        return self.plotter_barplot_true(colors=self.colors,
                                         show_grid=self.show_grid)

    def _barplot_predicted(self):
        return self.plotter_barplot_predicted(colors=self.colors,
                                              show_grid=self.show_grid)


class PerformancePlotterRegression(IPerformancePlotter):
    """
    Creates single performance plot for true target labels and target scores predicted from a regression model,
    according to given style parameter.

    An appropriate plot method is automatically generated by the :meth:`plot` method based on the :attr:`measure`
    parameter.
    """
    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 n_bins: int = 10,
                 show_regplot: bool = True,
                 show_grid: bool = True):
        self.plotter_prediction_distribution = PredictionDistribution
        self.plotter_calibration = PredictionCalibration
        self.plotter_observed_fitted = ObservedDistributionRegression
        self.plotter_residuals_fitted = ResidualsDistributionRegression
        self.plotter_absolute_residuals_fitted = AbsoluteResidualsDistributionRegression
        self.plotter_relative_residuals_fitted = RelativeResidualsDistributionRegression

        self._measure_choices = {
            PerformanceMeasure.observed_fitted: self._observed_fitted,
            PerformanceMeasure.calibration: self._calibration_regression,
            PerformanceMeasure.prediction_distribution: self._prediction_distribution_regression,
            PerformanceMeasure.residuals_fitted: self._residuals_fitted,
            PerformanceMeasure.abs_residuals_fitted: self._absolute_residuals_fitted,
            PerformanceMeasure.rel_residuals_fitted: self._relative_residuals_fitted,
        }

        super().__init__(colors=colors,
                         x_limits=x_limits,
                         y_limits=y_limits,
                         n_bins=n_bins,
                         show_grid=show_grid,
                         show_regplot=show_regplot)

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             measure: PerformanceMeasure,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create performance plot appropriate for specified performance measure.

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param measure: Performance measure used to choose appropriate plot method
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        plotter = self._select_measure(measure = measure)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat)

    # Implementation of select method  #####################

    def _select_measure(self,
                        measure: Union[PerformanceMeasure, int]):
        if isinstance(measure, int):
            measure = list(self._measure_choices.keys())[measure]
        if measure not in self._measure_choices.keys():
            raise ValueError("Unsupported measure choice for target type.")
        return self._measure_choices[measure]()

    # Implementation of plot methods ########################

    def _prediction_distribution_regression(self):
        return self.plotter_prediction_distribution(colors=self.colors,
                                                    show_grid=self.show_grid)

    def _calibration_regression(self):
        return self.plotter_calibration(colors=self.colors,
                                        n_bins=self.n_bins,
                                        show_grid=self.show_grid)

    def _observed_fitted(self):
        return self.plotter_observed_fitted(x_limits=self.x_limits,
                                            y_limits=self.y_limits,
                                            show_grid=self.show_grid,
                                            show_regplot=self.show_regplot)

    def _residuals_fitted(self):
        return self.plotter_residuals_fitted(x_limits=self.x_limits,
                                             y_limits=self.y_limits,
                                             show_grid=self.show_grid,
                                             show_regplot=self.show_regplot)

    def _absolute_residuals_fitted(self):
        return self.plotter_absolute_residuals_fitted(x_limits=self.x_limits,
                                                      y_limits=self.y_limits,
                                                      show_grid=self.show_grid,
                                                      show_regplot=self.show_regplot)

    def _relative_residuals_fitted(self):
        return self.plotter_relative_residuals_fitted(x_limits=self.x_limits,
                                                      y_limits=self.y_limits,
                                                      show_grid=self.show_grid,
                                                      show_regplot=self.show_regplot)


# Performance plotter classes #######


class PerformancePlotter(TargetCatalog):
    """
    Creates single performance plot for true target labels and predicted target scores, according to given style
    parameter

    An appropriate plot method is automatically generated by the :meth:`plot` method based on the combination of the
    automatically detected target type and the :attr:`measure` parameter.

    :param colors: Plot colors for target
    :param x_limits: Limits for x-axis on scatter plots
    :param y_limits: Limits for y-axis on scatter plots
    :param n_bins: Number of bins to discretize the [0, 1] interval for calibration curves
    :param show_regplot: Show lowess (locally weighted scatterplot smoothing)
        regression line (bool) on scatter plots.
    :param show_grid: Show grid lines on plots (bool)
    """
    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 n_bins: int = 10,
                 show_regplot: bool = True,
                 show_grid: bool = True):
        super().__init__()

        self.plotter_classification = PerformancePlotterClassification
        self.plotter_multiclass = PerformancePlotterMulticlass
        self.plotter_regression = PerformancePlotterRegression

        self.colors = colors
        self.x_limits = x_limits
        self.y_limits = y_limits
        self.n_bins = n_bins
        self.show_regplot = show_regplot
        self.show_grid = show_grid

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             measure: PerformanceMeasure,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create performance plot appropriate for target type and performance measure combination.

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param measure: Performance measure used to choose appropriate plot method
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        plotter = self._select_case(target = y)
        return plotter.plot(ax = ax, y = y, y_hat = y_hat, measure = measure)

    # Implementation of target catalog methods ########################

    def _classification(self):
        return self.plotter_classification(colors=self.colors,
                                           n_bins=self.n_bins,
                                           show_grid=self.show_grid)

    def _multiclass(self):
        return self.plotter_multiclass(colors=self.colors,
                                       n_bins=self.n_bins,
                                       show_grid=self.show_grid)

    def _regression(self):
        return self.plotter_regression(colors=self.colors,
                                       x_limits=self.x_limits,
                                       y_limits=self.y_limits,
                                       n_bins=self.n_bins,
                                       show_regplot=self.show_regplot,
                                       show_grid=self.show_grid)


class MultiPerformancePlotter:
    """
    Creates (multiple) performance measure plot(s) for given true target labels and predicted target scores according to
    given style parameters

    Uses :class:`hmsPM.plotting.grid.PlotGridBuilder` to create and arrange plots on page and uses the functions in
    `hmsPM.plotting.output` to save PDF files, with plots produced by :class:`PerformancePlotter`.

    :param colors: Plot colors for target
    :param x_limits: Limits for x-axis on scatter plots
    :param y_limits: Limits for y-axis on scatter plots
    :param n_bins: Number of bins to discretize the [0, 1] interval for calibration curves
    :param show_regplot: Show lowess (locally weighted scatterplot smoothing)
        regression line (bool) on scatter plots.
    :param show_grid: Show grid lines on plots (bool)
    :param n_rows: Number of rows on (PDF) page
    :param n_cols: Number of cols on (PDF) page
    :param w: PDF width in inches
    :param h: PDF height in inches
    """
    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 n_bins: int = 10,
                 show_regplot: bool = True,
                 show_grid: bool = True,
                 n_rows: int = 2,
                 n_cols: int = 3,
                 w: float = 11,
                 h: float = 7.5):
        self._performance_plotter = PerformancePlotter(colors = colors,
                                                       x_limits = x_limits,
                                                       y_limits = y_limits,
                                                       n_bins = n_bins,
                                                       show_regplot = show_regplot,
                                                       show_grid = show_grid)
        self._plot_grid_builder = PlotGridBuilder(n_rows= n_rows,
                                                  n_cols= n_cols,
                                                  w = w,
                                                  h = h)

    @property
    def colors(self):
        return self._performance_plotter.colors

    @colors.setter
    def colors(self, colors):
        self._performance_plotter.colors = colors

    @property
    def x_limits(self):
        return self._performance_plotter.x_limits

    @x_limits.setter
    def x_limits(self, x_limits):
        self._performance_plotter.x_limits = x_limits

    @property
    def y_limits(self):
        return self._performance_plotter.y_limits

    @y_limits.setter
    def y_limits(self, y_limits):
        self._performance_plotter.y_limits = y_limits

    @property
    def n_bins(self):
        return self._performance_plotter.n_bins

    @n_bins.setter
    def n_bins(self, n_bins):
        self._performance_plotter.n_bins = n_bins

    @property
    def show_regplot(self):
        return self._performance_plotter.show_regplot

    @show_regplot.setter
    def show_regplot(self, show_regplot):
        self._performance_plotter.show_regplot = show_regplot

    @property
    def show_grid(self):
        return self._performance_plotter.show_grid

    @show_grid.setter
    def show_grid(self, show_grid):
        self._performance_plotter.show_grid = show_grid

    @property
    def n_rows(self):
        return self._plot_grid_builder.n_rows

    @n_rows.setter
    def n_rows(self, n_rows):
        self._plot_grid_builder.n_rows = n_rows

    @property
    def n_cols(self):
        return self._plot_grid_builder.n_cols

    @n_cols.setter
    def n_cols(self, n_cols):
        self._plot_grid_builder.n_cols = n_cols

    @property
    def w(self):
        return self._plot_grid_builder.w

    @w.setter
    def w(self, w):
        self._plot_grid_builder.w = w

    @property
    def h(self):
        return self._plot_grid_builder.h

    @h.setter
    def h(self, h):
        self._plot_grid_builder.h = h

    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             measures: Optional[Union[str, PerformanceMeasure, List[PerformanceMeasure]]] = "all",
             file_path: Optional[str] = None) -> PlotGrids:
        """
        Create performance plot(s) for target variable and predicted target scores given performance measure(s).

        The target type is detected automatically. By default, all available performance measures are plotted on a
        single page. Alternatively, the :attr:`measures` parameter can be used to specify which performance measure(s)
        should be used for plotting (default = ``all_metrics``).

        Available measures for each target type are

        * classification: ``prediction_distribution``, ``roc_curve``, ``calibration_curve``, ``confusion_matrix``,
          ``precision_recall_curve``, ``precision_curve``;
        * regression: ``prediction_distribution``, ``calibration_curve``, ``scatterplot_observed_vs_fitted``,
          ``scatterplot_residuals_vs_fitted``, ``scatterplot_absolute_residuals_vs_fitted``,
          ``scatterplot_relative_residuals_vs_fitted``; and
        * multiclass: ``roc_curve``, ``calibration_curve``, ``confusion_matrix``, ``model_metrics_table``,
          ``barplot_true_labels_by_predicted_labels``, ``barplot_predicted_labels_by_true_labels``.

        Plots can be saved as PDF files by specifying the :attr:`file_path` parameter.

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param measures: String or list indicating performance measure(s), or ``all``, which automatically plots all
            available performance measures for given target type - default = ``all``
        :param file_path: File path (string) to save PDF file of plots;
            default = ``None``.
        :return: Plot(s) for given performance measure(s)
        """
        _measures = self._convert_measures(measures = measures)
        plot_calls = self._generate_plot_calls_per_measure(plot_function=self._performance_plotter.plot,
                                                           y = y,
                                                           y_hat = y_hat,
                                                           measures = _measures)

        plot_grids = self._plot_grid_builder.build(plot_calls=plot_calls)

        if file_path:
            save_plot_grids_to_pdf(plot_grids=plot_grids, file_path=file_path)

        return plot_grids

    @staticmethod
    def _convert_measures(measures: Optional[Union[str, PerformanceMeasure, List[PerformanceMeasure]]]
                          ) -> Union[List[PerformanceMeasure], Iterable[int]]:
        if measures == "all":
            # all six available performance measured will be plotted
            return list(range(0, 6))
        if isinstance(measures, str):
            return [PerformanceMeasure(measures)]
        if isinstance(measures, Iterable):
            return [PerformanceMeasure(measure) for measure in measures]
        raise TypeError('measure must be list of PerformanceMeasure')

    @staticmethod
    def _generate_plot_calls_per_measure(plot_function: Callable,
                                         measures: Union[List[PerformanceMeasure], Iterable[int]],
                                         **kwargs) -> PlotFunctionCalls:
        return [
            PlotFunctionCall(function=plot_function,
                             kwargs={**kwargs, 'measure': measure})
            for measure in measures
        ]
