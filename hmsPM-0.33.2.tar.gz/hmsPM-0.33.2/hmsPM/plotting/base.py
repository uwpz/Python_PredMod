"""Base plotting classes"""

from abc import ABC, abstractmethod
from typing import Optional, Union, List

import pandas as pd
import seaborn as sns
from matplotlib.axes import Axes

from hmsPM.datatypes import (
    AxisLimits,
    AxesLimits,
    Color,
    Colors,
    TargetType,
    PerformanceMeasure,
)


class IMulticlassBarplot(ABC):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 target_labels: Optional[List[str]] = None,
                 show_grid: bool = True):
        self.colors = colors
        self.target_labels = target_labels
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a barplot for performance of multiclass model

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IMulticlassModelMetrics(ABC):

    def __init__(self,
                 target_labels: Optional[List[str]] = None):
        self.target_labels = target_labels

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a table with multiclass model metrics

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IScatterPlot(ABC):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.x_limits = x_limits
        self.y_limits = y_limits
        self.show_grid = show_grid
        self.show_regplot = show_regplot

    @abstractmethod
    def plot(self,
             x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a scatter plot for performance plots for regression targets

        :param x: x variable
        :param y: y variable
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IScatterPlotRegression(ABC):

    def __init__(self,
                 title: Optional[str] = None,
                 xlabel: Optional[str] = "x",
                 ylabel: Optional[str] = "y",
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True,
                 show_regplot: Optional[bool] = True):
        self.title = title
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.x_limits = x_limits
        self.y_limits = y_limits
        self.show_grid = show_grid
        self.show_regplot = show_regplot

    @abstractmethod
    def plot(self,
             x: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a scatter plot for performance plots for regression targets

        :param x: x variable
        :param y_hat: y variable
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IROCCurve(ABC):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 target_labels: Optional[List[str]] = None,
                 show_grid: bool = True):
        self.colors = colors
        self.target_labels = target_labels
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a ROC curve

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IConfusionMatrix(ABC):

    def __init__(self,
                 target_labels: Optional[List[str]] = None):
        self.target_labels = target_labels

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a Confusion Matrix

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IPredictionDistribution(ABC):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 show_grid: bool = True):
        self.colors = colors
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a distribution plot for predictions

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class ICalibration(ABC):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 n_bins: int = 10,
                 target_labels: Optional[List[str]] = None,
                 show_grid: bool = True):
        self.colors = colors
        self.n_bins = n_bins
        self.target_labels = target_labels
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a calibration plot

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IPrecisionRecall(ABC):

    def __init__(self,
                 show_grid: bool = True):
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a precision recall curve plot

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IPrecision(ABC):

    def __init__(self,
                 show_grid: bool = True):
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a precision curve plot

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IPerformancePlotter(ABC):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 x_limits: Optional[AxisLimits] = None,
                 y_limits: Optional[AxisLimits] = None,
                 n_bins: int = 10,
                 show_regplot: bool = True,
                 show_grid: bool = True):
        self.colors = colors
        self.x_limits = x_limits
        self.y_limits = y_limits
        self.n_bins = n_bins
        self.show_regplot = show_regplot
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             y: pd.Series,
             y_hat: pd.Series,
             measure: PerformanceMeasure,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a performance plot

        :param y: Target variable
        :param y_hat: Predicted target scores
        :param  measure: Performance measure
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IBarPlot(ABC):

    def __init__(self,
                 height: Optional[pd.Series] = 0.8,
                 colors: Optional[Union[Color, Colors]] = None):
        """
        :param height: Bar height
        :param colors: Bar face colors
        """
        self.height = height
        self.colors = colors

    @abstractmethod
    def plot(self,
             x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a bar plot

        :param x: Bar width
        :param y: Y coordinate of the bars
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IMultiBarPlot(ABC):

    def __init__(self,
                 height: Optional[pd.Series] = 0.8,
                 colors: Colors = sns.color_palette('colorblind')):
        """
        :param height: Bar height
        :param colors: Bar face colors
        """
        self.height = height
        self.colors = colors

    @abstractmethod
    def plot(self,
             x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a bar plot

        :param x: Bar width
        :param y: Y coordinate of the bars
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IBoxPlot(ABC):

    def __init__(self,
                 colors: Optional[Colors] = None,
                 orientation: str = 'h',
                 line_width = 1,
                 flier_size = 3):
        """
        :param colors: Colors to use for the different hue levels
        :param orientation: Orientation of the plot ('v': vertical, 'h': horizontal)
        :param line_width: Width of lines framing the plot elements
        :param flier_size: Size of markers indicating outliers
        """
        self.colors = colors
        self.orientation = orientation
        self.line_width = line_width
        self.flier_size = flier_size

    @abstractmethod
    def plot(self,
             x: pd.Series,
             y: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a box plot

        :param x: X values
        :param y: Y coordinate of the box plots
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IDistributionPlotMulticlass(ABC):

    def __init__(self, colors: Colors = sns.color_palette('colorblind')):
        """
        :param colors: Colors
        """
        self.colors = colors

    @abstractmethod
    def plot(self,
             x: pd.Series,
             group_by: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create univariate distribution plot for (multiclass) classification

        :param x: X values
        :param group_by: Group X values by
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IDistributionPlotRegression(ABC):

    def __init__(self, colors: Optional[Union[Color, Colors]] = None):
        """
        :param colors: Colors
        """
        self.colors = colors

    @abstractmethod
    def plot(self,
             x: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create univariate distribution plot for regression

        :param x: Values
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IHeatMap(ABC):

    def __init__(self,
                 axlims: AxesLimits,
                 colors: Optional[Union[Color, Colors]] = None):
        """
        :param axlims: Axes limits
        :param colors: Colors
        """
        self.axlims = axlims
        self.colors = colors

    @abstractmethod
    def plot(self,
             x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create heat map as 2D hexagonal binning plot

        :param x: X values
        :param y: Y values
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IRegressionPlot(ABC):

    def __init__(self):
        pass

    @staticmethod
    @abstractmethod
    def plot(x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a linear regression model fit plot

        :param x: X values
        :param y: Y values
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        raise NotImplementedError


class IFeatureDistributionPlotter(ABC):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 target_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True):
        self.colors = colors
        self.target_limits = target_limits
        self.show_grid = show_grid
        """
        :param colors: Colors
        :param target_limits: Target limits
        :param show_grid: Switch for showing grid lines
        """

    @abstractmethod
    def plot(self,
             feature: pd.Series,
             target: pd.Series,
             target_type: Optional[Union[TargetType, str]] = None,
             varimps: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create a feature distribution plot

        :param feature: Pandas series with feature variable
        :param target: Pandas series with target variable
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from
            :attr:`target` parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :return: Axes
        """
        raise NotImplementedError
