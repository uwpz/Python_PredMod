"""Variable importance plotting"""

import warnings
from typing import Optional, Union, List

import pandas as pd
import numpy as np
import seaborn as sns
from matplotlib.axes import Axes

from hmsPM.datatypes import (
    SinglePlot,
)
from hmsPM.plotting.grid import SinglePlotBuilder


class FeatureImportancePlotter:
    """
    Creates a plot of feature importances calculated by permutation by
    :class:`hmsPM.calculation.feature_importances.calculate_variable_importance_by_permutation`

    Uses :class:`hmsPM.plotting.grid.SinglePlotBuilder` for plot initialisation and layout, and uses functions from
    `hmsPM.plotting.output` to save PDF file.

    :param w: PDF width in inches
    :param h: PDF height in inches
    """

    def __init__(self,
                 w: float = 8,
                 h: float = 6):
        super().__init__()

        self._single_plot_builder = SinglePlotBuilder(w=w, h=h)

    @property
    def w(self):
        return self._single_plot_builder.w

    @w.setter
    def w(self, w):
        self._single_plot_builder.w = w

    @property
    def h(self):
        return self._single_plot_builder.h

    @h.setter
    def h(self, h):
        self._single_plot_builder.h = h

    def plot(self,
             varimps: pd.DataFrame,
             feature_names: Optional[Union[str, List[str]]] = None,
             file_path: Optional[str] = None) -> SinglePlot:
        """
        Create plot for given feature importances.

        By default all features in the :attr:`varimps` dataframe are plotted. Alternatively,
        the features to be plotted can be specified with the :attr:`feature_names` parameter.

        The created plot can be saved as PDF files by specifying the
        :attr:`file_path` parameter.

        :param varimps: Pandas dataframe with variable importances
        :param feature_names: Feature or list of features to be used for plotting. If ``None``, all features from the
            input dataframe are plotted - default = ``None``
        :param file_path: Output file path - default = ``None``
        :return: Plot for given features
        """
        page = self._single_plot_builder.build(plot_function=self._plot_feature_importance,
                                               varimps=varimps,
                                               feature_names=feature_names)

        if file_path:
            page.figure.savefig(file_path)

        return page

    def _plot_feature_importance(
            self,
            ax: Axes,
            varimps: pd.DataFrame,
            feature_names: Optional[Union[str, List[str]]] = None) -> Axes:
        """
        Return feature importance plot.

        :param ax: Axes
        :param varimps: Pandas dataframe with variable importances
        :param feature_names: List of features to be used for plotting. If ``None``, all features from the input
            dataframe are plotted - default = ``None``
        :return: Figure and axis
        """
        n_features = len(varimps)
        if feature_names is not None:
            varimps = self._subset_variable_importances(feature_names=feature_names, varimps=varimps)

        # create category labels for plot
        varimps["Category"] = pd.cut(varimps["importance"], [-np.inf, 10, 50, np.inf],
                                     labels = ["low", "medium", "high"])

        sns.barplot("importance", "feature",
                    hue = "Category",
                    data = varimps,
                    dodge = False, palette = sns.xkcd_palette(["blue", "orange", "red"]), ax = ax)
        ax.legend(loc = 8, title = "Importance")
        ax.plot("importance_cum", "feature", data = varimps, color = "grey", marker = "o")
        ax.set_xlabel(r"importance / cumulative importance in % (-$\bullet$-)")
        ax.set_title("Top{0: .0f} (of{1: .0f}) Feature Importances".format(len(varimps), n_features))
        return ax

    @staticmethod
    def _subset_variable_importances(varimps: pd.DataFrame,
                                     feature_names: Union[str, List[str]]) -> pd.DataFrame:
        if isinstance(feature_names, str):
            feature_names = [feature_names]
        invalid_feature_names = set(feature_names) - set(varimps["feature"])
        if len(invalid_feature_names) > 0:
            warnings.warn(f"At least one of the specified feature_names is not a feature name in the passed varimps "
                          f"dataframe. The invalid feature names will be ignored. The invalid feature names "
                          f"are {invalid_feature_names}")
        idx_features_to_plot = varimps["feature"].isin(feature_names)
        varimps = varimps.loc[idx_features_to_plot, :]
        return varimps
