"""Axes utilities"""

from typing import Optional

import numpy as np
import pandas as pd
from matplotlib.axes import Axes
from matplotlib import pyplot as plt

from hmsPM.datatypes import (
    AxisLimits,
    Ticks,
    Dimension,
)
from hmsPM.preprocessing.target import encode_to_numerical_target
from hmsPM.utils import call_method


###############################################################################
# Base axes utilities


def create_axes() -> Axes:
    _, ax = plt.subplots()
    return ax


def set_grid(ax: Axes, show_grid: bool):
    ax.grid(show_grid, linewidth=1)


###############################################################################
# Axes utilities with specified dimensions


def get_axlim(ax: Axes, dim: Dimension):
    get_lim_methods = {Dimension.x: 'get_xlim',
                       Dimension.y: 'get_ylim'}
    return call_method(ax, get_lim_methods[dim])


def get_axticks(ax: Axes, dim: Dimension):
    get_ticks_method = {Dimension.x: 'get_xticks',
                        Dimension.y: 'get_yticks'}
    return call_method(ax, get_ticks_method[dim])


def join_axes(ax1: Axes, ax2: Axes, dim: Dimension):
    get_shared_method = {Dimension.y: 'get_shared_x_axes',
                         Dimension.x: 'get_shared_y_axes'}
    shared_axes = call_method(ax1, get_shared_method[dim])
    shared_axes.join(ax1, ax2)


def set_axlim(ax: Axes, dim: Dimension, axlim: AxisLimits):
    set_lim_method = {Dimension.x: 'set_xlim',
                      Dimension.y: 'set_ylim'}
    call_method(ax, set_lim_method[dim], *axlim)


def set_axlabel(ax: Axes, dim: Dimension, label: str):
    set_label_method = {Dimension.x: 'set_xlabel',
                        Dimension.y: 'set_ylabel'}
    call_method(ax, set_label_method[dim], label)


def set_axticks(ax: Axes, dim: Dimension, ticks: Ticks):
    set_ticks_method = {Dimension.x: 'set_xticks',
                        Dimension.y: 'set_yticks'}
    call_method(ax, set_ticks_method[dim], ticks)


def remove_tick_labels_below_min_value(ax: Axes, dim: Dimension):
    axlim = get_axlim(ax=ax, dim=dim)
    ticks = [tick
             for tick in get_axticks(ax=ax, dim=dim)
             if tick >= axlim[0]]
    set_axticks(ax=ax, dim=dim, ticks=ticks)


def set_inset_axis_limits(ax: Axes,
                          offset_ratio: float,
                          dim: Dimension):
    axlim = get_axlim(ax=ax, dim=dim)
    new_axlims = (axlim[0] - offset_ratio * (axlim[1] - axlim[0]),
                  axlim[1])
    set_axlim(ax=ax, dim=dim, axlim=new_axlims)


def draw_line(ax: Axes, dim: Dimension, loc: float, color: str, ls: Optional[str] = 'solid'):
    axline_method = {Dimension.x: 'axvline',
                     Dimension.y: 'axhline'}
    call_method(ax, axline_method[dim], loc, color=color, ls=ls)


def draw_mean_line(ax: Axes, data: pd.Series, dim: Dimension, color: str):
    if not np.issubdtype(data.dtype, np.number):
        data = encode_to_numerical_target(data)
    draw_line(ax=ax, dim=dim, loc=data.mean(), color=color, ls='dotted')


def draw_separation_line(ax: Axes, dim: Dimension, loc: float, color: str):
    draw_line(ax=ax, dim=dim, loc=loc, color=color)


def create_inset_axes(ax: Axes,
                      offset_ratio: float,
                      dim: Dimension,
                      color_separation_line: Optional[str] = None):

    axlim = get_axlim(ax=ax, dim=dim)
    new_min_axlim = axlim[0] - offset_ratio * (axlim[1] - axlim[0])
    new_axlims = (new_min_axlim, axlim[1])
    set_axlim(ax=ax, dim=dim, axlim=new_axlims)
    inset_ratio = 0.85 * (axlim[0] - new_min_axlim) / (axlim[1] - new_min_axlim)

    inset_axes_bounds = {Dimension.x: [0, 0, inset_ratio, 1],
                         Dimension.y: [0, 0, 1, inset_ratio]}
    ax_inset = ax.inset_axes(inset_axes_bounds[dim])

    ax_inset.set_axis_off()

    if color_separation_line is not None:
        draw_separation_line(ax=ax, dim=dim, loc=axlim[0], color=color_separation_line)

    join_axes(ax1=ax, ax2=ax_inset, dim=dim)

    return ax_inset
