"""PDF plotting"""

from os.path import splitext

from matplotlib.backends.backend_pdf import PdfPages

from hmsPM.datatypes import PlotGrids


def ensure_ext(file_path: str, file_ext: str) -> str:
    """Ensures that the file path has the given extension"""
    path = file_path
    base_path, ext = splitext(path)
    if ext != file_ext:
        path = base_path + file_ext
    return path


def save_plot_grids_to_pdf(plot_grids: PlotGrids, file_path: str):
    """
    Save pages with plots in PDF file

    :param plot_grids: PlotPages with figure and axes to be plotted
    :param file_path: File path (string) to save PDF file of plots
    """
    file_path = ensure_ext(file_path=file_path, file_ext='.pdf')
    with PdfPages(file_path) as pdf:
        for page in plot_grids:
            pdf.savefig(figure=page.figure)
