"""Distribution plotting"""

import warnings
from typing import Callable, Optional, Union

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib import colors as mcolors
from matplotlib.axes import Axes

from hmsPM.datatypes import (
    AxisLimits,
    AxesLimits,
    Color,
    Colors,
    FeatureScale,
    PlotGrids,
    PlotFunctionCall,
    PlotFunctionCalls,
    TargetType,
    Dimension,
)
from hmsPM.plotting.base import (
    IBarPlot,
    IMultiBarPlot,
    IBoxPlot,
    IDistributionPlotMulticlass,
    IDistributionPlotRegression,
    IHeatMap,
    IRegressionPlot,
    IFeatureDistributionPlotter,
)
from hmsPM.plotting.axes import (
    create_axes,
    create_inset_axes,
    draw_mean_line,
    set_axlim,
    set_axlabel,
    set_grid,
    remove_tick_labels_below_min_value,
)
from hmsPM.plotting.output import save_plot_grids_to_pdf
from hmsPM.plotting.grid import PlotGridBuilder
from hmsPM.preprocessing import remove_na
from hmsPM.utils import (
    check_target_type,
    check_multiclass_levels,
    FeatureTargetCatalog,
)

# remove warnings for two many open figures
plt.rcParams.update({'figure.max_open_warning': 0})


class BarPlot(IBarPlot):

    def plot(self,
             x: pd.DataFrame,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        ax.barh(y=y,
                width=x,
                height=self.height,
                color=self.colors,
                edgecolor="black",
                alpha=0.5,
                linewidth=1)
        return ax


class BarPlotMulticlass(IMultiBarPlot):

    def plot(self,
             x: pd.DataFrame,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        offset = np.zeros(len(x))
        members = x.columns.to_numpy()
        for m, member in enumerate(members):
            color = self.colors[m]
            ax.barh(y=y,
                    width=x[member],
                    height=self.height,
                    left=offset,
                    color=color,
                    label=member,
                    edgecolor="black",
                    alpha=0.5,
                    linewidth=1)
            offset = offset + x[member].values
        ax.legend(title=x.columns.name,
                  loc="center left",
                  bbox_to_anchor=(1, 0.5))
        return ax


class BoxPlot(IBoxPlot):

    def plot(self,
             x: pd.Series,
             y: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        if y is None:
            x = remove_na(x)
        else:
            x, y = remove_na(x, y)
            y = y.astype('category')

        sns.boxplot(x=x,
                    y=y,
                    showmeans=True,
                    meanprops=dict(marker="x",
                                   markerfacecolor="black",
                                   markeredgecolor="black",
                                   markersize=3),
                    palette=self.colors,
                    orient=self.orientation,
                    linewidth=self.line_width,
                    fliersize=self.flier_size,
                    ax=ax)
        return ax


class DistributionPlotMulticlass(IDistributionPlotMulticlass):

    def plot(self,
             x: pd.Series,
             group_by: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        members = np.sort(group_by.unique())
        for m, member in enumerate(members):
            x_plot = x[group_by == member].dropna()
            bw: Union[float, str] = 'scott'
            if len(x_plot.quantile([.25, .75]).unique()) == 1:
                bw = 0.2
            color = self.colors[m]
            sns.distplot(a=x_plot,
                         kde_kws=dict(bw=bw),
                         color=color,
                         bins=20,
                         label=member,
                         ax=ax)
        ax.legend(title=group_by.name, loc="best")
        return ax


class DistributionPlotRegression(IDistributionPlotRegression):

    def plot(self,
             x: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        x = x.dropna()
        sns.distplot(a=x,
                     bins=20,
                     color=self.colors,
                     ax=ax)
        return ax


class HeatMap(IHeatMap):

    def plot(self,
             x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        # Calculate colormap
        if self.colors is None:
            self.colors = mcolors.LinearSegmentedColormap.from_list("gr_bl_yl_rd",
                                                                    [(0.5, 0.5, 0.5, 0), "blue", "yellow",
                                                                     "red"])
        # Hexbin plot
        ax.set_facecolor('0.98')
        plot_hexbin = ax.hexbin(x, y,
                                extent=self.axlims,
                                cmap=self.colors)

        # Add legend
        plt.colorbar(plot_hexbin, ax=ax)
        return ax


class RegressionPlot(IRegressionPlot):

    @staticmethod
    def plot(x: pd.Series,
             y: pd.Series,
             ax: Optional[Axes] = None) -> Axes:
        if ax is None:
            ax = create_axes()

        df = pd.concat([x, y], axis=1)
        sns.regplot(x=x.name,
                    y=y.name,
                    data=df,
                    lowess=True,
                    scatter=False,
                    color="black",
                    ax=ax)
        return ax


class CategoricalPlotterMixin:

    @staticmethod
    def _prepare_data_for_barplot(target: pd.Series,
                                  feature: pd.Series,
                                  target_type: TargetType,
                                  min_bar_width: float) -> pd.DataFrame:
        # Create dataframe with target feature frequencies
        if target_type == TargetType.regression:
            df_data = pd.concat([feature, target], axis=1)
            df_plot = pd.DataFrame(dict(target_means_by_feature=df_data.groupby(feature.name)[target.name].mean(),
                                        freq_target_feature_comb=df_data.groupby(feature.name).size())).reset_index()
        else:
            crosstab_feature_target = pd.crosstab(feature, target)
            df_plot = crosstab_feature_target.div(crosstab_feature_target.sum(axis=1), axis=0)
            df_plot["freq_target_feature_comb"] = crosstab_feature_target.sum(axis=1)
            df_plot = df_plot.reset_index()

        # Bar width
        no_of_rows = len(target)
        max_freq_target_feature_comb = max(df_plot.freq_target_feature_comb)
        df_plot["pct_target_feature_comb"] = 100 * df_plot.freq_target_feature_comb / no_of_rows
        df_plot["weight_bar_width"] = 0.9 * df_plot.freq_target_feature_comb / max_freq_target_feature_comb
        df_plot["weight_bar_width_adjusted"] = np.where(df_plot.weight_bar_width.values < min_bar_width,
                                                        min_bar_width,
                                                        df_plot.weight_bar_width)

        # Axis labels
        y_ratio = df_plot.pct_target_feature_comb.round(1).astype(str)
        if target_type == TargetType.regression:
            df_plot["y"] = df_plot.index.values
            df_plot["y_labels"] = df_plot[feature.name] + " (" + y_ratio + "%)"
        else:
            df_plot["y"] = df_plot[feature.name] + " (" + y_ratio + "%)"
            if target_type == TargetType.classification:
                target_class = 1
                if not np.issubdtype(target.dtype, np.number):
                    minority_class = target.value_counts(ascending=True).index[0]
                    target_class = minority_class
                df_plot['x'] = df_plot[target_class]

        return df_plot


class ClassificationPlotterMixin:

    @staticmethod
    def _get_class_colors(target: pd.Series, colors: Colors) -> Colors:
        """Get color palette for (multiclass) classification levels
        Returns a sequential palette when more classes than expected for multiclass classification;
        returns the default palette when user input palette has insufficient levels
        but expected number of classes for multiclass classification.
        :return: color palette
        """
        number_of_classes = target.nunique()
        more_than_10_classes = number_of_classes > 10
        insufficient_color_palette = len(colors) < number_of_classes
        if more_than_10_classes and insufficient_color_palette:
            warnings.warn(
                "Insufficient color levels for number of classes - use sequential color palette.",
                UserWarning)
            colors = sns.cubehelix_palette(number_of_classes, start=.5, rot=-.75)
        elif insufficient_color_palette:
            warnings.warn(
                "Insufficient color levels for number of classes - change color palette.",
                UserWarning)
            colors = sns.color_palette('colorblind')
        else:
            colors = colors
        return colors


class FeatureDistributionPlotterMixin:

    # Auxiliary axes methods ##################################################

    @staticmethod
    def _get_axes_limits(ax, x, y, target_limits: Optional[AxisLimits] = None) -> AxesLimits:
        xmin = x.min()
        xmax = x.max()
        ymin = y.min()
        ymax = y.max()
        # TODO The values of target_limits are not use. May use different parameter.
        if target_limits:
            ylim = ax.get_ylim()
            ymin = ylim[0]
            ymax = ylim[1]
        axlims = (xmin, xmax, ymin, ymax)
        return axlims

    @staticmethod
    def _set_axis_limits_for_target(ax: Axes,
                                    dim: Dimension,
                                    target_limits: Optional[AxisLimits] = None):
        if target_limits is not None:
            set_axlim(ax=ax, dim=dim, axlim=target_limits)

    # Auxiliary formatting methods ############################################

    def _set_title_and_labels(self,
                              ax: Axes,
                              target: pd.Series,
                              feature: pd.Series,
                              target_type: TargetType,
                              feature_scale: FeatureScale,
                              dim: Dimension,
                              varimps: Optional[pd.Series] = None):
        self._set_title(ax=ax, feature=feature, varimps=varimps)
        self._set_feature_label(ax=ax,
                                feature=feature,
                                feature_scale=feature_scale,
                                dim=dim,
                                digits=1)
        self._set_target_label(ax=ax,
                               target=target,
                               target_type=target_type,
                               feature_scale=feature_scale,
                               dim=dim)

    @staticmethod
    def _set_title(ax: Axes, feature: pd.Series, varimps: Optional[pd.Series] = None):
        title = str(feature.name)
        if varimps is not None:
            title += f" (VI: {str(varimps[feature.name])})"
        ax.set_title(title)

    @staticmethod
    def _set_feature_label(ax: Axes,
                           feature: pd.Series,
                           feature_scale: FeatureScale,
                           dim: Dimension,
                           digits: int = 1):
        if feature_scale == FeatureScale.numerical:
            dim_other = {Dimension.x: Dimension.y,
                         Dimension.y: Dimension.x}
            dim = dim_other[dim]
        na_ratio = str(round(feature.isnull().mean() * 100, ndigits = digits))
        feature_label = f"{feature.name} (NA: {na_ratio}%)"
        set_axlabel(ax=ax, dim=dim, label=feature_label)

    @staticmethod
    def _set_target_label(ax: Axes,
                          target: pd.Series,
                          target_type: TargetType,
                          feature_scale: FeatureScale,
                          dim: Dimension):
        target_type = TargetType[target_type.name]
        if not np.issubdtype(target.dtype, np.number):
            minority_class = target.value_counts(ascending=True).index[0]
        else:
            minority_class = None
        label = {
            (FeatureScale.numerical, TargetType.classification): "density",
            (FeatureScale.numerical, TargetType.multiclass): "density",
            (FeatureScale.numerical, TargetType.regression): str(target.name),
            (FeatureScale.categorical, TargetType.classification): f"mean({str(target.name)})" + (
                f" - target: {str(minority_class)}" if minority_class else ""),
            (FeatureScale.categorical, TargetType.multiclass): f"Proportions by {str(target.name)}",
            (FeatureScale.categorical, TargetType.regression): str(target.name),
        }
        feature_target_combination = (feature_scale, target_type)
        set_axlabel(ax=ax, dim=dim, label=label[feature_target_combination])


class FeatureDistributionPlotterCategoricalClassification(IFeatureDistributionPlotter,
                                                          FeatureDistributionPlotterMixin,
                                                          CategoricalPlotterMixin,
                                                          ClassificationPlotterMixin):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 min_bar_width: int = 0,
                 target_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True):
        super().__init__(colors=colors,
                         target_limits=target_limits,
                         show_grid=show_grid)
        self.min_bar_width = min_bar_width

        self.barplot = BarPlot
        self.barplot_multiclass = BarPlotMulticlass

    def plot(self,
             feature: pd.Series,
             target: pd.Series,
             target_type: Optional[Union[TargetType, str]] = None,
             varimps: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create distribution plot for categorical feature against classification target

        This method can be used for both a classification and multiclass
        classification target. It is automatically called by the :meth:`plot`
        method if a categorical feature and classification target is detected.

        The generated plot is composed of

        * a main :class:`BarPlot` or :class:`BarPlotMulticlass` showing the mean
          target value of each feature value

          * with its bar width scaled to the feature value frequency for which
            a minimum width can be specified with the class parameter
            :attr:`min_bar_width`, and

        * an inner :class:`BarPlot` showing the feature value frequency.

        The used plot classes are stored as class members and can be
        overwritten by classes with compatible signatures derived from the
        according abstract interface class :class:`IBarPlot`.

        As a default, the distribution plot is created based on the detected
        target type. If the target_type parameter is specified it overwrites
        the detected target type unless it is incompatible with the data.

        If the detected target type is ``regression`` and the user specified
        :attr:`target_type` is ``multiclass`` this function raises an error if
        the number of target levels is too high to be supported by the plotting
        functionality (> 100) and a warning if the number of target levels is
        too high to create reasonable aesthetics (> 10).

        The plot is generated in the passed axes. New axes are created if no axes
        are passed to the plot method. If needed, the figure object can be retrieved
        with `matplotlib.pyplot.gcf`.

        :param feature: Pandas series with feature variable
        :param target: Pandas series with target variable
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from
            :attr:`target` parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        if ax is None:
            ax = create_axes()

        check_multiclass_levels(target = target, target_type = target_type)
        target_type = check_target_type(target = target, target_type = target_type)

        df_plot = self._prepare_data_for_barplot(target = target, feature = feature, target_type = target_type,
                                                 min_bar_width = self.min_bar_width)

        # Main barplot
        colors = self._get_class_colors(target = target, colors = self.colors)
        if target_type == TargetType.multiclass:
            x_multiclass = np.sort(target.unique())
            barplot_multiclass = self.barplot_multiclass(height = df_plot.weight_bar_width_adjusted,
                                                         colors = colors)
            barplot_multiclass.plot(ax = ax,
                                    x = df_plot.loc[:, x_multiclass],
                                    y = df_plot.y)
        else:
            barplot = self.barplot(height = df_plot.weight_bar_width_adjusted,
                                   colors = colors[1])
            barplot.plot(ax = ax,
                         x = df_plot.x,
                         y = df_plot.y)
            self._set_axis_limits_for_target(ax = ax, dim = Dimension.x, target_limits = self.target_limits)
            draw_mean_line(ax = ax, data = target, dim = Dimension.x, color = 'black')

        remove_tick_labels_below_min_value(ax = ax, dim = Dimension.x)

        # Inner barplot
        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = 0.3,
                                     dim = Dimension.x,
                                     color_separation_line = 'black')
        barplot = self.barplot(colors = "lightgrey")
        barplot.plot(ax = ax_inset,
                     x = df_plot.weight_bar_width,
                     y = df_plot.y.values)

        self._set_title_and_labels(ax=ax,
                                   target=target,
                                   feature=feature,
                                   target_type=target_type,
                                   feature_scale=FeatureScale.categorical,
                                   dim=Dimension.x,
                                   varimps=varimps)

        set_grid(ax=ax, show_grid=self.show_grid)

        return ax


class FeatureDistributionPlotterCategoricalRegression(IFeatureDistributionPlotter,
                                                      FeatureDistributionPlotterMixin,
                                                      CategoricalPlotterMixin):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 min_bar_width: int = 0,
                 target_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True):
        super().__init__(colors=colors,
                         target_limits=target_limits,
                         show_grid=show_grid)
        self.min_bar_width = min_bar_width

        self.barplot = BarPlot
        self.boxplot = BoxPlot

    def plot(
            self,
            feature: pd.Series,
            target: pd.Series,
            target_type: Optional[Union[TargetType, str]] = None,
            varimps: Optional[pd.Series] = None,
            ax: Optional[Axes] = None) -> Axes:
        """
        Create distribution plot for categorical feature against regression target

        This method can be used for a regression target. It is automatically
        called by the :meth:`plot` method if a categorical feature and
        regression target is detected.

        The generated plot is composed of

        * a main :class:`BoxPlot` showing the feature value distribution on the
          target,
        * an inner :class:`BarPlot` showing the feature value frequency, and
        * a dotted line highlighting the mean target value.

        The used plot classes are stored as class members and can be
        overwritten by classes with compatible signatures derived from the
        according abstract interface classes :class:`IBoxPlot` and
        :class:`IBarPlot`.

        The plot is generated in the passed axes. New axes are created if no axes
        are passed to the plot method. If needed, the figure object can be retrieved
        with `matplotlib.pyplot.gcf`.

        :param feature: Pandas series with feature variable
        :param target: Pandas series with target variable
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from
            :attr:`target` parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        if ax is None:
            ax = create_axes()

        # Main grouped boxplot
        self._set_axis_limits_for_target(ax = ax, dim = Dimension.x, target_limits = self.target_limits)
        boxplot = self.boxplot(colors = ["lightgrey"])
        boxplot.plot(x = target,
                     y = feature,
                     ax = ax)

        remove_tick_labels_below_min_value(ax = ax, dim = Dimension.x)

        df_plot = self._prepare_data_for_barplot(target = target,
                                                 feature = feature,
                                                 target_type = TargetType.regression,
                                                 min_bar_width = self.min_bar_width)

        # Inner barplot
        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = 0.3,
                                     dim = Dimension.x,
                                     color_separation_line = 'black')
        barplot = self.barplot(colors = 'lightgrey')
        barplot.plot(ax = ax_inset,
                     x = df_plot.weight_bar_width,
                     y = df_plot.y)

        draw_mean_line(ax=ax, data=target, dim=Dimension.x, color='black')

        self._set_title_and_labels(ax=ax,
                                   target=target,
                                   feature=feature,
                                   target_type=TargetType.regression,
                                   feature_scale=FeatureScale.categorical,
                                   dim=Dimension.x,
                                   varimps=varimps)

        ax.set_yticklabels(df_plot.y_labels)

        set_grid(ax=ax, show_grid=self.show_grid)

        return ax


class FeatureDistributionPlotterNumericalClassification(IFeatureDistributionPlotter,
                                                        FeatureDistributionPlotterMixin,
                                                        ClassificationPlotterMixin):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 target_limits: Optional[AxisLimits] = None,
                 show_grid: bool = True):
        super().__init__(colors=colors,
                         target_limits=target_limits,
                         show_grid=show_grid)
        self.boxplot = BoxPlot
        self.distributionplot_multiclass = DistributionPlotMulticlass

    def plot(self,
             feature: pd.Series,
             target: pd.Series,
             target_type: Optional[Union[TargetType, str]] = None,
             varimps: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create distribution plot for numerical feature against classification target.

        This method can be used for both a classification and multiclass
        classification target. It is automatically called by the :meth:`plot`
        method if a numerical feature and classification target is detected.

        The generated plot is composed of

        * a main :class:`DistributionPlotMulticlass` showing the feature
          value distribution on the target,
        * an innter :class:`BoxPlot` showing the feature value distribution on the
          target.

        The used plot classes are stored as class members and can be
        overwritten by classes with compatible signatures derived from the
        according abstract interface classes :class:`IBoxPlot` and
        :class:`IDistributionPlotMulticlass`.

        If the detected target type is ``regression`` and the user specified
        :attr:`target_type` is ``multiclass`` this function raises an error if
        the number of target levels is too high to be supported by the plotting
        functionality (> 100) and a warning if the number of target levels is
        too high to create reasonable aesthetics (> 10).

        The plot is generated in the passed axes. New axes are created if no axes
        are passed to the plot method. If needed, the figure object can be retrieved
        with `matplotlib.pyplot.gcf`.

        :param feature: Pandas series with feature variable
        :param target: Pandas series with target variable
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from
            :attr:`target` parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        if ax is None:
            ax = create_axes()

        check_multiclass_levels(target = target, target_type = target_type)
        target_type = check_target_type(target = target, target_type = target_type)

        # Main distribution plot (overlayed)
        colors = self._get_class_colors(target = target, colors = self.colors)
        distribution_plot_multiclass = self.distributionplot_multiclass(colors = colors)
        distribution_plot_multiclass.plot(ax = ax,
                                          x = feature,
                                          group_by = target)

        remove_tick_labels_below_min_value(ax = ax, dim = Dimension.y)

        # Inner Boxplot
        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = 0.3,
                                     dim = Dimension.y,
                                     color_separation_line = 'black')
        self.boxplot(colors = colors).plot(ax = ax_inset,
                                           y = target,
                                           x = feature)

        self._set_title_and_labels(ax=ax,
                                   target=target,
                                   feature=feature,
                                   target_type=target_type,
                                   feature_scale=FeatureScale.numerical,
                                   dim=Dimension.y,
                                   varimps=varimps)

        set_grid(ax=ax, show_grid=self.show_grid)

        return ax


class FeatureDistributionPlotterNumericalRegression(IFeatureDistributionPlotter,
                                                    FeatureDistributionPlotterMixin):

    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 target_limits: Optional[AxisLimits] = None,
                 show_regplot: bool = False,
                 show_grid: bool = True):
        super().__init__(colors=colors,
                         target_limits=target_limits,
                         show_grid=show_grid)
        self.show_regplot = show_regplot

        self.boxplot = BoxPlot
        self.distplot_regression = DistributionPlotRegression
        self.heatmap = HeatMap
        self.regplot = RegressionPlot

    def plot(self,
             feature: pd.Series,
             target: pd.Series,
             target_type: Optional[Union[TargetType, str]] = None,
             varimps: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create distribution plot for numerical feature against regression target

        This method can be used for a regression target. It is automatically
        called by the :meth:`plot` method if a numerical feature and
        regression target is detected.

        The generated plot is composed of

        * a main :class:`HeatMap` showing the feature value distribution on the
          target,

          * optionally, with a lowess regression lines
            (:class:`RegressionPlot`) which is controlled by the class
            parameter :attr:`show_regplot`,

        * an inner :class:`DistributionPlotRegression` histogram showing the feature
          value distribution, and
        * a inner :class:`BoxPlot` showing the value distribution.

        The used plot classes are stored as class members and can be
        overwritten by classes with compatible signatures derived from the
        according abstract interface classes :class:`IBoxPlot`,
        :class:`DistributionPlotRegression`, :class:`IHeatMap`, and
        :class:`IRegressionPlot`.

        The plot is generated in the passed axes. New axes are created if no axes
        are passed to the plot method. If needed, the figure object can be retrieved
        with `matplotlib.pyplot.gcf`.

        :param feature: Pandas series with feature variable
        :param target: Pandas series with target variable
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from
            :attr:`target` parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        if ax is None:
            ax = create_axes()

        # Main heatmap
        self._set_axis_limits_for_target(ax = ax, dim = Dimension.y, target_limits = self.target_limits)
        axlims = self._get_axes_limits(ax = ax, x = feature, y = target, target_limits = self.target_limits)
        heatmap = self.heatmap(axlims = axlims)
        heatmap.plot(ax = ax, x = feature, y = target)

        # Show lowess regression line?
        if self.show_regplot:
            self.regplot.plot(ax = ax, x = feature, y = target)

        remove_tick_labels_below_min_value(ax = ax, dim = Dimension.y)

        # Inner Histogram
        ax_inset = create_inset_axes(ax = ax,
                                     offset_ratio = 0.4,
                                     dim = Dimension.y,
                                     color_separation_line = 'grey')
        distplot_regression = self.distplot_regression(colors="black")
        distplot_regression.plot(ax = ax_inset,
                                 x = feature)

        # Inner-inner Boxplot
        ax_inset_nested = create_inset_axes(ax = ax_inset,
                                            offset_ratio = 0.4,
                                            dim = Dimension.y)
        boxplot = self.boxplot(colors=["grey"])
        boxplot.plot(x = feature,
                     ax = ax_inset_nested)

        self._set_title_and_labels(ax=ax,
                                   target=target,
                                   feature=feature,
                                   target_type=TargetType.regression,
                                   feature_scale=FeatureScale.numerical,
                                   dim=Dimension.y,
                                   varimps=varimps)

        set_grid(ax=ax, show_grid=self.show_grid)

        return ax


class FeatureDistributionPlotter(FeatureTargetCatalog):
    """
    Creates single feature distributions plot against a model target according to given style parameter

    An appropriate distribution plot is automatically generated by the
    :meth:`plot` method based on the target type and feature scale combination.

    :param colors: Plot colors for target
    :param min_bar_width: Minimum bar width for plots of categorical features.
        The bar width in these plots is scaled to the frequency of each
        category. The :attr:`min_bar_width` ensures that even bars of rare
        categories are visible.
    :param target_limits: Limit for target axis
    :param show_grid: Show grid lines on plots (bool).
    """

    def __init__(self,
                 colors: Union[Color, Colors] = sns.color_palette('colorblind'),
                 min_bar_width: int = 0,
                 target_limits: Optional[AxisLimits] = None,
                 show_regplot: bool = False,
                 show_grid: bool = True):
        super().__init__()

        self.colors = colors
        self.min_bar_width = min_bar_width
        self.target_limits = target_limits
        self.show_regplot = show_regplot
        self.show_grid = show_grid

        self.plotter_categorical_classification = FeatureDistributionPlotterCategoricalClassification
        self.plotter_categorical_regression = FeatureDistributionPlotterCategoricalRegression
        self.plotter_numerical_classification = FeatureDistributionPlotterNumericalClassification
        self.plotter_numerical_regression = FeatureDistributionPlotterNumericalRegression

    def plot(self,
             feature: pd.Series,
             target: pd.Series,
             target_type: Optional[Union[TargetType, str]] = None,
             varimps: Optional[pd.Series] = None,
             ax: Optional[Axes] = None) -> Axes:
        """
        Create distribution plot appropriate for target type and feature scale combination.

        :param feature: Pandas series with feature variable
        :param target: Pandas series with target variable
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from
            :attr:`target` parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :param ax: Optional axes object to draw the plot onto; default = ``None``
        :return: Axes
        """
        plotter = self._select_case(feature = feature, target = target, target_type = target_type)
        return plotter.plot(ax = ax, feature = feature, target = target, target_type = target_type, varimps = varimps)

    # Implementation of feature-target catalog methods ########################

    def _categorical_feature_classification_target(self):
        return self.plotter_categorical_classification(colors=self.colors,
                                                       min_bar_width=self.min_bar_width,
                                                       target_limits=self.target_limits,
                                                       show_grid=self.show_grid)

    def _categorical_feature_multiclass_target(self):
        return self.plotter_categorical_classification(colors=self.colors,
                                                       min_bar_width=self.min_bar_width,
                                                       target_limits=self.target_limits,
                                                       show_grid=self.show_grid)

    def _categorical_feature_regression_target(self):
        return self.plotter_categorical_regression(colors=self.colors,
                                                   min_bar_width=self.min_bar_width,
                                                   target_limits=self.target_limits,
                                                   show_grid=self.show_grid)

    def _numerical_feature_classification_target(self):
        return self.plotter_numerical_classification(colors=self.colors,
                                                     target_limits=self.target_limits,
                                                     show_grid=self.show_grid)

    def _numerical_feature_multiclass_target(self):
        return self.plotter_numerical_classification(colors=self.colors,
                                                     target_limits=self.target_limits,
                                                     show_grid=self.show_grid)

    def _numerical_feature_regression_target(self):
        return self.plotter_numerical_regression(colors=self.colors,
                                                 target_limits=self.target_limits,
                                                 show_regplot=self.show_regplot,
                                                 show_grid=self.show_grid)


class MultiFeatureDistributionPlotter:
    """
    Creates (multiple) consistent feature distribution plot(s) against a model
    target according to given style parameters

    Uses :class:`hmsPM.plotting.grid.PlotGridBuilder` for plot initialisation and grid layout, and uses functions from
    `hmsPM.plotting.output` to save PDF file. The plots are produced by :class:`FeatureDistributionPlotter`.

    :param colors: Plot colors for target
    :param min_bar_width: Minimum bar width for plots of categorical features.
        The bar width in these plots is scaled to the frequency of each
        category. The :attr:`min_bar_width` ensures that even bars of rare
        categories are visible.
    :param target_limits: Limit for target axis
    :param show_regplot: Show lowess (locally weighted scatterplot smoothing)
        regression line (bool) on plot for numerical feature against regression
        target.
    :param show_grid: Show grid lines on plots (bool)
    :param n_rows: Number of rows on PDF page
    :param n_cols: Number of cols on PDF page
    :param w: PDF width in inches
    :param h: PDF height in inches
    """

    def __init__(self,
                 colors: Union[Color, Colors] = sns.color_palette('colorblind'),
                 min_bar_width: int = 0,
                 target_limits: Optional[AxisLimits] = None,
                 show_regplot: bool = False,
                 show_grid: bool = True,
                 n_rows: int = 1,
                 n_cols: int = 1,
                 w: float = 8,
                 h: float = 6):
        self._distribution_plotter = FeatureDistributionPlotter(colors = colors,
                                                                min_bar_width = min_bar_width,
                                                                target_limits = target_limits,
                                                                show_regplot = show_regplot,
                                                                show_grid = show_grid)
        self._plot_grid_builder = PlotGridBuilder(n_rows= n_rows,
                                                  n_cols= n_cols,
                                                  w = w,
                                                  h = h)

    @property
    def colors(self):
        return self._distribution_plotter.colors

    @colors.setter
    def colors(self, colors):
        self._distribution_plotter.colors = colors

    @property
    def min_bar_width(self):
        return self._distribution_plotter.min_bar_width

    @min_bar_width.setter
    def min_bar_width(self, min_bar_width):
        self._distribution_plotter.min_bar_width = min_bar_width

    @property
    def target_limits(self):
        return self._distribution_plotter.target_limits

    @target_limits.setter
    def target_limits(self, target_limits):
        self._distribution_plotter.target_limits = target_limits

    @property
    def show_regplot(self):
        return self._distribution_plotter.show_regplot

    @show_regplot.setter
    def show_regplot(self, show_regplot):
        self._distribution_plotter.show_regplot = show_regplot

    @property
    def show_grid(self):
        return self._distribution_plotter.show_grid

    @show_grid.setter
    def show_grid(self, show_grid):
        self._distribution_plotter.show_grid = show_grid

    @property
    def n_rows(self):
        return self._plot_grid_builder.n_rows

    @n_rows.setter
    def n_rows(self, n_rows):
        self._plot_grid_builder.n_rows = n_rows

    @property
    def n_cols(self):
        return self._plot_grid_builder.n_cols

    @n_cols.setter
    def n_cols(self, n_cols):
        self._plot_grid_builder.n_cols = n_cols

    @property
    def w(self):
        return self._plot_grid_builder.w

    @w.setter
    def w(self, w):
        self._plot_grid_builder.w = w

    @property
    def h(self):
        return self._plot_grid_builder.h

    @h.setter
    def h(self, h):
        self._plot_grid_builder.h = h

    def plot(self,
             features: Union[pd.Series, pd.DataFrame],
             target: pd.Series,
             target_type: Optional[Union[TargetType, str]] = None,
             varimps: Optional[pd.Series] = None,
             file_path: Optional[str] = None) -> PlotGrids:
        """
        Create plot(s) for distribution of given feature(s) against target.

        The feature scale and target type are detected automatically. The
        target type can be specified explicitly via the :attr:`target_type`
        parameter.

        Plots can be saved as PDF files by specifying the :attr:`file_path`
        parameter.

        :param features: Pandas dataframe or series with feature(s) to be
            plotted
        :param target: Pandas series with target variable
        :param target_type: Target type (``multiclass``, ``classification``, or
            ``regression``) which overwrites target type detected from `target`
            parameter - default = ``None``.
        :param varimps: Pandas series with variable importances with an entry
            for the value of each feature in features - default = ``None``.
        :param file_path: File path (string) to save PDF file of plots;
            default = ``None``.
        :return: Plot(s) for given feature(s) against target
        """

        plot_calls = self._generate_plot_calls_per_feature(plot_function = self._distribution_plotter.plot,
                                                           features = features,
                                                           target = target,
                                                           target_type = target_type,
                                                           varimps = varimps)

        plot_grids = self._plot_grid_builder.build(plot_calls = plot_calls)

        if file_path:
            save_plot_grids_to_pdf(plot_grids=plot_grids, file_path=file_path)

        return plot_grids

    @staticmethod
    def _generate_plot_calls_per_feature(plot_function: Callable,
                                         features: Union[pd.Series, pd.DataFrame],
                                         **kwargs) -> PlotFunctionCalls:
        if isinstance(features, pd.Series):
            features = pd.DataFrame(features)

        return [
            PlotFunctionCall(function=plot_function,
                             kwargs={**kwargs, 'feature': feature})
            for _, feature in features.items()
        ]
