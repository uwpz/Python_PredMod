"""Imputing of missing data"""

from typing import Any, List, Optional, Union

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer

from hmsPM.utils import (
    detect_feature_scale,
    detect_input_data_type,
)
from hmsPM.datatypes import (
    FeatureScale,
    InputDataType,
)
from hmsPM.preprocessing.base import PreprocessorMixin


class Imputer(SimpleImputer, PreprocessorMixin):
    """
    Imputes missing values of given features within the input data.

    This imputer can be used within a scikit-learn Pipeline. It uses the SimpleImputer from scikit-learn and accepts
    all keyword arguments from the SimpleImputer class. For a description of the parameters, refer to the
    scikit-learn `SimpleImputer
    documentation <https://scikit-learn.org/stable/modules/generated/sklearn.impute.SimpleImputer.html>`_.

    Additionally, this class can also be used to impute columns with values taken from
    the column at random (strategy = 'random'). Accepted imputation strategies are therefore 'mean'
    (default: strategy = 'mean'), 'median', 'most_frequent', 'constant', or 'random'.

    :param strategy: Imputation strategy ('mean', 'median', 'most_frequent', 'constant', 'random'); default = 'mean'
    :param fill_value: Value used to replace missing values for 'constant' strategy; default = 'missing_value'.
    :param column_names: List of feature names to be imputed
    """
    def __init__(self,
                 strategy: str,
                 fill_value: Optional[Union[int, float, str]] = None,
                 column_names: Optional[List[str]] = None, **kwargs):
        super().__init__(**kwargs)
        self.column_names = self._convert_column_names(column_names)
        self.strategy = strategy
        # The fill_value parameter (used as fill value for 'constant' strategy) overwrites the fill_value from the
        # SimpleImputer. This is to ensure it works with the hmsPM::ColumnTransformer.
        self.fill_value = fill_value
        self._statistics: List[Any] = []
        self._input_data_type = InputDataType.none

    def fit(self, X: Union[pd.DataFrame, pd.Series, np.ndarray], *_, **kwargs):
        """
        Fit the imputation to (specified) columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        """
        self._input_data_type = detect_input_data_type(x=X)

        df = self._convert_input_data_to_data_frame(X = X)

        valid_column_names = self._validate_column_names(df = df,
                                                         column_names = self.column_names,
                                                         input_data_type = self._input_data_type)

        df_selected = self._select_columns(df=df, column_names = valid_column_names)

        if self.strategy == 'random':
            self._statistics = self._create_random_fill_values(df=df_selected)
        else:
            if self.strategy == 'constant' and self.fill_value is None:
                feature_scale_df = detect_feature_scale(df_selected.iloc[:, 0])
                if feature_scale_df == FeatureScale.numerical:
                    self.fill_value = 0
                else:
                    self.fill_value = 'missing_value'
            super().fit(df_selected, **kwargs)
        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Perform imputation on (specified) columns of the input data

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Transformed pandas data frame, pandas series, or numpy array
        """
        df = self._convert_input_data_to_data_frame(X = X)

        valid_column_names = self._validate_column_names(df = df,
                                                         column_names = self.column_names,
                                                         input_data_type = self._input_data_type)

        df_selected = self._select_columns(df=df, column_names = valid_column_names)

        if self.strategy == 'random':
            df_imputed = self._impute_with_random_value(df=df_selected)
        else:
            df_imputed = super().transform(df_selected)

        self._set_columns(df = df, df_replace = df_imputed, column_names = valid_column_names)

        X = self._convert_data_frame_to_input_data_type(df=df, input_data_type = self._input_data_type)

        return X

    def _create_random_fill_values(self, df: pd.DataFrame) -> List[Any]:
        if self.missing_values is not None:
            # missing_values is a parameter from SimpleImputer. It enables the user to specify values that should be
            # treated as the missing values(default = np.nan) and that will therefore be imputed. Here we ensure this
            # behaviour also works for the 'random' strategy.
            df.replace(self.missing_values, np.nan)
        statistics = []
        for _, column in df.items():
            possible_values = column.dropna().unique()
            random_filler = np.random.choice(possible_values)
            statistics.append(random_filler)
        return statistics

    def _impute_with_random_value(self, df: pd.DataFrame) -> pd.DataFrame:
        missing_values = self.missing_values
        if missing_values is None:
            missing_values = np.nan
        for i_col in range(df.shape[1]):
            statistic = self._statistics[i_col]
            df.iloc[:, i_col] = df.iloc[:, i_col].replace(missing_values, statistic)
        return df
