"""Preprocessing of numerical features"""

import warnings
from math import log10
from typing import Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.base import (
    BaseEstimator,
    TransformerMixin,
)

from hmsPM.utils import (
    detect_input_data_type,
)
from hmsPM.datatypes import (
    FeatureScale,
    InputDataType
)
from hmsPM.preprocessing.base import PreprocessorMixin


class QuantileBinner(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Bins numerical columns of input data or single numerical series to quantiles.

    This transformer can be used within a scikit-learn Pipeline.

    The transformation is performed on all numerical columns of the input data by default. Alternatively, the
    user can specify the columns to be binned by using the column_names parameter; note that the
    column_names parameter only works when the input data is a pandas data frame.

    :param n_bins: Number of bins; default = 10
    :param output_format: Format of output (intervals, quantiles, or numeric); default = intervals
    :param column_names: List of column names to be binned. Can only be used when input data is a pandas data frame.
        If not specified all numerical columns will be transformed; default = None
    """
    def __init__(self,
                 n_bins: int = 10,
                 output_format: Optional[str] = 'intervals',
                 column_names: Optional[Union[str, List[str]]] = None):
        self.n_bins = n_bins
        self.column_names = self._convert_column_names(column_names)
        self.output_format = self._check_output_format(output_format = output_format)
        self._input_data_type = InputDataType.none
        self._binning_function = self._get_binning_function(output_format = self.output_format)

    def fit(self, *_):
        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Perform binning on the numerical columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Transformed pandas data frame, pandas series, or numpy array
        """
        self._input_data_type = detect_input_data_type(x = X)

        df = self._convert_input_data_to_data_frame(X = X)

        self.column_names = self._validate_column_names(df = df,
                                                        column_names = self.column_names,
                                                        feature_scale = FeatureScale.numerical,
                                                        input_data_type = self._input_data_type)

        df_selected = self._select_columns(df=df, column_names = self.column_names)

        df_transformed = df_selected.apply(self._bin_values, n_bins=self.n_bins)

        self._set_columns(df = df, df_replace = df_transformed, column_names = self.column_names)

        X = self._convert_data_frame_to_input_data_type(df=df, input_data_type = self._input_data_type)

        return X

    def _bin_values(self, x: pd.Series, n_bins: int) -> pd.Series:
        bins = self._binning_function(x=x, n_bins=n_bins)
        return bins

    @staticmethod
    def _required_precision(interval: pd.Interval) -> int:
        interval_mid = abs(interval.right + interval.left) / 2
        interval_length = (interval.right - interval.left)
        return int(np.ceil(np.log10(interval_mid / interval_length)))

    @staticmethod
    def _format_scientific(interval: pd.Interval, precision) -> str:
        return '({:.{p}e}, {:.{p}e}]'.format(interval.left, interval.right, p=precision)

    @staticmethod
    def _quantile_labels(n_labels: int) -> List[str]:
        required_digits = int(log10(n_labels))
        quantile_index = 1 + np.arange(n_labels)
        return ['q' + str(i_quantile).zfill(required_digits)
                for i_quantile in quantile_index]

    def _bin_values_to_intervals(self, x: pd.Series, n_bins: int) -> pd.Series:
        bins = pd.qcut(x = x, q = n_bins, duplicates = "drop")
        if x.max() >= 1e6:
            # Use scientific notation for large values
            intervals = pd.Series(bins.cat.categories)
            precision = intervals.apply(lambda iv: self._required_precision(iv)).max()
            bins.cat.categories = intervals.apply(lambda iv: self._format_scientific(iv, precision))
        bins = bins.astype("str").replace("nan", np.nan)
        return bins

    @staticmethod
    def _bin_values_to_numeric(x: pd.Series, n_bins: int) -> pd.Series:
        bins = pd.qcut(x = x, q = n_bins, duplicates = "drop", labels = False)
        return pd.Series(bins)

    def _bin_values_to_quantiles(self, x: pd.Series, n_bins: int) -> pd.Series:
        bins = pd.qcut(x = x, q = n_bins, duplicates = "drop")
        # Define number of labels in case n_bins < number of unique values
        n_labels = len(bins.cat.categories)
        bins.cat.categories = self._quantile_labels(n_labels)
        bins = bins.astype("str").replace("nan", np.nan)
        return bins

    @staticmethod
    def _check_output_format(output_format: Optional[str] = None) -> str:
        if output_format not in ['intervals', 'quantiles', 'numeric']:
            raise ValueError("Invalid output_format parameter, must be 'intervals', 'quantiles', or 'numeric'.")
        return output_format

    def _get_binning_function(self, output_format: str) -> Callable:
        binning_functions = {'numeric': self._bin_values_to_numeric,
                             'quantiles': self._bin_values_to_quantiles,
                             'intervals': self._bin_values_to_intervals}
        return binning_functions[output_format]


class Winsorizer(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Winsorizes numerical columns within input data to the specified quantile limits.

    This transformer can be used within a scikit-learn Pipeline.

    The winsorization is performed on all numerical columns of the input data by default. Alternatively, the
    user can specify the columns to be converted by using the column_names parameter; note that the
    column_names parameter only works when the input data is a pandas data frame.

    This class uses the lower and upper limits from the quantiles tuple parameter to winsorize each given column. If
    this parameter is not specified, clipping values will be set to (0, 1) which means the original columns will be
    returned.

    :param column_names: List of column names to be winsorized. If not specified all numerical columns will be
        transformed; default = None
    :param quantiles: Tuple of floats in the format (lower quantile, upper quantile) to be used for winsorization,
        default = None.
    """
    def __init__(self,
                 column_names: Optional[Union[str, List[str]]] = None,
                 quantiles: Optional[Union[Tuple[float, float]]] = None):
        self.column_names = self._convert_column_names(column_names)
        self.quantiles = quantiles
        self._lower_quantile: float = 0.0
        self._upper_quantile: float = 1.0
        self._statistics: dict = {}
        self._input_data_type = InputDataType.none

    def fit(self, X: Union[pd.DataFrame, pd.Series, np.ndarray], *_):
        """
        Fit the clipping values for winsorization on the (specified) numerical columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        """
        self._lower_quantile, self._upper_quantile = self._validate_quantiles(quantiles=self.quantiles)

        self._input_data_type = detect_input_data_type(x = X)

        df = self._convert_input_data_to_data_frame(X = X)

        self.column_names = self._validate_column_names(df = df,
                                                        column_names = self.column_names,
                                                        feature_scale = FeatureScale.numerical,
                                                        input_data_type = self._input_data_type)

        df_selected = self._select_columns(df=df, column_names = self.column_names)

        self._statistics = self._calculate_statistics(df=df_selected)

        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Perform winsorization on the (specified) numerical columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Transformed pandas data frame, pandas series, or numpy array
        """

        df = self._convert_input_data_to_data_frame(X = X)

        df_selected = self._select_columns(df=df, column_names = self.column_names)

        lower_limits = self._statistics["lower_limits"]
        upper_limits = self._statistics["upper_limits"]

        df_transformed = df_selected.apply(self._winsorize, lower_limits=lower_limits, upper_limits=upper_limits)

        self._set_columns(df = df, df_replace = df_transformed, column_names = self.column_names)

        X = self._convert_data_frame_to_input_data_type(df=df, input_data_type = self._input_data_type)

        return X

    def _calculate_statistics(self, df: pd.DataFrame) -> Dict[str, dict]:

        lower_limits, upper_limits = self._create_quantile_dictionaries(df)

        statistics = {"lower_limits": lower_limits,
                      "upper_limits": upper_limits}

        return statistics

    @staticmethod
    def _validate_quantiles(quantiles: Optional[Tuple[float, float]] = None) -> Tuple[float, float]:
        if quantiles is None:
            warnings.warn(
                "The quantiles parameter was not specified; original columns returned.",
                UserWarning)
            lower_quantile = 0.0
            upper_quantile = 1.0
        else:
            lower_quantile = quantiles[0]
            upper_quantile = quantiles[1]
        return lower_quantile, upper_quantile

    def _create_quantile_dictionaries(self, df: pd.DataFrame) -> Tuple[dict, dict]:

        upper_limits = df.quantile(self._upper_quantile).to_dict()
        lower_limits = df.quantile(self._lower_quantile).to_dict()

        return lower_limits, upper_limits

    @staticmethod
    def _winsorize(x: pd.Series, lower_limits: dict, upper_limits: dict) -> pd.Series:
        return x.clip(lower = lower_limits[x.name],
                      upper = upper_limits[x.name])
