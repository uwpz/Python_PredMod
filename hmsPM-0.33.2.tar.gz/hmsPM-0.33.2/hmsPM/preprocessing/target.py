"""Preprocessing of target variable"""

import warnings

import numpy as np
import pandas as pd


def encode_to_numerical_target(target: pd.Series) -> pd.Series:
    """
    Encode categorical target to numerical target.

    Categorical values are encoded numerically in the order of frequency of the class,
    with the least frequent values (minority class) encoded as the highest numerical value.

    In case of two classes the minority class is encoded as 1.

    :param target: Pandas series to be encoded
    :return: Encoded series
    """
    if np.issubdtype(target.dtype, np.number):
        warnings.warn("Input series is already of type numeric - returning original series.",
                      UserWarning)
        return target

    ordered_classes = target.value_counts().index
    range_of_levels = range(len(ordered_classes))

    class_index_recoding = {ordered_classes[i]: list(range_of_levels)[i] for i in range_of_levels}
    encoded_target = target.map(class_index_recoding)
    return encoded_target
