"""Model Metrics"""

from typing import Callable, Dict, Union

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, accuracy_score, make_scorer

from hmsPM.datatypes import TargetType


###############################################################################
# (Multiclass) Classification


def acc(y_true: np.array, y_pred: np.array) -> np.float:
    """Accuracy

    Calculate (subset) accuracy for (multiclass) classification.

    :param y_true: Ground truth target labels
    :param y_pred: Predicted target labels
    :return: Accuracy value
    """
    if y_true.ndim > 1:
        # Identify index of true label
        y_true = y_true.argmax(axis = 1)
    if y_pred.ndim > 1:
        # Identify index of predicted label
        y_pred = y_pred.argmax(axis = 1)
    return accuracy_score(y_true=y_true,
                          y_pred=y_pred)


def auc(y_true: np.array, y_score: np.array) -> np.float:
    """Area under the curve

    Calculate AUC for both classification and multiclass classification.
    Use one-vs-rest for multiclass case.

    :param y_true: Ground truth target labels
    :param y_score: Target scores
    :return: Area under the curve value
    """
    if y_score.ndim == 2 and y_score.shape[1] == 2:
        # Extract scores of true-label
        y_score = y_score[:, 1]
    return roc_auc_score(y_true=y_true,
                         y_score=y_score,
                         multi_class="ovr")


def rmse(y_true: np.array, y_pred: np.array) -> np.float:
    """Root mean square error

    :param y_true: Ground truth target labels
    :param y_pred: Predicted target labels
    :return: Root mean square error value
    """
    return np.sqrt(np.mean(np.power(y_true - y_pred, 2)))


###############################################################################
# Regression


def spear(y_true: np.array, y_pred: np.array) -> np.float:
    """Spearman correlation coefficient

    :param y_true: Ground truth target labels
    :param y_pred: Predicted target labels
    :return: Spearman correlation coefficient value
    """
    return (pd.DataFrame({"y_true": y_true, "y_pred": y_pred})
              .corr(method = "spearman")
              .values[0, 1])


def scorer(target_type: Union[TargetType, str]) -> Dict[str, Callable]:
    """Scorer for evaluation metrics

    Select evaluation metrics scorer for given target type.

    :param target_type: Target type
    :return: Dictionary of scorer functions
    """
    scorers = {
        TargetType.classification: {
            "auc": make_scorer(auc, greater_is_better=True, needs_proba=True),
            "acc": make_scorer(acc, greater_is_better=True)},
        TargetType.multiclass: {
            "auc": make_scorer(auc, greater_is_better=True, needs_proba=True),
            "acc": make_scorer(acc, greater_is_better=True)},
        TargetType.regression: {
            "spear": make_scorer(spear, greater_is_better=True),
            "rmse": make_scorer(rmse, greater_is_better=False)}
    }
    return scorers[TargetType(target_type)]
