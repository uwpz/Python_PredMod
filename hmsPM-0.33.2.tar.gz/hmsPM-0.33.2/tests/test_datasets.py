"""Tests for `hmsPM` example data"""

import numpy as np
import pandas as pd
import pytest
from pandas.testing import (
    assert_series_equal,
    assert_index_equal
)

from hmsPM.datasets import (
    load_dataset,
    load_titanic,
    load_ameshousing,
)


###############################################################################
# Tests of load_dataset


def test_load_dataset_loads_titanic_data_with_correct_column_names():
    expected_columns = pd.Index(['pclass', 'survived', 'name', 'sex', 'age', 'sibsp', 'parch', 'ticket', 'fare',
                                 'cabin', 'embarked', 'boat', 'body', 'home.dest'])
    loaded_data = load_dataset(name='titanic')
    assert_index_equal(loaded_data.columns, expected_columns)


def test_load_dataset_loads_ameshousing_data_with_column_names():
    expected_columns = pd.Index(['Order', 'PID', 'MS_SubClass', 'MS_Zoning', 'Lot_Frontage', 'Lot_Area',
                                 'Street', 'Alley', 'Lot_Shape', 'Land_Contour', 'Utilities', 'Lot_Config',
                                 'Land_Slope', 'Neighborhood', 'Condition_1', 'Condition_2', 'Bldg_Type', 'House_Style',
                                 'Overall_Qual', 'Overall_Cond', 'Year_Built', 'Year_RemodAdd', 'Roof_Style',
                                 'Roof_Matl', 'Exterior_1st', 'Exterior_2nd', 'Mas_Vnr_Type', 'Mas_Vnr_Area',
                                 'Exter_Qual', 'Exter_Cond', 'Foundation', 'Bsmt_Qual', 'Bsmt_Cond', 'Bsmt_Exposure',
                                 'BsmtFin_Type_1', 'BsmtFin_SF_1', 'BsmtFin_Type_2', 'BsmtFin_SF_2', 'Bsmt_Unf_SF',
                                 'Total_Bsmt_SF', 'Heating', 'Heating_QC', 'Central_Air', 'Electrical', 'first_Flr_SF',
                                 'second_Flr_SF', 'Low_Qual_Fin_SF', 'Gr_Liv_Area', 'Bsmt_Full_Bath', 'Bsmt_Half_Bath',
                                 'Full_Bath', 'Half_Bath', 'Bedroom_AbvGr', 'Kitchen_AbvGr', 'Kitchen_Qual',
                                 'TotRms_AbvGrd', 'Functional', 'Fireplaces', 'Fireplace_Qu', 'Garage_Type',
                                 'Garage_Yr_Blt', 'Garage_Finish', 'Garage_Cars', 'Garage_Area', 'Garage_Qual',
                                 'Garage_Cond', 'Paved_Drive', 'Wood_Deck_SF', 'Open_Porch_SF', 'Enclosed_Porch',
                                 'threeSsn_Porch', 'Screen_Porch', 'Pool_Area', 'Pool_QC', 'Fence', 'Misc_Feature',
                                 'Misc_Val', 'Mo_Sold', 'Yr_Sold', 'Sale_Type', 'Sale_Condition', 'SalePrice',
                                 'SalePrice_Category'])
    loaded_data = load_dataset(name='ameshousing')
    assert_index_equal(loaded_data.columns, expected_columns)


def test_load_dataset_raises_key_error_for_unknown_dataset():
    with pytest.raises(KeyError) as exec_info:
        load_dataset(name='unknown_dataset')

    assert exec_info.value.args[0] == 'Unknown dataset unknown_dataset. Available datasets are titanic, ameshousing.'


###############################################################################
# Tests of load_titanic


def test_load_titanic_loads_data_with_correct_dtypes():
    columns = pd.Series(['pclass', 'survived', 'name', 'sex', 'age', 'sibsp', 'parch', 'ticket', 'fare', 'cabin',
                         'embarked', 'boat', 'body', 'home.dest'])
    expected_dtypes = pd.Series([np.object, np.int64, np.object, np.object, np.float64, np.int64, np.int64, np.object,
                                 np.float64, np.object, np.object, np.object, np.float64, np.object], index=columns)
    loaded_data = load_titanic()
    assert_series_equal(loaded_data.dtypes, expected_dtypes)


def test_load_titanic_loads_data_with_correct_column_names():
    expected_columns = pd.Index(['pclass', 'survived', 'name', 'sex', 'age', 'sibsp', 'parch', 'ticket', 'fare',
                                 'cabin', 'embarked', 'boat', 'body', 'home.dest'])
    loaded_data = load_titanic()
    assert_index_equal(loaded_data.columns, expected_columns)


###############################################################################
# Tests of load_ameshousing


def test_load_ameshousing_loads_data_with_correct_dtypes():
    columns = pd.Series(['Order', 'PID', 'MS_SubClass', 'MS_Zoning', 'Lot_Frontage', 'Lot_Area', 'Street',
                         'Alley', 'Lot_Shape', 'Land_Contour', 'Utilities', 'Lot_Config', 'Land_Slope', 'Neighborhood',
                         'Condition_1', 'Condition_2', 'Bldg_Type', 'House_Style', 'Overall_Qual', 'Overall_Cond',
                         'Year_Built', 'Year_RemodAdd', 'Roof_Style', 'Roof_Matl', 'Exterior_1st', 'Exterior_2nd',
                         'Mas_Vnr_Type', 'Mas_Vnr_Area', 'Exter_Qual', 'Exter_Cond', 'Foundation', 'Bsmt_Qual',
                         'Bsmt_Cond', 'Bsmt_Exposure', 'BsmtFin_Type_1', 'BsmtFin_SF_1', 'BsmtFin_Type_2',
                         'BsmtFin_SF_2', 'Bsmt_Unf_SF', 'Total_Bsmt_SF', 'Heating', 'Heating_QC', 'Central_Air',
                         'Electrical', 'first_Flr_SF', 'second_Flr_SF', 'Low_Qual_Fin_SF', 'Gr_Liv_Area',
                         'Bsmt_Full_Bath', 'Bsmt_Half_Bath', 'Full_Bath', 'Half_Bath', 'Bedroom_AbvGr', 'Kitchen_AbvGr',
                         'Kitchen_Qual', 'TotRms_AbvGrd', 'Functional', 'Fireplaces', 'Fireplace_Qu', 'Garage_Type',
                         'Garage_Yr_Blt', 'Garage_Finish', 'Garage_Cars', 'Garage_Area', 'Garage_Qual', 'Garage_Cond',
                         'Paved_Drive', 'Wood_Deck_SF', 'Open_Porch_SF', 'Enclosed_Porch', 'threeSsn_Porch',
                         'Screen_Porch', 'Pool_Area', 'Pool_QC', 'Fence', 'Misc_Feature', 'Misc_Val', 'Mo_Sold',
                         'Yr_Sold', 'Sale_Type', 'Sale_Condition', 'SalePrice', 'SalePrice_Category'])
    expected_dtypes = pd.Series([np.int64, np.int64, np.int64, np.object, np.float64, np.int64, np.object, np.object,
                                 np.object, np.object, np.object, np.object, np.object, np.object, np.object, np.object,
                                 np.object, np.object, np.int64, np.int64, np.int64, np.int64, np.object, np.object,
                                 np.object, np.object, np.object, np.float64, np.object, np.object, np.object,
                                 np.object, np.object, np.object, np.object, np.float64, np.object, np.float64,
                                 np.float64, np.float64, np.object, np.object, np.object, np.object, np.int64, np.int64,
                                 np.int64, np.int64, np.float64, np.float64, np.int64, np.int64, np.int64, np.int64,
                                 np.object, np.int64, np.object, np.int64, np.object, np.object, np.float64, np.object,
                                 np.float64, np.float64, np.object, np.object, np.object, np.int64, np.int64, np.int64,
                                 np.int64, np.int64, np.int64, np.object, np.object, np.object, np.int64, np.int64,
                                 np.int64, np.object, np.object, np.int64, np.object], index=columns)
    loaded_data = load_ameshousing()
    assert_series_equal(loaded_data.dtypes, expected_dtypes)


def test_load_ameshousing_loads_data_with_column_names():
    expected_columns = pd.Index(['Order', 'PID', 'MS_SubClass', 'MS_Zoning', 'Lot_Frontage', 'Lot_Area',
                                 'Street', 'Alley', 'Lot_Shape', 'Land_Contour', 'Utilities', 'Lot_Config',
                                 'Land_Slope', 'Neighborhood', 'Condition_1', 'Condition_2', 'Bldg_Type', 'House_Style',
                                 'Overall_Qual', 'Overall_Cond', 'Year_Built', 'Year_RemodAdd', 'Roof_Style',
                                 'Roof_Matl', 'Exterior_1st', 'Exterior_2nd', 'Mas_Vnr_Type', 'Mas_Vnr_Area',
                                 'Exter_Qual', 'Exter_Cond', 'Foundation', 'Bsmt_Qual', 'Bsmt_Cond', 'Bsmt_Exposure',
                                 'BsmtFin_Type_1', 'BsmtFin_SF_1', 'BsmtFin_Type_2', 'BsmtFin_SF_2', 'Bsmt_Unf_SF',
                                 'Total_Bsmt_SF', 'Heating', 'Heating_QC', 'Central_Air', 'Electrical', 'first_Flr_SF',
                                 'second_Flr_SF', 'Low_Qual_Fin_SF', 'Gr_Liv_Area', 'Bsmt_Full_Bath', 'Bsmt_Half_Bath',
                                 'Full_Bath', 'Half_Bath', 'Bedroom_AbvGr', 'Kitchen_AbvGr', 'Kitchen_Qual',
                                 'TotRms_AbvGrd', 'Functional', 'Fireplaces', 'Fireplace_Qu', 'Garage_Type',
                                 'Garage_Yr_Blt', 'Garage_Finish', 'Garage_Cars', 'Garage_Area', 'Garage_Qual',
                                 'Garage_Cond', 'Paved_Drive', 'Wood_Deck_SF', 'Open_Porch_SF', 'Enclosed_Porch',
                                 'threeSsn_Porch', 'Screen_Porch', 'Pool_Area', 'Pool_QC', 'Fence', 'Misc_Feature',
                                 'Misc_Val', 'Mo_Sold', 'Yr_Sold', 'Sale_Type', 'Sale_Condition', 'SalePrice',
                                 'SalePrice_Category'])
    loaded_data = load_ameshousing()
    assert_index_equal(loaded_data.columns, expected_columns)
