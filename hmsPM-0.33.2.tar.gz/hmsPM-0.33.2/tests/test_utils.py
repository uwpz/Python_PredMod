"""Tests for `hmsPM` utility functions"""

import pytest

import numpy as np
import pandas as pd

from hmsPM.utils import (
    detect_feature_scale,
    detect_target_type,
    get_fields,
    check_fields,
)
from hmsPM.datatypes import FeatureScale, TargetType


###############################################################################
# Tests of detect_feature_scale


def test_detect_feature_scale_detects_int_as_numerical():
    numerical_input_series = pd.Series([1, 2, 3, 4])
    expected_output = FeatureScale.numerical

    feature_type = detect_feature_scale(numerical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_float_as_numerical():
    numerical_input_series = pd.Series([1.1, 2.2, 3.3, 4.4])
    expected_output = FeatureScale.numerical

    feature_type = detect_feature_scale(numerical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_int_as_numerical_for_np_array():
    numerical_input_series = np.array([1, 2, 3, 4])
    expected_output = FeatureScale.numerical

    feature_type = detect_feature_scale(numerical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_int_as_numerical_if_has_missing():
    numerical_input_series = np.array([1, 2, 3, np.nan])
    expected_output = FeatureScale.numerical

    feature_type = detect_feature_scale(numerical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_string_as_categorical():
    categorical_input_series = pd.Series(['a', 'b', 'c', 'd'])
    expected_output = FeatureScale.categorical

    feature_type = detect_feature_scale(categorical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_string_as_categorical_if_has_missing():
    categorical_input_series = pd.Series(['a', 'b', 'c', np.nan])
    expected_output = FeatureScale.categorical

    feature_type = detect_feature_scale(categorical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_boolean_as_categorical():
    categorical_input_series = pd.Series([True, False, False, False])
    expected_output = FeatureScale.categorical

    feature_type = detect_feature_scale(categorical_input_series)

    assert feature_type == expected_output


def test_detect_feature_scale_detects_mixed_as_categorical():
    categorical_input_series = pd.Series([1, 2, '3', '4'])
    expected_output = FeatureScale.categorical

    feature_type = detect_feature_scale(categorical_input_series)

    assert feature_type == expected_output


###############################################################################
# Tests of detect_target_type


def test_detect_target_type_detects_classification_target_for_numerical_numpy_array_input():
    classification_input_series = np.array([1, 2, 1, 1])
    expected_output = TargetType.classification

    target_type = detect_target_type(classification_input_series)

    assert target_type == expected_output


def test_detect_target_type_detects_classification_target_for_numerical_input():
    classification_input_series = pd.Series([1, 2, 1, 1])
    expected_output = TargetType.classification

    target_type = detect_target_type(classification_input_series)

    assert target_type == expected_output


def test_detect_target_type_detects_multiclass_classification_target_for_numerical_input():
    multiclass_classification_input_series = pd.Series([1, 2, 3, 4])
    expected_output = TargetType.multiclass

    target_type = detect_target_type(multiclass_classification_input_series)

    assert target_type == expected_output


def test_detect_target_type_detects_classification_target_for_string_input():
    classification_input_series = pd.Series(['a', 'b', 'a', 'a'])
    expected_output = TargetType.classification

    target_type = detect_target_type(classification_input_series)

    assert target_type == expected_output


def test_detect_target_type_detects_multiclass_classification_target_for_string_input():
    multiclass_classification_input_series = pd.Series(['a', 'b', 'c', 'd'])
    expected_output = TargetType.multiclass

    target_type = detect_target_type(multiclass_classification_input_series)

    assert target_type == expected_output


def test_detect_target_type_detects_regression_target():
    regression_input_series = pd.Series(range(11))
    expected_output = TargetType.regression

    target_type = detect_target_type(regression_input_series)

    assert target_type == expected_output


def test_detect_target_type_raises_error_for_zero_variance_input_series():
    zero_variance_input_series = pd.Series([1, 1, 1, 1])
    with pytest.raises(ValueError) as exception_info:
        detect_target_type(zero_variance_input_series)

    assert exception_info.value.args[0] == "Target variable has zero variance."


def test_detect_target_type_detects_classification_target_if_input_has_missings():
    classification_input_series = pd.Series([1, 2, np.nan, 1])
    expected_output = TargetType.classification

    target_type = detect_target_type(classification_input_series)

    assert target_type == expected_output


###############################################################################
# Tests of field utilities


def test_get_fields_retrieves_key_names_from_dictionary():
    d = {'col1': [1, 2, 3], 'col2': [4, 5, 6]}
    expected_field_names = ['col1', 'col2']

    assert get_fields(d) == expected_field_names


def test_get_fields_retrieves_column_names_from_pandas_data_frame():
    df = pd.DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]})
    expected_field_names = ['col1', 'col2']

    assert get_fields(df) == expected_field_names


def test_get_fields_raises_type_error_for_unsupported_data_types():
    d = [1, 2, 3]
    with pytest.raises(TypeError) as exception_info:
        check_fields(data=d, fields=['col1', 'col2', 'col3'])

    assert exception_info.value.args[0] == "Unsupported data type <class 'list'>"


def test_check_fields_raises_key_error_with_variable_name_for_single_missing_field_in_dictionary():
    d = {'col1': [1, 2, 3], 'col2': [4, 5, 6]}
    with pytest.raises(KeyError) as exception_info:
        check_fields(data=d, fields=['col1', 'col2', 'col3'], var_name='d')

    assert exception_info.value.args[0] == "Field col3 is missing in d (<class 'dict'>)"


def test_check_fields_raises_key_error_for_multiple_missing_fields_in_dictionary():
    d = {'col1': [1, 2, 3], 'col2': [4, 5, 6]}
    with pytest.raises(KeyError) as exception_info:
        check_fields(data=d, fields=['col1', 'col2', 'col3', 'col4'])

    assert exception_info.value.args[0] == "Fields col3, col4 are missing in (<class 'dict'>)"


def test_check_fields_raises_key_error_with_variable_name_for_missing_fields_in_pandas_data_frame():
    df = pd.DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]})
    with pytest.raises(KeyError) as exception_info:
        check_fields(data=df, fields=['col1', 'col2', 'col3'], var_name='df')

    assert exception_info.value.args[0] == "Field col3 is missing in df (<class 'pandas.core.frame.DataFrame'>)"


def test_check_fields_raises_key_error_for_multiple_missing_fields_in_pandas_data_frame():
    df = pd.DataFrame({'col1': [1, 2, 3], 'col2': [4, 5, 6]})
    with pytest.raises(KeyError) as exception_info:
        check_fields(data=df, fields=['col1', 'col2', 'col3', 'col4'])

    assert exception_info.value.args[0] == "Fields col3, col4 are missing in (<class 'pandas.core.frame.DataFrame'>)"
