import pytest

from hmsPM.plotting.performance import (
    ROCCurve,
    ConfusionMatrix,
    PredictionDistribution,
    PredictionCalibration,
    PrecisionRecallCurveClassification,
    PrecisionCurveClassification,
    ObservedDistributionRegression,
    ResidualsDistributionRegression,
    AbsoluteResidualsDistributionRegression,
    RelativeResidualsDistributionRegression,
    MetricsMulticlass,
    TrueLabelsMulticlass,
    PredictedLabelsMulticlass,
    MultiPerformancePlotter,
)
from hmsPM.datatypes import PerformanceMeasure
from tests.plotting.utils import remove_file, file_tester


###############################################################################
# Tests for classification target


def test_roc_curve_creates_plot_for_classification_target(
        titanic_numerical_classification_scores, titanic_classification_target_numerical):
    plotter = ROCCurve()
    ax = plotter.plot(y = titanic_classification_target_numerical, y_hat = titanic_numerical_classification_scores)
    assert ax.xaxis.get_label_text() == "fpr: P($\\^y$=1|$y$=0)"
    assert ax.yaxis.get_label_text() == "tpr: P($\\^y$=1|$y$=1)"


def test_confusion_matrix_creates_plot_for_classification_target(
        titanic_numerical_classification_scores, titanic_classification_target_numerical):
    plotter = ConfusionMatrix()
    ax = plotter.plot(y = titanic_classification_target_numerical, y_hat = titanic_numerical_classification_scores)
    assert ax.xaxis.get_label_text() == "Predicted label"
    assert ax.yaxis.get_label_text() == "True label"


def test_prediction_distribution_creates_plot_for_classification_target(
        titanic_numerical_classification_scores, titanic_classification_target_numerical):
    plotter = PredictionDistribution()
    ax = plotter.plot(y = titanic_classification_target_numerical, y_hat = titanic_numerical_classification_scores)
    assert ax.xaxis.get_label_text() == r"Predictions ($\^y$)"
    assert ax.yaxis.get_label_text() == "Density"


def test_prediction_calibration_creates_plot_for_classification_target(
        titanic_numerical_classification_scores, titanic_classification_target_numerical):
    plotter = PredictionCalibration()
    ax = plotter.plot(y = titanic_classification_target_numerical, y_hat = titanic_numerical_classification_scores)
    assert ax.xaxis.get_label_text() == r"$\bar{\^y}$ in $\^y$-bin"
    assert ax.yaxis.get_label_text() == r"$\bar{y}$ in $\^y$-bin"


def test_precision_recall_curve_creates_plot(
        titanic_numerical_classification_scores, titanic_classification_target_numerical):
    plotter = PrecisionRecallCurveClassification()
    ax = plotter.plot(y = titanic_classification_target_numerical, y_hat = titanic_numerical_classification_scores)
    assert ax.xaxis.get_label_text() == r"recall=tpr: P($\^y$=1|$y$=1)"
    assert ax.yaxis.get_label_text() == r"precision: P($y$=1|$\^y$=1)"


def test_precision_curve_creates_plot(
        titanic_numerical_classification_scores, titanic_classification_target_numerical):
    plotter = PrecisionCurveClassification()
    ax = plotter.plot(y = titanic_classification_target_numerical, y_hat = titanic_numerical_classification_scores)
    assert ax.xaxis.get_label_text() == "% Samples Tested"
    assert ax.yaxis.get_label_text() == r"precision: P($y$=1|$\^y$=1)"


###############################################################################
# Tests for regression target

def test_calibration_creates_plot_for_regression_target(
        ameshousing_regression_target, ameshousing_regression_scores):
    plotter = PredictionCalibration()
    ax = plotter.plot(y = ameshousing_regression_target, y_hat = ameshousing_regression_scores)
    assert ax.xaxis.get_label_text() == r"$\bar{\^y}$ in $\^y$-bin"
    assert ax.yaxis.get_label_text() == r"$\bar{y}$ in $\^y$-bin"


def test_prediction_distribution_creates_plot_for_regression_target(
        ameshousing_regression_target, ameshousing_regression_scores):
    plotter = PredictionDistribution()
    ax = plotter.plot(y = ameshousing_regression_target, y_hat = ameshousing_regression_scores)
    assert ax.xaxis.get_label_text() == ""
    assert ax.yaxis.get_label_text() == "density"


def test_regression_observed_distribution_creates_plot(
        ameshousing_regression_target, ameshousing_regression_scores):
    plotter = ObservedDistributionRegression()
    ax = plotter.plot(y = ameshousing_regression_target, y_hat = ameshousing_regression_scores)
    assert ax.xaxis.get_label_text() == r"$\^y$"
    assert ax.yaxis.get_label_text() == "y"


def test_regression_residuals_distribution_creates_plot(
        ameshousing_regression_target, ameshousing_regression_scores):
    plotter = ResidualsDistributionRegression()
    ax = plotter.plot(y = ameshousing_regression_target, y_hat = ameshousing_regression_scores)
    assert ax.xaxis.get_label_text() == r"$\^y$"
    assert ax.yaxis.get_label_text() == r"y-$\^y$"


def test_regression_absolute_residuals_distribution_creates_plot(
        ameshousing_regression_target, ameshousing_regression_scores):
    plotter = AbsoluteResidualsDistributionRegression()
    ax = plotter.plot(y = ameshousing_regression_target, y_hat = ameshousing_regression_scores)
    assert ax.xaxis.get_label_text() == r"$\^y$"
    assert ax.yaxis.get_label_text() == r"|y-$\^y$|"


def test_regression_relative_residuals_distribution_creates_plot(
        ameshousing_regression_target, ameshousing_regression_scores):
    plotter = RelativeResidualsDistributionRegression()
    ax = plotter.plot(y = ameshousing_regression_target, y_hat = ameshousing_regression_scores)
    assert ax.xaxis.get_label_text() == r"$\^y$"
    assert ax.yaxis.get_label_text() == r"|y-$\^y$|/|y|"


###############################################################################
# Tests for multiclass target


def test_roc_curve_creates_plot_for_multiclass_target(
        ameshousing_string_multiclass_scores, ameshousing_multiclass_target_string):
    plotter = ROCCurve()
    ax = plotter.plot(y = ameshousing_multiclass_target_string, y_hat = ameshousing_string_multiclass_scores)
    assert ax.xaxis.get_label_text() == r"fpr: P($\^y$=1|$y$=0)"
    assert ax.yaxis.get_label_text() == r"tpr: P($\^y$=1|$y$=1)"


def test_prediction_calibration_creates_plot_for_multiclass_target(
        ameshousing_string_multiclass_scores, ameshousing_multiclass_target_string):
    plotter = PredictionCalibration()
    ax = plotter.plot(y = ameshousing_multiclass_target_string, y_hat = ameshousing_string_multiclass_scores)
    assert ax.xaxis.get_label_text() == r"$\bar{\^y}$ in $\^y$-bin"
    assert ax.yaxis.get_label_text() == r"$\bar{y}$ in $\^y$-bin"


def test_confusion_matrix_creates_plot_for_multiclass_target(
        ameshousing_string_multiclass_scores, ameshousing_multiclass_target_string):
    plotter = ConfusionMatrix()
    ax = plotter.plot(y = ameshousing_multiclass_target_string, y_hat = ameshousing_string_multiclass_scores)
    assert ax.xaxis.get_label_text() == "Predicted label (#: %)"
    assert ax.yaxis.get_label_text() == "True label (#: %)"


def test_multiclass_model_matrix_creates_plot(
        ameshousing_string_multiclass_scores, ameshousing_multiclass_target_string):
    plotter = MetricsMulticlass()
    ax = plotter.plot(y = ameshousing_multiclass_target_string, y_hat = ameshousing_string_multiclass_scores)
    assert ax.xaxis.get_label_text() == "True label"
    assert ax.yaxis.get_label_text() == ""


def test_multiclass_barplot_true_creates_plot(
        ameshousing_string_multiclass_scores, ameshousing_multiclass_target_string):
    plotter = TrueLabelsMulticlass()
    ax = plotter.plot(y = ameshousing_multiclass_target_string, y_hat = ameshousing_string_multiclass_scores)
    assert ax.xaxis.get_label_text() == "Predicted label"
    assert ax.yaxis.get_label_text() == ""


def test_multiclass_barplot_predicted_creates_plot(
        ameshousing_string_multiclass_scores, ameshousing_multiclass_target_string):
    plotter = PredictedLabelsMulticlass()
    ax = plotter.plot(y = ameshousing_multiclass_target_string, y_hat = ameshousing_string_multiclass_scores)
    assert ax.xaxis.get_label_text() == ""
    assert ax.yaxis.get_label_text() == "True label"


###############################################################################
# Tests of MultiPerformancePlotter


def test_multi_performance_plotter_creates_pdf_for_numerical_classification_target(
        titanic_classification_target_numerical, titanic_numerical_classification_scores):
    file_path = 'performance_plots_for_numerical_classification_target.pdf'
    remove_file(file_path)
    plotter = MultiPerformancePlotter()
    plotter.plot(y = titanic_classification_target_numerical,
                 y_hat = titanic_numerical_classification_scores,
                 file_path = file_path)
    file_tester(file_path)


def test_multi_performance_plotter_creates_pdf_for_string_classification_target(
        titanic_classification_target_string, titanic_string_classification_scores):
    file_path = 'performance_plots_for_string_classification_target.pdf'
    remove_file(file_path)
    plotter = MultiPerformancePlotter()
    plotter.plot(y = titanic_classification_target_string,
                 y_hat = titanic_string_classification_scores,
                 file_path = file_path)
    file_tester(file_path)


def test_multi_performance_plotter_creates_pdf_for_regression_target(
        ameshousing_regression_target, ameshousing_regression_scores):
    file_path = 'performance_plots_for_regression_target.pdf'
    remove_file(file_path)
    plotter = MultiPerformancePlotter()
    plotter.plot(y = ameshousing_regression_target,
                 y_hat = ameshousing_regression_scores,
                 file_path = file_path)
    file_tester(file_path)


def test_multi_performance_plotter_creates_pdf_for_string_multiclass_target(
        ameshousing_multiclass_target_string, ameshousing_string_multiclass_scores):
    file_path = 'performance_plots_for_string_multiclass_target.pdf'
    remove_file(file_path)
    plotter = MultiPerformancePlotter()
    plotter.plot(y = ameshousing_multiclass_target_string,
                 y_hat = ameshousing_string_multiclass_scores,
                 file_path = file_path)
    file_tester(file_path)


def test_multi_performance_plotter_creates_pdf_for_numerical_multiclass_target(
        ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels,
        ameshousing_numerical_multiclass_scores):
    file_path = 'performance_plots_for_numerical_multiclass_target.pdf'
    remove_file(file_path)
    plotter = MultiPerformancePlotter()
    plotter.plot(y = ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels,
                 y_hat = ameshousing_numerical_multiclass_scores,
                 file_path = file_path)
    file_tester(file_path)


def test_multi_performance_plotter_create_correct_plots_for_specified_measures(
        ameshousing_multiclass_target_string, ameshousing_string_multiclass_scores):
    plotter = MultiPerformancePlotter()
    ax = plotter.plot(y = ameshousing_multiclass_target_string,
                      y_hat = ameshousing_string_multiclass_scores,
                      measures = [PerformanceMeasure.calibration, PerformanceMeasure.roc_curve])
    assert ax[0].axes[0][0].get_title() == "Calibration"
    assert ax[0].axes[0][1].get_title() == "ROC\n($AUC_{mean}$ = 0.62, $AUC_{weighted}$ = 0.62)"
    assert ax[0].axes[0][2].get_title() == ""


def test_multi_performance_plotter_raises_error_for_unsupported_measure_for_target_type(
        ameshousing_multiclass_target_string, ameshousing_string_multiclass_scores):
    plotter = MultiPerformancePlotter()
    with pytest.raises(ValueError) as exception_info:
        plotter.plot(y = ameshousing_multiclass_target_string,
                     y_hat = ameshousing_string_multiclass_scores,
                     measures = [PerformanceMeasure.residuals_fitted])

    assert exception_info.value.args[0] == "Unsupported measure choice for target type."
