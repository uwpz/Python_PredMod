import numpy as np
import pandas as pd
import pytest
import seaborn as sns
from random import choices, sample

from hmsPM.datatypes import TargetType
from hmsPM.calculation.feature_importance import UnivariateFeatureImportanceCalculator
from hmsPM.plotting.distribution import (
    MultiFeatureDistributionPlotter,
    FeatureDistributionPlotterCategoricalClassification,
    FeatureDistributionPlotterCategoricalRegression,
    FeatureDistributionPlotterNumericalClassification,
    FeatureDistributionPlotterNumericalRegression,
)
from hmsPM.utils import detect_target_type
from .utils import remove_file, file_tester


###############################################################################
# Tests of FeatureDistributionPlotterCategoricalClassification


def test_feature_distribution_plotter_categorical_classification_creates_plot(
        titanic_features, titanic_classification_target_numerical):
    plotter = FeatureDistributionPlotterCategoricalClassification()
    ax = plotter.plot(feature = titanic_features.loc[:, 'pclass'], target = titanic_classification_target_numerical)
    assert ax.xaxis.get_label_text() == "mean(survived)"
    assert ax.yaxis.get_label_text() == ""


###############################################################################
# Tests of FeatureDistributionPlotterNumericalClassification


def test_feature_distribution_plotter_numerical_classification_creates_plot(
        titanic_features, titanic_classification_target_numerical):
    plotter = FeatureDistributionPlotterNumericalClassification()
    ax = plotter.plot(feature = titanic_features.loc[:, 'fare'], target = titanic_classification_target_numerical)
    assert ax.xaxis.get_label_text() == "fare (NA: 0.1%)"
    assert ax.yaxis.get_label_text() == "density"


def test_feature_distribution_plotter_numerical_classification_creates_plot_with_rounded_na_ratio():
    n = 1000000
    feature = pd.Series(choices(range(10), k=n), name='feature')
    index_to_remove = sample(range(n), k=6666)
    feature.iloc[index_to_remove] = np.nan
    target = pd.Series(choices(range(10), k=n))
    plotter = FeatureDistributionPlotterNumericalClassification()
    ax = plotter.plot(feature = feature, target = target)
    assert ax.xaxis.get_label_text() == "feature (NA: 0.7%)"


###############################################################################
# Tests of FeatureDistributionPlotterCategoricalRegression


def test_feature_distribution_plotter_categorical_regression_creates_plot(
        ameshousing_features, ameshousing_regression_target):
    plotter = FeatureDistributionPlotterCategoricalRegression()
    ax = plotter.plot(feature = ameshousing_features.loc[:, 'Sale_Type'], target = ameshousing_regression_target)
    assert ax.xaxis.get_label_text() == "SalePrice"
    assert ax.yaxis.get_label_text() == "Sale_Type"


###############################################################################
# Tests of FeatureDistributionPlotterNumericalRegression


def test_feature_distribution_plotter_numerical_regression_creates_plot(
        ameshousing_features, ameshousing_regression_target):
    plotter = FeatureDistributionPlotterNumericalRegression()
    ax = plotter.plot(feature = ameshousing_features.loc[:, 'Lot_Frontage'], target = ameshousing_regression_target)
    assert ax.xaxis.get_label_text() == "Lot_Frontage (NA: 16.7%)"
    assert ax.yaxis.get_label_text() == "SalePrice"


###############################################################################
# Tests of MultiFeatureDistributionPlotter


def test_multi_feature_distribution_plotter_creates_pdf_with_single_plot_for_single_feature(
        titanic_features, titanic_classification_target_numerical):
    file_path = 'distribution_plot_for_single_feature.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=titanic_features.iloc[:, [0]],
                 target=titanic_classification_target_numerical,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_multiple_plots_on_one_page(
        titanic_features, titanic_classification_target_numerical):
    file_path = 'distribution_plots_for_multiple_features_on_one_page.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.n_rows = 1
    plotter.n_cols = 2
    plotter.plot(features=titanic_features,
                 target=titanic_classification_target_numerical,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_for_incorrect_pdf_file_extension(
        titanic_features, titanic_classification_target_numerical):
    file_path = 'distribution_plot_for_incorrect_pdf_file_extension'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=titanic_features.iloc[:, [0]],
                 target=titanic_classification_target_numerical,
                 file_path=file_path)
    expected_file_path = 'distribution_plot_for_incorrect_pdf_file_extension.pdf'
    file_tester(expected_file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_classification_plots_for_numerical_levels_without_varimps(
        titanic_features, titanic_classification_target_numerical):
    file_path = 'distribution_plots_for_classification_numerical.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=titanic_features.iloc[:, [0, 2]],
                 target=titanic_classification_target_numerical,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_classification_plots_for_string_levels_without_varimps(
        titanic_features, titanic_classification_target_string):
    file_path = 'distribution_plots_for_classification_string.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=titanic_features.iloc[:, [0, 2]],
                 target=titanic_classification_target_string,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_regression_plots_without_varimps(
        ameshousing_features, ameshousing_regression_target):
    file_path = 'distribution_plots_for_regression.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_regression_target,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_multiclass_plots_for_string_levels_without_varimps(
        ameshousing_features, ameshousing_multiclass_target_string):
    file_path = 'distribution_plots_for_multiclass_string.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_multiclass_target_string,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_multiclass_plots_for_numerical_levels_without_varimps(
        ameshousing_features, ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels):
    file_path = 'distribution_plots_for_multiclass_numerical.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_multiclass_plots_for_overwritten_target_type(
        ameshousing_features, ameshousing_multiclass_target_numerical_with_more_than_ten_levels):
    file_path = 'distribution_plots_for_multiclass_with_overwritten_target_type.pdf'
    remove_file(file_path)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_multiclass_target_numerical_with_more_than_ten_levels,
                 target_type=TargetType.multiclass,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_warns_if_insufficient_color_levels(
        ameshousing_features, ameshousing_multiclass_target_string):
    with pytest.warns(UserWarning) as record:
        plotter = MultiFeatureDistributionPlotter()
        plotter.colors = sns.color_palette("hls", 3)
        plotter.plot(features=ameshousing_features,
                     target=ameshousing_multiclass_target_string)

    assert record[0].message.args[0] == "Insufficient color levels for number of classes - change color palette."


def test_multi_feature_distribution_plotter_warns_if_insufficient_color_levels_and_more_than_ten_levels(
        ameshousing_features, ameshousing_multiclass_target_numerical_with_more_than_ten_levels):
    with pytest.warns(UserWarning) as record:
        plotter = MultiFeatureDistributionPlotter()
        plotter.plot(features=ameshousing_features,
                     target=ameshousing_multiclass_target_numerical_with_more_than_ten_levels,
                     target_type=TargetType.multiclass)

    assert record[1].message.args[0] == ("Insufficient color levels for number of classes "
                                         "- use sequential color palette.")


def test_multi_feature_distribution_plotter_warns_if_multiclass_target_type_for_detected_classification(
        titanic_features, titanic_classification_target_numerical):
    with pytest.warns(UserWarning) as record:
        plotter = MultiFeatureDistributionPlotter()
        plotter.plot(features=titanic_features,
                     target=titanic_classification_target_numerical,
                     target_type=TargetType.multiclass)

    assert record[0].message.args[0] == ("Input target type 'multiclass' but only two classes detected; "
                                         "consider removing target_type parameter")


def test_multi_feature_distribution_plotter_warns_if_high_number_of_levels_for_multiclass(
        ameshousing_features, ameshousing_multiclass_target_numerical_with_more_than_ten_levels):
    with pytest.warns(UserWarning) as record:
        plotter = MultiFeatureDistributionPlotter()
        plotter.plot(features=ameshousing_features,
                     target=ameshousing_multiclass_target_numerical_with_more_than_ten_levels,
                     target_type=TargetType.multiclass)

    assert record[0].message.args[0] == ("Number of levels higher than expected for plotting functionality; "
                                         "may lead to style issues in plots.")


def test_multi_feature_distribution_plotter_raises_error_for_invalid_classification_target_type_input(
        ameshousing_features, ameshousing_regression_target):
    detected_target_type = detect_target_type(ameshousing_regression_target)
    target_type = TargetType.classification
    with pytest.raises(ValueError) as exception_info:
        plotter = MultiFeatureDistributionPlotter()
        plotter.plot(features = ameshousing_features,
                     target = ameshousing_regression_target,
                     target_type = target_type)

    assert exception_info.value.args[0] == ("The specified target_type {} cannot be used for the detected target type "
                                            "{}".format(target_type, detected_target_type))


def test_multi_feature_distribution_plotter_raises_error_for_invalid_multiclass_target_type_input(
        ameshousing_features, ameshousing_regression_target):
    detected_target_type = detect_target_type(ameshousing_regression_target)
    target_type = TargetType.multiclass
    with pytest.raises(ValueError) as exception_info:
        plotter = MultiFeatureDistributionPlotter()
        plotter.plot(features = ameshousing_features,
                     target = ameshousing_regression_target,
                     target_type = target_type)

    assert exception_info.value.args[0] == ("Too many levels in target_type {} to be used for plotting of "
                                            "the detected target type {}".format(target_type, detected_target_type))


def test_multi_feature_distribution_plotter_creates_pdf_with_classification_plots_with_varimps(
        titanic_features, titanic_classification_target_numerical):
    file_path = 'distribution_plots_for_classification_with_varimps.pdf'
    remove_file(file_path)
    varimps = UnivariateFeatureImportanceCalculator().calculate(target=titanic_classification_target_numerical,
                                                                features=titanic_features)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=titanic_features.iloc[:, [0, 2]],
                 target=titanic_classification_target_numerical,
                 varimps=varimps,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_multiclass_plots_with_varimps(
        ameshousing_features, ameshousing_multiclass_target_string):
    file_path = 'distribution_plots_for_multiclass_with_varimps.pdf'
    remove_file(file_path)
    varimps = UnivariateFeatureImportanceCalculator().calculate(target=ameshousing_multiclass_target_string,
                                                                features=ameshousing_features)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_multiclass_target_string,
                 varimps=varimps,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_regression_plots_with_lowess_regplot(
        ameshousing_features, ameshousing_regression_target):
    file_path = 'distribution_plots_for_regression_with_lowess_regplot.pdf'
    remove_file(file_path)
    varimps = UnivariateFeatureImportanceCalculator().calculate(target=ameshousing_regression_target,
                                                                features=ameshousing_features)
    plotter = MultiFeatureDistributionPlotter(show_regplot=True)
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_regression_target,
                 varimps=varimps,
                 file_path=file_path)
    file_tester(file_path)


def test_multi_feature_distribution_plotter_creates_pdf_with_regression_plots_with_varimps(
        ameshousing_features, ameshousing_regression_target):
    file_path = 'distribution_plots_for_regression_with_varimps.pdf'
    remove_file(file_path)
    varimps = UnivariateFeatureImportanceCalculator().calculate(target=ameshousing_regression_target,
                                                                features=ameshousing_features)
    plotter = MultiFeatureDistributionPlotter()
    plotter.plot(features=ameshousing_features,
                 target=ameshousing_regression_target,
                 varimps = varimps,
                 file_path=file_path)
    file_tester(file_path)
