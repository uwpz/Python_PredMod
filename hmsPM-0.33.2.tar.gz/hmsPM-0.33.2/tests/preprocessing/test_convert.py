"""Tests for `hmsPM.preprocessing` conversion functions"""

import pytest

import numpy as np
import pandas as pd
import re
from scipy import sparse
from pandas.testing import (
    assert_series_equal,
)
from numpy.testing import assert_array_equal

from hmsPM.preprocessing.convert import (
    ScaleConverter,
    MatrixConverter
)


###############################################################################
# Tests of MatrixConverter


def test_matrix_converter_convertes_dataframe_to_sparse_matrix_by_default():
    test_data = pd.DataFrame({
        "f_num": [1, 5, 11, 13],
        "f_cat": ['a', 'a', 'b', 'a'],
    })
    expected_data = sparse.csr_matrix([[1., 1., 0.],
                                       [5., 1., 0.],
                                       [11., 0., 1.],
                                       [13., 1., 0.]])
    tr_spm = MatrixConverter()
    converted_data = tr_spm.fit_transform(X=test_data)
    assert_array_equal(converted_data.todense(), expected_data.todense())


def test_matrix_converter_convertes_array_to_sparse_matrix_by_default():
    test_data = np.array([[1, 'a'],
                          [5, 'a'],
                          [11, 'b'],
                          [13, 'a']], dtype = object)
    expected_data = sparse.csr_matrix([[1., 1., 0.],
                                       [5., 1., 0.],
                                       [11., 0., 1.],
                                       [13., 1., 0.]])
    tr_spm = MatrixConverter()
    converted_data = tr_spm.fit_transform(X=test_data)
    assert_array_equal(converted_data.todense(), expected_data.todense())


def test_matrix_converter_convertes_dataframe_to_dense_matrix():
    test_data = pd.DataFrame({
        "f_num": [1, 5, 11, 13],
        "f_cat": ['a', 'a', 'b', 'a'],
    })
    expected_data = np.array([[1., 1., 0.],
                              [5., 1., 0.],
                              [11., 0., 1.],
                              [13., 1., 0.]])
    tr_spm = MatrixConverter(to_sparse = False)
    converted_data = tr_spm.fit_transform(X=test_data)
    assert_array_equal(converted_data, expected_data)


def test_matrix_converter_convertes_array_to_dense_matrix():
    test_data = np.array([[1, 'a'],
                          [5, 'a'],
                          [11, 'b'],
                          [13, 'a']], dtype = object)
    expected_data = np.array([[1., 1., 0.],
                              [5., 1., 0.],
                              [11., 0., 1.],
                              [13., 1., 0.]])
    tr_spm = MatrixConverter(to_sparse = False)
    converted_data = tr_spm.fit_transform(X=test_data)
    assert_array_equal(converted_data, expected_data)


###############################################################################
# Test data


@pytest.fixture
def data_for_transformer_testing():
    return pd.DataFrame({
        "target": [1, 0, 1, 1],
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', '11', '13'],
        "f_float_num": [1.1, 5.1, 11.1, 13.1],
        "f_float_cat": ["1.1", "5.1", "11.1", '13.1'],
        "f_bool": [True, True, False, True],
        "f_bool_num": [1, 1, 0, 1],
        "f_bool_cat": ['True', 'True', 'False', 'True'],
        "f_float_num_with_missings": [1.0, 5.0, np.nan, 13.0],
        "f_float_cat_with_missings": ['1.0', '5.0', np.nan, '13.0'],
        "f_mixed": [1, 5, '11', '13'],
        "f_string": ['a', 'a', 'b', 'a'],
        "f_string2": ['aa', 'bb', 'bb', 'aa'],
        "f_string_with_missing": ['a', np.nan, 'b', 'a'],
    })


###############################################################################
# Tests of ScaleConverter


def test_scale_converter_converts_numerical_to_numerical_values_for_int(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_int_num"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_int_num, data_for_transformer_testing.f_int_num, check_names=False)


def test_scale_converter_converts_numerical_to_numerical_values_for_float(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_float_num"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_float_num, data_for_transformer_testing.f_float_num, check_names=False)


def test_scale_converter_converts_numerical_to_categorical_values_for_int(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_int_num"], scale="categorical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_int_num, data_for_transformer_testing.f_int_cat, check_names=False)


def test_scale_converter_converts_numerical_to_categorical_values_for_float(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_float_num"], scale="categorical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_float_num, data_for_transformer_testing.f_float_cat, check_names=False)


def test_scale_converter_converts_categorical_to_categorical_values(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_int_cat"], scale="categorical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_int_cat, data_for_transformer_testing.f_int_cat, check_names=False)


def test_scale_converter_converts_categorical_to_numerical_values_for_int(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_int_cat"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_int_cat, data_for_transformer_testing.f_int_num, check_names=False)


def test_scale_converter_converts_categorical_to_numerical_values_for_float(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_float_cat"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_float_cat, data_for_transformer_testing.f_float_num, check_names=False)


def test_scale_converter_converts_mixed_to_numerical_values(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_mixed"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_mixed, data_for_transformer_testing.f_int_num, check_names=False)


def test_scale_converter_converts_mixed_to_categorical_values(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_mixed"], scale="categorical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_mixed, data_for_transformer_testing.f_int_cat, check_names=False)


def test_scale_converter_preserves_missing_values_for_numerical_conversion(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_float_cat_with_missings"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_float_cat_with_missings,
                        data_for_transformer_testing.f_float_num_with_missings, check_names=False)


def test_scale_converter_preserves_missing_values_for_categorical_conversion(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_float_num_with_missings"], scale="categorical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_float_num_with_missings,
                        data_for_transformer_testing.f_float_cat_with_missings, check_names=False)


def test_scale_converter_converts_boolean_values_to_numerical_values(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_bool"], scale="numerical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_bool, data_for_transformer_testing.f_bool_num, check_names=False)


def test_scale_converter_converts_boolean_values_to_categorical_values(data_for_transformer_testing):
    transformed_data = (ScaleConverter(column_names=["f_bool"], scale="categorical")
                        .fit_transform(data_for_transformer_testing.copy()))
    assert_series_equal(transformed_data.f_bool, data_for_transformer_testing.f_bool_cat, check_names=False)


def test_scale_converter_returns_np_array_for_np_array_input():
    test_data = np.array([[1, 5, 11, 13]]).transpose()
    expected_values = np.array([['1', '5', '11', '13']]).transpose()

    converted_values = ScaleConverter(scale = "categorical").fit_transform(test_data)

    assert_array_equal(converted_values, expected_values)


def test_scale_converter_preserves_missings_for_np_array_input():
    test_data = np.array([['1', '5', np.nan, '13']]).transpose()
    expected_values = np.array([[1, 5, np.nan, 13]]).transpose()

    converted_values = ScaleConverter(scale = "numerical").fit_transform(test_data)

    assert_array_equal(converted_values, expected_values)


def test_scale_converter_returns_series_for_series_input():
    test_data = pd.Series([1, 5, 11, 13])
    expected_values = pd.Series(['1', '5', '11', '13'])

    converted_values = ScaleConverter(scale = "categorical").fit_transform(test_data)

    assert_series_equal(converted_values, expected_values)


def test_scale_converter_raises_error_for_invalid_scale():
    with pytest.raises(ValueError) as exception_info:
        ScaleConverter(scale='invalid_scale')

    assert exception_info.value.args[0] == "'invalid_scale' is not a valid FeatureScale"


def test_scale_converter_raises_error_for_converting_non_numerical_string_to_numerical():
    non_numerical_string_input = pd.DataFrame(pd.Series(['a', 'b', 'c'], name = "f_string"))
    with pytest.raises(ValueError) as exception_info:
        ScaleConverter(column_names=["f_string"], scale="numerical").fit_transform(non_numerical_string_input)

    assert re.search("^Unable to parse string", exception_info.value.args[0])
