"""Tests for `hmsPM.preprocessing` functions for categorical features"""

import pytest

import numpy as np
import pandas as pd
from pandas.testing import (
    assert_frame_equal,
    assert_series_equal,
)
from numpy.testing import assert_array_equal

from hmsPM.preprocessing.categorical import (
    CategoryCollapser,
    TargetEncoder,
)


###############################################################################
# Tests of TargetEncoder


@pytest.fixture
def data_for_target_encoder_testing():
    return pd.DataFrame({"target": [1, 0, 1, 1],
                         "f_string": ['a', 'a', 'b', 'a'],
                         "f_string2": ['aa', 'bb', 'bb', 'aa'],
                         "f_lstring": ['0123456789', '0', '0', '0'],
                         "f_nume": [3, 4, 5, 7]})


def test_target_encoder_generates_encoding_for_categorical_features_only_by_default(data_for_target_encoder_testing):
    expected_encoding = {'f_string': {'b': 1, 'a': 2},
                         'f_string2': {'aa': 1, 'bb': 2}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    encoder = TargetEncoder().fit(features, target)
    target_encoding = encoder.target_encoding

    assert target_encoding == expected_encoding


def test_target_encoder_generates_encoding_for_given_feature_names(data_for_target_encoder_testing):
    expected_encoding = {'f_string': {'b': 1, 'a': 2}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    encoder = TargetEncoder(feature_names = "f_string").fit(features, target)
    target_encoding = encoder.target_encoding

    assert target_encoding == expected_encoding


def test_target_encoder_generates_encoding_for_specified_subset_index(data_for_target_encoder_testing):
    expected_encoding = {'f_string': {'a': 2, 'b': 1},
                         'f_string2': {'aa': 1, 'bb': 2}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    idx = [0, 1, 2]

    encoder = TargetEncoder(subset_index = idx).fit(features, target)
    target_encoding = encoder.target_encoding

    assert target_encoding == expected_encoding


def test_target_encoder_generates_encoding_for_specified_array_subset_index(data_for_target_encoder_testing):
    expected_encoding = {'f_string': {'a': 2, 'b': 1},
                         'f_string2': {'aa': 1, 'bb': 2}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    idx = np.array([0, 1, 2])

    encoder = TargetEncoder(subset_index = idx).fit(features, target)
    target_encoding = encoder.target_encoding

    assert target_encoding == expected_encoding


def test_target_encoder_generates_encoding_for_specified_dictionary(data_for_target_encoder_testing):
    expected_encoding = {'f_string': {'b': 4, 'a': 5},
                         'f_string2': {'aa': 3, 'bb': 4}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    encoder = TargetEncoder(target_encoding = expected_encoding).fit(features, target)
    target_encoding = encoder.target_encoding

    assert target_encoding == expected_encoding


def test_target_encoder_raises_error_if_specified_encoding_is_invalid_data_type(data_for_target_encoder_testing):
    invalid_encoding = [{'f_string': {'b': 4, 'a': 5}},
                        {'f_string2': {'aa': 3, 'bb': 4}}]

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    with pytest.raises(ValueError) as exception_info:
        TargetEncoder(target_encoding = invalid_encoding).fit(features, target)

    assert exception_info.value.args[0] == "Target encoding must be of type dictionary."


def test_target_encoder_raises_error_if_specified_encoding_dictionary_has_invalid_values(
        data_for_target_encoder_testing):
    invalid_encoding = {'f_string': {'b': 4, 'a': 5},
                        'f_string2': [1, 2, 3, 4]}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    with pytest.raises(ValueError) as exception_info:
        TargetEncoder(target_encoding = invalid_encoding).fit(features, target)

    assert exception_info.value.args[0] == ("At least one of the values in the specified encoding dictionary is an "
                                            "invalid type. Values must be dictionaries with mappings of the original "
                                            "categories to the encoded categories.")


def test_target_encoder_raises_error_if_specified_encoding_dictionary_has_invalid_keys(data_for_target_encoder_testing):
    invalid_encoding = {'f_string': {'b': 4, 'a': 5},
                        'not_a_column_name': {'aa': 3, 'bb': 4}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    with pytest.raises(ValueError) as exception_info:
        TargetEncoder(target_encoding = invalid_encoding).fit(features, target)

    assert exception_info.value.args[0] == ("The key 'not_a_column_name' in the specified encoding dictionary is not "
                                            "a valid column name of the passed features.")


def test_target_encoder_warns_if_specified_encoding_dictionary_misses_features(data_for_target_encoder_testing):
    incomplete_encoding = {'f_string': {'b': 4, 'a': 5}}

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    with pytest.warns(UserWarning) as record:
        TargetEncoder(target_encoding = incomplete_encoding).fit(features, target)

    assert record[0].message.args[0] == ("Not all feature are specified in the encoding dictionary. The original "
                                         "feature(s) will be returned. The unspecified columns are {'f_string2'}")


def test_target_encoder_returns_original_features_for_missing_features_in_specified_encoding_dictionary(
        data_for_target_encoder_testing):
    incomplete_encoding = {'f_string': {'b': 4, 'a': 5}}

    expected_data = pd.DataFrame({
        "f_string": [5, 5, 4, 5],
        "f_string2": ['aa', 'bb', 'bb', 'aa'],
    })

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    encoded_data = TargetEncoder(target_encoding = incomplete_encoding).fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_raises_error_if_specified_feature_is_numerical():
    test_data = pd.DataFrame({"target": [1, 0, 1, 1],
                              "f_num": [1, 3, 4, 1]})

    feature_names = ["f_num"]
    target_name = "target"
    features = test_data.loc[:, feature_names]
    target = test_data.loc[:, target_name]

    with pytest.raises(ValueError) as exception_info:
        TargetEncoder(feature_names = feature_names).fit_transform(features, target)

    assert exception_info.value.args[0] == ("At least one of the specified columns is numerical, but class only "
                                            "works for categorical columns.")


def test_target_encoder_encodes_categorical_feature_only_by_default(data_for_target_encoder_testing):
    expected_data = pd.DataFrame({
        "f_string": [2, 2, 1, 2],
        "f_string2": [1, 2, 2, 1],
    })

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    encoded_data = TargetEncoder().fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_encodes_categorical_features_with_long_strings(data_for_target_encoder_testing):
    expected_data = pd.DataFrame({
        "f_lstring": [1, 2, 2, 2],
    })

    feature_names = ["f_lstring"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    encoded_data = TargetEncoder().fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data)


def test_target_encoder_encodes_categorical_feature_with_specified_subset_index(data_for_target_encoder_testing):
    expected_data = pd.DataFrame({
        "f_string": [2, 2, 1, 2],
        "f_string2": [1, 2, 2, 1],
    })

    feature_names = ["f_string", "f_string2"]
    target_name = "target"
    features = data_for_target_encoder_testing.loc[:, feature_names]
    target = data_for_target_encoder_testing.loc[:, target_name]

    idx = [0, 1, 2]

    encoded_data = TargetEncoder(subset_index = idx).fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_preserves_missings_for_default_handle_missings_as_return_nan():
    test_data = pd.DataFrame({"target": [1, 0, 1, 1],
                              "f_string_with_missing": ['a', np.nan, 'b', 'a']})

    expected_data = pd.DataFrame({
        "f_string_with_missing": [1, np.nan, 2, 1],
    })

    feature_names = ["f_string_with_missing"]
    target_name = "target"
    features = test_data.loc[:, feature_names]
    target = test_data.loc[:, target_name]

    encoded_data = TargetEncoder().fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_encodes_missings_as_value_for_handle_missings_specified_as_value():
    test_data = pd.DataFrame({"target": [1, 0, 1, 1],
                              "f_string_with_missing": ['a', np.nan, 'b', 'a']})

    expected_data = pd.DataFrame({
        "f_string_with_missing": [1, -2, 2, 1],
    })

    feature_names = ["f_string_with_missing"]
    target_name = "target"
    features = test_data.loc[:, feature_names]
    target = test_data.loc[:, target_name]

    encoded_data = TargetEncoder(encode_missing = True).fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_encodes_unknowns_as_value_for_default_handle_unknowns_specified_as_value():
    test_data = pd.DataFrame({"target": [1, 0, 1, 1],
                              "f_string": ['a', 'c', 'b', 'a']})

    target_encoding = {'f_string': {'b': 4, 'a': 5}}

    expected_data = pd.DataFrame({
        "f_string": [5, -1, 4, 5],
    })

    feature_names = ["f_string"]
    target_name = "target"
    features = test_data.loc[:, feature_names]
    target = test_data.loc[:, target_name]

    encoded_data = TargetEncoder(target_encoding = target_encoding).fit_transform(features, target)

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_encodes_unknowns_as_value_for_handle_unknowns_specified_as_return_nan():
    test_data = pd.DataFrame({"target": [1, 0, 1, 1],
                              "f_string": ['a', 'c', 'b', 'a']})

    target_encoding = {'f_string': {'b': 4, 'a': 5}}

    expected_data = pd.DataFrame({
        "f_string": [5, np.nan, 4, 5],
    })

    feature_names = ["f_string"]
    target_name = "target"
    features = test_data.loc[:, feature_names]
    target = test_data.loc[:, target_name]

    encoded_data = (TargetEncoder(target_encoding = target_encoding,
                                  encode_unknown = False).fit_transform(features, target))

    assert_frame_equal(encoded_data, expected_data, check_dtype = False)


def test_target_encoder_returns_np_array_for_np_array_input():
    features = np.array([['a', 'aa'],
                         ['a', 'bb'],
                         ['b', 'bb'],
                         ['a', 'aa']])
    target = np.array([1, 0, 1, 1])

    expected_data = np.array([[2, 1],
                              [2, 2],
                              [1, 2],
                              [2, 1]])

    encoded_data = TargetEncoder().fit_transform(features, target)

    assert_array_equal(encoded_data, expected_data)


def test_target_encoder_returns_series_for_series_input():
    features = pd.Series(['a', 'a', 'b', 'a'])
    target = pd.Series([1, 0, 1, 1])

    expected_data = pd.Series([2, 2, 1, 2])

    encoded_data = TargetEncoder().fit_transform(features, target)

    assert_series_equal(encoded_data, expected_data)


def test_target_encoder_raises_error_for_np_array_input_and_specified_column_names():
    features = np.array([1, 2, 1, 1, 3])
    target = np.array([1, 0, 0, 0, 1])

    with pytest.raises(ValueError) as exception_info:
        TargetEncoder(feature_names = ["f_string"]).fit_transform(features, target)

    assert exception_info.value.args[0] == ("Column names cannot be specified for input data of type np.ndarray. "
                                            "Remove column_names parameter or change input data to pd.DataFrame.")


###############################################################################
# Tests of CategoryCollapser


def test_category_collapser_collapses_specified_number_of_top_categories_to_default_other_label():
    categories_to_collapse = pd.DataFrame({'categories': ['a', 'a', 'b', 'b', 'c', 'd']})
    expected_values = pd.DataFrame({'categories': ['a', 'a', 'b', 'b', '_OTHER_', '_OTHER_']})

    collapsed_values = CategoryCollapser(n_top = 2).fit_transform(categories_to_collapse)

    assert_frame_equal(collapsed_values, expected_values)


def test_category_collapser_collapses_specified_number_of_top_categories_to_specified_other_label():
    categories_to_collapse = pd.DataFrame({'categories': ['a', 'a', 'b', 'b', 'c', 'd']})
    expected_values = pd.DataFrame({'categories': ['a', 'a', 'b', 'b', '_manual_', '_manual_']})

    collapsed_values = CategoryCollapser(n_top = 2,
                                         other_label = "_manual_").fit_transform(categories_to_collapse)

    assert_frame_equal(collapsed_values, expected_values)


def test_category_collapser_preserves_missing_values():
    categories_to_collapse = pd.DataFrame({'categories': ['a', 'a', 'b', 'b', np.nan, 'd']})
    expected_values = pd.DataFrame({'categories': ['a', 'a', 'b', 'b', np.nan, '_OTHER_']})

    collapsed_values = CategoryCollapser(n_top = 2).fit_transform(categories_to_collapse)

    assert_frame_equal(collapsed_values, expected_values)


def test_category_collapser_returns_np_array_for_np_array_input():
    categories_to_collapse = np.array([['d', 'l'],
                                       ['c', 'm'],
                                       ['a', 'a'],
                                       ['a', 'l'],
                                       ['b', 'm'],
                                       ['b', 'b'],
                                       ['a', 'c']])

    expected_values = np.array([['_OTHER_', 'l'],
                                ['_OTHER_', 'm'],
                                ['a', '_OTHER_'],
                                ['a', 'l'],
                                ['b', 'm'],
                                ['b', '_OTHER_'],
                                ['a', '_OTHER_']])

    collapsed_values = CategoryCollapser(n_top = 2).fit_transform(categories_to_collapse)

    assert_array_equal(collapsed_values, expected_values)


def test_category_collapser_returns_series_for_series_input():
    categories_to_collapse = pd.Series(['d', 'c', 'a', 'a', 'b', 'b', 'a'])
    expected_values = pd.Series(['_OTHER_', '_OTHER_', 'a', 'a', 'b', 'b', 'a'])

    collapsed_values = CategoryCollapser(n_top = 2).fit_transform(categories_to_collapse)

    assert_series_equal(collapsed_values, expected_values)


def test_category_collapser_raises_error_if_specified_column_is_numerical():
    categories_to_collapse = pd.DataFrame({'categories_num': [1, 2, 1, 1, 2, 1],
                                           'categories_cat': ['a', 'a', 'b', 'b', 'c', 'd']})

    with pytest.raises(ValueError) as exception_info:
        CategoryCollapser(n_top = 2,
                          column_names = "categories_num").fit_transform(categories_to_collapse)

    assert exception_info.value.args[0] == ("At least one of the specified columns is numerical, but class only "
                                            "works for categorical columns.")


def test_category_collapser_raises_error_for_np_array_input_and_specified_column_names():
    test_data = np.array([[1, 2, np.nan, 1, 3]])

    with pytest.raises(ValueError) as exception_info:
        CategoryCollapser(n_top = 2,
                          column_names = ["f_string"]).fit_transform(test_data)

    assert exception_info.value.args[0] == ("Column names cannot be specified for input data of type np.ndarray. "
                                            "Remove column_names parameter or change input data to pd.DataFrame.")
