"""Tests for `hmsPM.preprocessing` functions for target variable"""

import pytest

import numpy as np
import pandas as pd
from pandas.testing import (
    assert_series_equal,
)

from hmsPM.preprocessing.target import (
    encode_to_numerical_target
)


###############################################################################
# Tests of encode_to_numerical_target


def test_encode_to_numerical_target_encodes_minority_string_target_to_correct_binary_target():
    string_target = pd.Series(['a', 'b', 'a', 'a', 'b', 'a'])
    expected_values = pd.Series([0, 1, 0, 0, 1, 0])

    encoded_values = encode_to_numerical_target(target = string_target)

    assert_series_equal(encoded_values, expected_values)


def test_encode_to_numerical_target_warns_if_input_target_series_numerical():
    numerical_target = pd.Series([0, 1, 0, 0, 1, 0])
    with pytest.warns(UserWarning) as record:
        encode_to_numerical_target(target = numerical_target)

    assert len(record) == 1
    assert record[0].message.args[0] == "Input series is already of type numeric - returning original series."


def test_encode_to_numerical_target_returns_original_if_input_target_series_numerical():
    numerical_target = pd.Series([0, 1, 0, 0, 1, 0])
    expected_values = pd.Series([0, 1, 0, 0, 1, 0])

    encoded_values = encode_to_numerical_target(target = numerical_target)

    assert_series_equal(encoded_values, expected_values)


def test_encode_to_numerical_target_preserves_missing_values():
    string_target = pd.Series(['a', 'b', 'a', 'a', np.NaN, 'a'])
    expected_values = pd.Series([0, 1, 0, 0, np.NaN, 0])

    encoded_values = encode_to_numerical_target(target = string_target)

    assert_series_equal(encoded_values, expected_values)
