import pytest

import numpy as np

from hmsPM.metrics import acc, auc, rmse, spear


@pytest.fixture
def y_true_class_1d():
    """Target true labels for classification
    with 4 samples"""
    return np.array([0, 1, 1, 0])


@pytest.fixture
def y_pred_class_1d():
    """Target predicted labels for classification
    with 4 samples"""
    return np.array([0, 1, 0, 0])


@pytest.fixture
def y_pred_class_2d():
    """Target predicted labels for classification
    with 4 samples as binary label indicators"""
    return np.array([[1, 0],
                     [0, 1],
                     [1, 0],
                     [1, 0]])


@pytest.fixture
def y_score_class_1d():
    """Target scores for classification
    of true-class with 4 samples"""
    return np.array([0.1, 0.9, 0.2, 0.3])


@pytest.fixture
def y_score_class_2d():
    """Target scores for classification
    for each class with 4 samples"""
    return np.array([[0.9, 0.1],
                     [0.1, 0.9],
                     [0.8, 0.2],
                     [0.7, 0.3]])


@pytest.fixture
def y_true_multiclass_1d():
    """Target true labels for multi-class classification
    with 4 samples"""
    return np.array([0, 1, 2, 0])


@pytest.fixture
def y_true_multiclass_3d():
    """Target predicted labels for multiclass classification
    with 4 samples as binary label indicators"""
    return np.array([[1, 0, 0],
                     [0, 1, 0],
                     [0, 0, 1],
                     [1, 0, 0]])


@pytest.fixture
def y_pred_multiclass_1d():
    """Target predicted labels for multiclass classification
    with 4 samples"""
    return np.array([0, 1, 0, 0])


@pytest.fixture
def y_pred_multiclass_3d():
    """Target predicted labels for multiclass classification
    with 4 samples as binary label indicators"""
    return np.array([[1, 0, 0],
                     [0, 1, 0],
                     [1, 0, 0],
                     [1, 0, 0]])


@pytest.fixture
def y_score_multiclass():
    """Target scores for multiclass classification
    for each class with 4 samples"""
    return np.array([[0.9, 0.1, 0.0],
                     [0.1, 0.8, 0.1],
                     [0.4, 0.3, 0.3],
                     [0.7, 0.2, 0.1]])


@pytest.fixture
def y_true_regr():
    """Target values for regression
    with 4 samples"""
    return np.array([0, 10, 20, 30])


@pytest.fixture
def y_pred_regr():
    """Target predicted values for regression
    with 4 samples"""
    return np.array([0, 5, 25, 30])


def test_acc_for_classification_with_1d_prediction_array(
        y_true_class_1d, y_pred_class_1d):
    assert acc(y_true_class_1d, y_pred_class_1d) == 0.75


def test_acc_for_classification_with_2d_prediction_array(
        y_true_class_1d, y_pred_class_2d):
    assert acc(y_true_class_1d, y_pred_class_2d) == 0.75


def test_acc_for_multiclass_classification_with_1d_prediction_array(
        y_true_multiclass_1d, y_pred_multiclass_1d):
    assert acc(y_true_multiclass_1d, y_pred_multiclass_1d) == 0.75


def test_acc_for_multiclass_classification_with_3d_prediction_array(
        y_true_multiclass_1d, y_pred_multiclass_3d):
    assert acc(y_true_multiclass_1d, y_pred_multiclass_3d) == 0.75


def test_acc_for_multiclass_classification_with_3d_truth_and_prediction_array(
        y_true_multiclass_3d, y_pred_multiclass_3d):
    assert acc(y_true_multiclass_3d, y_pred_multiclass_3d) == 0.75


def test_auc_for_classification_with_1d_scoring_array(
        y_true_class_1d, y_score_class_1d):
    assert auc(y_true_class_1d, y_score_class_1d) == 0.75


def test_auc_for_classification_with_2d_scoring_array(
        y_true_class_1d, y_score_class_2d):
    assert auc(y_true_class_1d, y_score_class_2d) == 0.75


def test_auc_for_multiclass_classification(
        y_true_multiclass_1d, y_score_multiclass):
    assert auc(y_true_multiclass_1d, y_score_multiclass) == 1.0


def test_rmse(y_true_regr, y_pred_regr):
    assert round(rmse(y_true_regr, y_pred_regr), 3) == 3.536


def test_spear(y_true_regr, y_pred_regr):
    assert spear(y_true_regr, y_pred_regr) == 1.0
