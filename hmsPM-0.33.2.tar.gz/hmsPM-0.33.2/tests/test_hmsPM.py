#!/usr/bin/env python

"""Tests for `hmsPM` package."""
