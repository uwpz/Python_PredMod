import pandas as pd
from pandas.testing import (
    assert_frame_equal,
)
from sklearn.linear_model import LogisticRegression, LinearRegression

from hmsPM.preprocessing.convert import MatrixConverter
from hmsPM.preprocessing.resample import Undersampler
from hmsPM.preprocessing.categorical import TargetEncoder
from hmsPM.calculation.partial_dependency import PartialDependencyCalculator


def test_calc_partial_dependence_calculates_partial_dependence(
        titanic_classification_target_numerical, titanic_features_preprocessed):
    expected_data = pd.DataFrame({'feature': ['age', 'age', 'age', 'age', 'age', 'age',
                                              'pclass', 'pclass', 'pclass', 'pclass', 'pclass', 'pclass'],
                                  'value': ['0.16670000599999998', '21.0', '28.0', '28.0', '39.0', '80.0',
                                            '1.0', '1.0', '2.0', '3.0', '3.0', '3.0'],
                                  'target': ['target', 'target', 'target', 'target', 'target', 'target',
                                             'target', 'target', 'target', 'target', 'target', 'target'],
                                  'yhat_mean': [0.590090, 0.441494, 0.393156, 0.393156, 0.321450, 0.123731,
                                                0.673868, 0.673868, 0.443409, 0.233833, 0.233833, 0.233833]})

    f_cat = ['pclass']
    f_num = ['age']
    features = titanic_features_preprocessed.loc[:, f_num + f_cat]
    features = TargetEncoder().fit_transform(features, titanic_classification_target_numerical)

    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)

    partial_dependence = PartialDependencyCalculator(n_bins = 5).calculate(X_test = features,
                                                                           fit = logreg,
                                                                           X_train = features)

    assert_frame_equal(partial_dependence, expected_data)


def test_calc_partial_dependence_calculates_partial_dependence_for_specified_features(
        titanic_classification_target_numerical, titanic_features_preprocessed):
    expected_data = pd.DataFrame({'feature': ['pclass', 'pclass', 'pclass',
                                              'age', 'age', 'age', 'age', 'age', 'age'],
                                  'value': ['1st', '2nd', '3rd',
                                            '0.16670000599999998', '21.0', '28.0', '28.0', '39.0', '80.0'],
                                  'target': ['target', 'target', 'target',
                                             'target', 'target', 'target', 'target', 'target', 'target'],
                                  'yhat_mean': [0.615950, 0.415908, 0.266615,
                                                0.530349, 0.423958, 0.389618, 0.389618, 0.337786, 0.176911]})

    f_cat = ['pclass', 'sex']
    f_num = ['age', 'fare']
    features = titanic_features_preprocessed.loc[:, f_num + f_cat]
    X_sparse = MatrixConverter().fit_transform(features)

    logreg = LogisticRegression().fit(X_sparse, titanic_classification_target_numerical)

    partial_dependence = PartialDependencyCalculator(n_bins = 5).calculate(X_test = features,
                                                                           fit = logreg,
                                                                           X_train = features,
                                                                           feature_names = ['pclass', 'age'])

    assert_frame_equal(partial_dependence, expected_data)


def test_calc_partial_dependence_calculates_partial_dependence_for_undersampled_data(
        titanic_classification_target_numerical,
        titanic_features_preprocessed):
    expected_data = pd.DataFrame({
        'feature': ['pclass', 'pclass', 'pclass', 'age', 'age', 'age', 'age', 'age', 'age'],
        'value': ['1st', '3rd', '2nd', '0.16670000599999998', '21.0', '28.0', '28.200000000000045', '39.0', '80.0'],
        'target': ['target', 'target', 'target', 'target', 'target', 'target', 'target', 'target', 'target'],
        'yhat_mean': [0.60997, 0.30235, 0.44732, 0.57150, 0.46346, 0.42775, 0.42674, 0.37306, 0.19660]})

    sampler = Undersampler(random_state = 1).fit(X = titanic_features_preprocessed,
                                                 y = titanic_classification_target_numerical)
    features_undersampled = sampler.transform(titanic_features_preprocessed)
    target_undersampled = sampler.transform(titanic_classification_target_numerical)

    b_all = sampler.b_all
    b_sample = sampler.b_sample

    f_cat = ['pclass', 'sex']
    f_num = ['age', 'fare']
    features_undersampled = features_undersampled.loc[:, f_num + f_cat]

    X_sparse = MatrixConverter().fit_transform(features_undersampled)

    logreg = LogisticRegression().fit(X_sparse, target_undersampled)
    calc = PartialDependencyCalculator(n_bins = 5)
    partial_dependence = calc.calculate(X_test = features_undersampled,
                                        fit = logreg,
                                        X_train = features_undersampled,
                                        b_sample = b_sample, b_all = b_all,
                                        feature_names = ['pclass', 'age'])

    assert_frame_equal(partial_dependence, expected_data, check_less_precise = True)


def test_calc_partial_dependence_calculates_partial_dependence_for_multiclass_target(
        ameshousing_multiclass_target_string, ameshousing_features_preprocessed):
    expected_data = pd.DataFrame({'feature': ['Sale_Type', 'Sale_Type', 'Sale_Type', 'Sale_Type'],
                                  'value': ['WD ', 'WD ', 'WD ', 'WD '],
                                  'target': ['q1', 'q2', 'q3', 'q4'],
                                  'yhat_mean': [0.261834, 0.259505, 0.253856, 0.224804]})

    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    features = ameshousing_features_preprocessed.loc[:, f_num + f_cat]
    X_sparse = MatrixConverter().fit_transform(features)

    logreg = LogisticRegression().fit(X_sparse, ameshousing_multiclass_target_string)

    partial_dependence = PartialDependencyCalculator(n_bins = 5).calculate(X_test = features,
                                                                           fit = logreg,
                                                                           X_train = features)

    partial_dependence = partial_dependence.iloc[0:4, :]

    assert_frame_equal(partial_dependence, expected_data, check_less_precise=True)


def test_calc_partial_dependence_calculates_partial_dependence_for_regression_target(
        ameshousing_regression_target, ameshousing_features_preprocessed):
    expected_data = pd.DataFrame({'feature': ['Sale_Type', 'Sale_Type', 'Sale_Type', 'Sale_Type'],
                                  'value': ['WD ', 'New', 'COD', 'ConLI'],
                                  'target': ['target', 'target', 'target', 'target'],
                                  'yhat_mean': [175200.736537, 266115.296635,
                                                133162.773524, 178987.074504]})

    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    features = ameshousing_features_preprocessed.loc[:, f_num + f_cat]
    X_sparse = MatrixConverter().fit_transform(features)

    linreg = LinearRegression().fit(X_sparse, ameshousing_regression_target)

    partial_dependence = PartialDependencyCalculator(n_bins = 5).calculate(X_test = features,
                                                                           fit = linreg,
                                                                           X_train = features)

    partial_dependence = partial_dependence.iloc[0:4, :]

    assert_frame_equal(partial_dependence, expected_data)
