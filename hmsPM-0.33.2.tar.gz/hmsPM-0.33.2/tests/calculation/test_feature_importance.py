"""Test of evaluation functions
"""
from collections import namedtuple

import numpy as np
import pandas as pd
import pytest
from pandas.testing import assert_frame_equal
from sklearn.linear_model import LogisticRegression

from hmsPM.calculation import (
    UnivariateFeatureImportanceCalculator,
    calculate_feature_importance_by_permutation,
)
from hmsPM.datasets import (
    load_ameshousing,
    load_titanic,
)
from hmsPM.datatypes import TargetType
from hmsPM.preprocessing import (
    QuantileBinner,
    ScaleConverter,
    TargetEncoder,
)


###############################################################################
# Test data


def cases_for_classification_tests():
    df = load_titanic()

    f_num = ['fare']
    f_cate = ['pclass', 'sex']
    feature_names = f_num + f_cate

    t_num = ['survived']
    t_string = ['survived_string']
    target_names = t_num + t_string

    # create string classification target
    df[t_string[0]] = df[t_num].iloc[:, 0].map({True: 'yes', False: 'no'})

    df = ScaleConverter(column_names = t_num + f_num, scale = "numerical").fit_transform(df)
    df = ScaleConverter(column_names = t_string + f_cate, scale = "categorical").fit_transform(df)

    df_with_missings = df.loc[:, target_names + feature_names]
    df_with_missings.loc[0:100, 'pclass'] = np.nan  # introduce missing values in one categorical feature
    df_without_missings = df_with_missings.dropna()

    expected_varimps_from_dense_features = pd.Series([0.757, 0.666, 0.646], index = ['sex', 'fare', 'pclass'])
    expected_varimps_from_sparse_features = pd.Series([0.761, 0.687, 0.646], index = ['sex', 'fare', 'pclass'])
    expected_varimps_from_imputed_features = pd.Series([0.761, 0.687, 0.668], index = ['sex', 'fare', 'pclass'])
    expected_varimps_from_binned_features = pd.Series([0.757, 0.666, 0.646], index = ['sex', 'fare', 'pclass'])

    warning_messages = {
        "string_classification": ("Detected string classification target. Encoded as binary classification target with "
                                  "minority class assumed to be the target class (minority class = 1)."),
        "missing_feature_values": ("At least one of the input features has missing values. "
                                   "Missing values will automatically be imputed.")
    }

    # Define parameter sets for test cases
    TestCaseClassification = namedtuple('TestCaseClassification',
                                        'target features n_bins impute_missings warnings expected_varimps')

    case_t_class_num_f_dense = pytest.param(
        *TestCaseClassification(target=df_without_missings[t_num].iloc[:, 0],
                                features=df_without_missings.loc[:, feature_names],
                                n_bins=None,
                                impute_missings=True,
                                warnings=None,
                                expected_varimps=expected_varimps_from_dense_features),
        id="with_num_target_and_dense_features")

    case_t_class_string_f_dense = pytest.param(
        *TestCaseClassification(target=df_without_missings[t_string].iloc[:, 0],
                                features=df_without_missings.loc[:, feature_names],
                                n_bins=None,
                                impute_missings=True,
                                warnings=[warning_messages["string_classification"]] * 3,
                                expected_varimps=expected_varimps_from_dense_features),
        id="with_string_target_and_dense_features")

    case_t_class_num_f_sparse = pytest.param(
        *TestCaseClassification(target=df_with_missings[t_num].iloc[:, 0],
                                features=df_with_missings.loc[:, feature_names],
                                n_bins=None,
                                impute_missings=False,
                                warnings=["Removed 1 row with missing values in fare",
                                          "Removed 101 rows with missing values in pclass"],
                                expected_varimps=expected_varimps_from_sparse_features),
        id="with_num_target_without_imputing_missing_features")

    case_t_class_string_f_sparse = pytest.param(
        *TestCaseClassification(target=df_with_missings[t_string].iloc[:, 0],
                                features=df_with_missings.loc[:, feature_names],
                                n_bins=None,
                                impute_missings=False,
                                warnings=["Removed 1 row with missing values in fare",
                                          warning_messages["string_classification"],
                                          "Removed 101 rows with missing values in pclass",
                                          warning_messages["string_classification"],
                                          warning_messages["string_classification"]],
                                expected_varimps=expected_varimps_from_sparse_features),
        id="with_string_target_without_imputing_missing_features")

    case_t_class_string_f_sparse_imputed = pytest.param(
        *TestCaseClassification(target=df_with_missings[t_string].iloc[:, 0],
                                features=df_with_missings.loc[:, feature_names],
                                n_bins=None,
                                impute_missings=True,
                                warnings=[warning_messages["missing_feature_values"],
                                          warning_messages["string_classification"],
                                          warning_messages["string_classification"],
                                          warning_messages["string_classification"]],
                                expected_varimps=expected_varimps_from_imputed_features),
        id="with_string_target_imputing_missing_features")

    case_t_class_string_f_binned = pytest.param(
        *TestCaseClassification(target=df_without_missings[t_string].iloc[:, 0],
                                features=df_without_missings.loc[:, feature_names],
                                n_bins=11,
                                impute_missings=False,
                                warnings=[warning_messages["string_classification"]] * 3,
                                expected_varimps=expected_varimps_from_binned_features),
        id="with_binning_numerical_features")

    case_t_class_string_class_warning = pytest.param(
        *TestCaseClassification(target=df_without_missings[t_string].iloc[:, 0],
                                features=df_without_missings.loc[:, feature_names],
                                n_bins=None,
                                impute_missings=True,
                                warnings=[warning_messages["string_classification"]] * 3,
                                expected_varimps=expected_varimps_from_dense_features),
        id="with_string_classification_warning")

    return [
        case_t_class_num_f_dense,
        case_t_class_string_f_dense,
        case_t_class_num_f_sparse,
        case_t_class_string_f_sparse,
        case_t_class_string_f_sparse_imputed,
        case_t_class_string_f_binned,
        case_t_class_string_class_warning,
    ]


def cases_for_regression_tests():
    df = load_ameshousing()

    f_num = ['Lot_Frontage']
    f_cate = ['Sale_Type']
    feature_names = f_num + f_cate

    t_regr = ['SalePrice']

    df = ScaleConverter(column_names = t_regr + f_num, scale = "numerical").fit_transform(df)
    df = ScaleConverter(column_names = f_cate, scale = "categorical").fit_transform(df)

    df_with_missings = df.loc[:, t_regr + feature_names]
    df_with_missings.loc[0:100, 'Sale_Type'] = np.nan  # introduce missing values in one categorical feature
    df_without_missings = df_with_missings.dropna()

    expected_varimps_from_dense_features = pd.Series([0.399, 0.366], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_sparse_features = pd.Series([0.373, 0.333], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_binned_features = pd.Series([0.37316, 0.33309], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_single_feature = pd.Series([0.373], index = ['Lot_Frontage'])

    # Define parameter sets for test cases
    TestCaseRegression = namedtuple('TestCaseRegression',
                                    'target features n_digits impute_missings expected_varimps')

    case_t_regr_f_dense = pytest.param(
        *TestCaseRegression(target=df_without_missings[t_regr].iloc[:, 0],
                            features=df_without_missings.loc[:, feature_names],
                            n_digits=None,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_dense_features),
        id="with_dense_features")

    case_t_regr_f_sparse = pytest.param(
        *TestCaseRegression(target=df_with_missings[t_regr].iloc[:, 0],
                            features=df_with_missings.loc[:, feature_names],
                            n_digits=None,
                            impute_missings=False,
                            expected_varimps=expected_varimps_from_sparse_features),
        id="without_imputing_missing_features")

    case_t_regr_f_binned = pytest.param(
        *TestCaseRegression(target=df_with_missings[t_regr].iloc[:, 0],
                            features=df_with_missings.loc[:, feature_names],
                            n_digits=5,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_binned_features),
        id="with_binning_numerical_features")

    case_t_regr_f_1 = pytest.param(
        *TestCaseRegression(target=df_with_missings[t_regr].iloc[:, 0],
                            features=df_with_missings.loc[:, f_num],
                            n_digits=None,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_single_feature),
        id="with_single_feature")

    return [
        case_t_regr_f_dense,
        case_t_regr_f_sparse,
        case_t_regr_f_binned,
        case_t_regr_f_1,
    ]


def cases_for_multiclass_tests():
    df = load_ameshousing()

    f_num = ['Lot_Frontage']
    f_cate = ['Sale_Type']
    feature_names = f_num + f_cate

    to_bin = 'SalePrice'
    t_string = ['SalePrice_multiclass_string']
    t_num_10minus = ['SalePrice_multiclass_numerical_10minus']
    t_num_10plus = ['SalePrice_multiclass_numerical_10plus']
    target_names = t_string + t_num_10minus + t_num_10plus

    df[t_string[0]] = QuantileBinner(n_bins = 4, output_format = 'intervals').fit_transform(df.loc[:, [to_bin]])
    df[t_num_10minus[0]] = QuantileBinner(n_bins = 3, output_format = 'numeric').fit_transform(df.loc[:, [to_bin]])
    df[t_num_10plus[0]] = QuantileBinner(n_bins = 11, output_format = 'numeric').fit_transform(df.loc[:, [to_bin]])

    df = ScaleConverter(column_names = t_num_10minus + t_num_10plus + f_num, scale = "numerical").fit_transform(df)
    df = ScaleConverter(column_names = t_string + f_cate, scale = "categorical").fit_transform(df)

    df_with_missings = df.loc[:, target_names + feature_names]
    df_with_missings.loc[0:100, 'Sale_Type'] = np.nan  # introduce missing values in one categorical feature
    df_without_missings = df_with_missings.dropna()

    expected_varimps_from_dense_features_t_string = pd.Series([0.663, 0.581], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_dense_features_t_num_10minus = pd.Series([0.678, 0.585], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_dense_features_t_num_10plus = pd.Series([0.650, 0.572], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_sparse_features_t_string = pd.Series([0.664, 0.569], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_sparse_features_t_num_10minus = pd.Series([0.678, 0.574], index = ['Lot_Frontage', 'Sale_Type'])
    expected_varimps_from_sparse_features_t_num_10plus = pd.Series([0.644, 0.569], index = ['Lot_Frontage', 'Sale_Type'])

    # Define parameter sets for test cases
    TestCaseMulticlass = namedtuple('TestCaseMulticlass',
                                    'target features target_type impute_missings expected_varimps')

    case_t_mclass_string_f_dense = pytest.param(
        *TestCaseMulticlass(target=df_without_missings[t_string].iloc[:, 0],
                            features=df_without_missings.loc[:, feature_names],
                            target_type=None,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_dense_features_t_string),
        id="with_string_target_and_dense_features")

    case_t_mclass_num_10minus_f_dense = pytest.param(
        *TestCaseMulticlass(target=df_without_missings[t_num_10minus].iloc[:, 0],
                            features=df_without_missings.loc[:, feature_names],
                            target_type=None,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_dense_features_t_num_10minus),
        id="with_num_target_and_dense_features")

    case_t_mclass_num_10plus_f_dense = pytest.param(
        *TestCaseMulticlass(target=df_without_missings[t_num_10plus].iloc[:, 0],
                            features=df_without_missings.loc[:, feature_names],
                            target_type=TargetType.multiclass,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_dense_features_t_num_10plus),
        id="with_num_target_overwritten_and_dense_features")

    case_t_mclass_string_f_sparse = pytest.param(
        *TestCaseMulticlass(target=df_with_missings[t_string].iloc[:, 0],
                            features=df_with_missings.loc[:, feature_names],
                            target_type=None,
                            impute_missings=False,
                            expected_varimps=expected_varimps_from_sparse_features_t_string),
        id="with_string_target_and_sparse_features")

    case_t_mclass_num_10minus_f_sparse = pytest.param(
        *TestCaseMulticlass(target=df_with_missings[t_num_10minus].iloc[:, 0],
                            features=df_with_missings.loc[:, feature_names],
                            target_type=None,
                            impute_missings=False,
                            expected_varimps=expected_varimps_from_sparse_features_t_num_10minus),
        id="with_num_target_and_sparse_features")

    case_t_mclass_num_10plus_f_sparse = pytest.param(
        *TestCaseMulticlass(target=df_with_missings[t_num_10plus].iloc[:, 0],
                            features=df_with_missings.loc[:, feature_names],
                            target_type=TargetType.multiclass,
                            impute_missings=True,
                            expected_varimps=expected_varimps_from_sparse_features_t_num_10plus),
        id="with_specified_num_target_and_sparse_features")

    return [
        case_t_mclass_string_f_dense,
        case_t_mclass_num_10minus_f_dense,
        case_t_mclass_num_10plus_f_dense,
        case_t_mclass_string_f_sparse,
        case_t_mclass_num_10minus_f_sparse,
        case_t_mclass_num_10plus_f_sparse,
    ]


###############################################################################
# Tests of UnivariateFeatureImportance


@pytest.mark.parametrize("target, features, n_bins, impute_missings, warnings, expected_varimps",
                         cases_for_classification_tests())
def test_univariate_feature_importance_calculates_feature_importance_for_classification(
        target: pd.Series, features: pd.Series, n_bins: int, impute_missings: bool, warnings: list,
        expected_varimps: pd.Series):
    if n_bins:
        calculator = UnivariateFeatureImportanceCalculator(n_bins=n_bins, impute_missings=impute_missings)
    else:
        calculator = UnivariateFeatureImportanceCalculator(impute_missings=impute_missings)
    if warnings:
        with pytest.warns(UserWarning) as record:
            varimps = calculator.calculate(target=target, features=features)
            for i_warning, warning in enumerate(record.list):
                assert getattr(warning.message, 'args')[0] == warnings[i_warning]
    else:
        varimps = calculator.calculate(target=target, features=features)
    assert all(varimps == expected_varimps)


@pytest.mark.parametrize("target, features, n_digits, impute_missings, expected_varimps",
                         cases_for_regression_tests())
def test_univariate_feature_importance_calculates_feature_importance_for_regression(
        target: pd.Series, features: pd.Series, n_digits: int, impute_missings: bool, expected_varimps: pd.Series):
    if n_digits:
        calculator = UnivariateFeatureImportanceCalculator(n_digits=n_digits)
    else:
        calculator = UnivariateFeatureImportanceCalculator()
    varimps = calculator.calculate(target = target, features = features)
    assert all(varimps == expected_varimps)


@pytest.mark.parametrize("target, features, target_type, impute_missings, expected_varimps",
                         cases_for_multiclass_tests())
def test_univariate_feature_importance_calculates_feature_importance_for_multiclass(
        target: pd.Series, features: pd.Series, target_type: TargetType, impute_missings: bool,
        expected_varimps: pd.Series):
    calculator = UnivariateFeatureImportanceCalculator(impute_missings=impute_missings)
    varimps = calculator.calculate(target=target, features=features, target_type=target_type)
    assert all(varimps == expected_varimps)


###############################################################################
# Tests of VariableImportanceByPermutation

def test_variable_importance_by_permutation_calculates_variable_importances(titanic_classification_target_numerical,
                                                                            titanic_features_preprocessed):
    import platform
    if platform.system() == 'Linux':
        expected_data = pd.DataFrame({
            'index': [5, 4, 0, 1, 6, 2, 3],
            'feature': ['sex', 'pclass', 'age', 'sibsp', 'embarked', 'parch', 'fare'],
            'performance_difference': [0.202903, 0.049809, 0.018793, 0.009167, 0.006112, 0.000611, 0.0],
            'importance': [100.0, 24.548193, 9.262048, 4.518072, 3.012048, 0.301205, 0.0],
            'importance_cum': [70.600744, 87.931951, 94.471026, 97.660818, 99.787347, 100.0, 100.0],
            'importance_sumnormed': [70.600744, 17.331207, 6.539075, 3.189793, 2.126528, 0.212653, 0.0]})
    else:
        expected_data = pd.DataFrame({
            'index': [5, 4, 0, 1, 6, 2, 3],
            'feature': ['sex', 'pclass', 'age', 'sibsp', 'embarked', 'parch', 'fare'],
            'performance_difference': [0.202903, 0.049809, 0.018793, 0.009167, 0.006112, 0.000611, 0.0],
            'importance': [100.0, 24.548193, 9.262048, 4.518072, 3.012048, 0.301205, 0.0],
            'importance_cum': [70.600744, 87.931951, 94.471026, 97.660818, 99.787347, 100.0, 100.0],
            'importance_sumnormed': [70.600744, 17.331207, 6.539075, 3.189793, 2.126528, 0.212653, 0.0]})

    features = (TargetEncoder(feature_names = ['pclass', 'sex', 'embarked'])
                .fit_transform(titanic_features_preprocessed, titanic_classification_target_numerical))

    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)
    varimps = calculate_feature_importance_by_permutation(features = titanic_features_preprocessed,
                                                          target = titanic_classification_target_numerical,
                                                          fit = logreg,
                                                          random_seed = 999)

    assert_frame_equal(varimps, expected_data, check_less_precise = True)
