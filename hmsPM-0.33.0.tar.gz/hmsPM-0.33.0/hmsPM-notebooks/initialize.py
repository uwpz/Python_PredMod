
# ######################################################################################################################
# Libraries
# ######################################################################################################################

# hmsPM
import hmsPM.datasets as hms_datasets
import hmsPM.preprocessing as hms_preproc
import hmsPM.calculation as hms_calc
import hmsPM.plotting as hms_plot
import hmsPM.utils as hms_utils

# Data
import numpy as np
import pandas as pd

# Plot
import matplotlib
import matplotlib.pyplot as plt

# Util
import os
import copy
import pickle


# ######################################################################################################################
# Parameters
# ######################################################################################################################

# Silent plotting (Overwrite to get default: plt.ion();  matplotlib.use('TkAgg'))
plt.ioff(); matplotlib.use('Agg')
plt.ion(); matplotlib.use('TkAgg')

# Locations
dataloc = "data/"
#plotloc = "./output/"

# Util
pd.set_option('display.width', 320)
pd.set_option('display.max_columns', 20)

# Other
twocol = ["red", "green"]
threecol = ["green", "yellow", "red"]


# ######################################################################################################################
# Functions
# ######################################################################################################################

def setdiff(a, b):
    return np.setdiff1d(a, b, True)

# Show closed figure again
def show_figure(fig):
    # create a dummy figure and use its manager to display "fig"
    dummy = plt.figure()
    new_manager = dummy.canvas.manager
    new_manager.canvas.figure = fig
    fig.set_canvas(new_manager.canvas)


