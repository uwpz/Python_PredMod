.. highlight:: shell

============
Contributing
============

Contributions are welcome, and they are greatly appreciated! Every little bit
helps, and credit will always be given.

You can contribute in many ways:


Types of Contributions
----------------------


Report Bugs
~~~~~~~~~~~

Report bugs at TODO.

If you are reporting a bug, please include:

* Your operating system name and version.
* Any details about your local setup that might be helpful in troubleshooting.
* Detailed steps to reproduce the bug.


Fix Bugs
~~~~~~~~

TODO


Implement Features
~~~~~~~~~~~~~~~~~~

TODO


Write Documentation
~~~~~~~~~~~~~~~~~~~

HMS Predictive Modeling could always use more documentation, whether as part of the
official HMS Predictive Modeling docs, in docstrings, or even on the web in blog posts,
articles, and such.


Submit Feedback
~~~~~~~~~~~~~~~

The best way to send feedback is to file an issue at TODO.

If you are proposing a feature:

* Explain in detail how it would work.
* Keep the scope as narrow as possible, to make it easier to implement.


Get Started!
------------

Ready to contribute? Here's how to set up `hmsPM` for local development.

1. Clone `hmsPM`::

    $ git clone https://analyticalsoftware-vis@dev.azure.com/analyticalsoftware-vis/00773-003_KF_ML/_git/hmsPM_Python

2. Setup a virtual environment

   a) using `PyCharm`:

       File | Settings | Project: hmsPM_Python | Project Interpreter | Add

       New environment: ``C:\...\hmsPM_Python\venv``

   b) using ``virtualenv``::

       $ cd hmsPM_Python/
       $ virtualenv venv

3. Activate virtual environment

   a) using ``bash``::

       $ source venv/Scripts/activate

   b) and ensure that the virtual environment is activated, e.g. with::

       $ which python

3. Install your local copy into the virtual environment

   a) with::

       $ python setup.py develop
        or
       $ make install-develop

   b) or if the virtual environment is not activated with::

       $ venv/Scripts/python setup.py develop

   c) and packages for package development, e.g., with::

       $ pip install -r requirements_dev.txt

5. Create a branch from develop for local development

   a) Update repository and checkout ``develop``::

       $ git fetch -p
       $ git checkout develop
       $ (git merge)

   b) Create branch based on ``develop``::

       $ git checkout -b feature/<name-of-your-feature>
        or
       $ git checkout -b fix/<name-of-your-bugfix>

      Now you can make your changes locally.

6. When you're done making changes, check that your changes pass

   * `flake8` using::

       $ flake8 hmsPM tests
        or
       $ make lint

   * tests using::

       $ python setup.py test
        or
       $ pytest
        or
       $ make test

   * and tests including other Python versions using::

       $ tox
        or
       $ make test-all

   To get `flake8` and `tox`, just `pip install` them into your virtualenv.

7. Commit your changes and push your branch::

    $ git add .
    $ git commit -m "Your detailed description of your changes."
    $ git push origin feature/<name-of-your-feature>
    or
    $ git push origin fix/<name-of-your-bugfix>

8. Submit a pull request through the Azure DevOps website.


Pull Request Guidelines
-----------------------

Before you submit a pull request, check that it meets these guidelines:

1. The pull request should include tests.
2. If the pull request adds functionality, the docs should be updated. Put
   your new functionality into a function with a docstring, and add the
   feature to the list in README.rst.
3. The pull request should work for Python 3.6, 3.7, and for PyPy.


Tips
----

To run a subset of tests::

$ pytest tests.test_hmsPM


Deploying
---------

A reminder for the maintainers on how to deploy.
Make sure all your changes are committed (including an entry in HISTORY.rst).
Then run::

$ bump2version patch # possible: major / minor / patch
$ git push
$ git push --tags
