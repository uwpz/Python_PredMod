..  _hmsPM.preprocessing:

hmsPM.preprocessing package
===========================

This sub-package contains functions and classes for data-preprocessing. All
transformer classes are compatible with sklearn (they derive from the sklearn
`BaseEstimator <https://scikit-learn.org/stable/modules/generated/sklearn.base.BaseEstimator.html>`_
and
`TransfomerMixin <https://scikit-learn.org/stable/modules/generated/sklearn.base.TransformerMixin.html>`_).
They contain a :meth:`fit` method which calculates parameters required for the
transformation and a :meth:`transform` method which applies the transformation;
like in sklearn, using :meth:`fit_transform` combines these two steps. In
addition, hmsPM transformers have an optional :attr:`column_names` parameter
for selective transformations of pandas dataframes if only a subset of the
columns in the dataframe passed to :meth:`fit_transform` should be transformed.

Transformers available in hmsPM supplement the transformers that are available
in sklearn and can be used within a sklearn `pipeline`, within the sklearn
`ColumnTransformer`, and if desired, also alongside sklearn transformers.

Unlike sklearn transformers, hmsPM transformers accept both pandas data frames
and series as well as numpy arrays. Also, the data type returned by hmsPM
transformers is the same as that of the input data. For example, when a pandas
dataframe is passed, a pandas dataframe is returned. Similarly, the hmsPM
`ColumTransformer` (based on the sklearn version) also preserves the original
data type of the input data.

This means that column names and dtypes of dataframe columns are preserved
to facilitate further analysis. For example, dtypes and column names are used
by other hmsPM functions and classes, in particular to automate the correct
selection of calculation methods or of plots appropriate for feature scales
and target types, as well as the creation of suitable plot labels and titles.

Note that the :class:`Undersampler<hmsPM.preprocessing.resample.Undersampler>`
is based on the imbalanced-learn library. Unlike all other hmsPM transformers,
it returns not only transformed features, but a tuple of sampled features and
target. If used in a pipeline with other transformers, the `Pipeline` included
in the imbalanced-learn library needs to be used; it cannot be used within the
normal sklearn `Pipeline`.


Submodules
----------

hmsPM.preprocessing.categorical module
--------------------------------------

.. automodule:: hmsPM.preprocessing.categorical
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.compose module
----------------------------------

.. automodule:: hmsPM.preprocessing.compose
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.convert module
----------------------------------

.. automodule:: hmsPM.preprocessing.convert
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.impute module
---------------------------------

.. automodule:: hmsPM.preprocessing.impute
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.missing module
---------------------------------

.. automodule:: hmsPM.preprocessing.missing
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.numerical module
------------------------------------

.. automodule:: hmsPM.preprocessing.numerical
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.resample module
------------------------------------

.. automodule:: hmsPM.preprocessing.resample
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.preprocessing.target module
---------------------------------

.. automodule:: hmsPM.preprocessing.target
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: hmsPM.preprocessing
   :members:
   :undoc-members:
   :show-inheritance:
