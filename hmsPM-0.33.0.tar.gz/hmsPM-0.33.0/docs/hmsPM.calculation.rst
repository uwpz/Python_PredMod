..  _hmsPM.calculation:

hmsPM.calculation package
=========================

This sub-package contains calculation functions and classes to derive values
relevant for predictive modelling and to generate data for corresponding
plotters. For the classes the :meth:`calculate` method is used for the
calculation.

The most important calculation classes and functions are:

:class:`CorrelationMatrixCalculator<hmsPM.calculation.correlation.CorrelationMatrixCalculator>`
    Creates a correlation matrix for input features. The appropriate
    correlation type is automatically chosen based on the feature scale.
    Alternatively, the correlation type can be specified by the user.

:class:`UnivariateFeatureImportanceCalculator<hmsPM.calculation.feature_importance.UnivariateFeatureImportanceCalculator>`
    Calculates univariate feature importance for given feature(s) against
    target by automatically detecting feature scale and target type and
    utilising the appropriate calculation function.

:func:`calculate_feature_importance_by_permutation<hmsPM.calculation.feature_importance.calculate_feature_importance_by_permutation>`
    Calculates permutation importance for feature evaluation.

:func:`scale_predictions<hmsPM.calculation.scale.scale_predictions>`
    Rescales predictions to rewind undersampling of the data in the case of
    imbalanced target classes.


Submodules
----------

hmsPM.calculation.base module
-----------------------------

.. automodule:: hmsPM.calculation.base
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.calculation.correlation module
------------------------------------

.. automodule:: hmsPM.calculation.correlation
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.calculation.feature\_importance module
--------------------------------------------

.. automodule:: hmsPM.calculation.feature_importance
   :members:
   :undoc-members:
   :show-inheritance:

hmsPM.calculation.scale module
------------------------------------

.. automodule:: hmsPM.calculation.scale
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: hmsPM.calculation
   :members:
   :undoc-members:
   :show-inheritance:
