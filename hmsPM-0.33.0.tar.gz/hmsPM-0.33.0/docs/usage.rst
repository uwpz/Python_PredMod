=====
Usage
=====

To use HMS Predictive Modeling in a project::

    import hmsPM
