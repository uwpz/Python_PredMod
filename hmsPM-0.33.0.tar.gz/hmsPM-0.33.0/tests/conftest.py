import pytest

import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression, LinearRegression, SGDRegressor
from sklearn.model_selection import GridSearchCV, learning_curve
from category_encoders import OrdinalEncoder

from hmsPM.datatypes import TargetType
from hmsPM.datasets import load_titanic, load_ameshousing
from hmsPM.metrics import scorer
from hmsPM.preprocessing import (
    ScaleConverter,
    QuantileBinner,
    Imputer,
    TargetEncoder,
    Undersampler
)


# MODULE DATA #################################################################


DF_TITANIC = load_titanic()
DF_AMESHOUSING = load_ameshousing()


# AUXILIARY FUNCTIONS #########################################################


def make_base_preprocessing_steps(numerical, categorical):
    return [
        ('numerical_convert',
         ScaleConverter(column_names=numerical,
                        scale='numerical')),
        ('numerical_impute_median',
         Imputer(column_names=numerical,
                 strategy='median')),
        ('categorical_convert',
         ScaleConverter(column_names=categorical,
                        scale='categorical')),
        ('categorical_impute_missing',
         Imputer(column_names=categorical,
                 strategy='constant',
                 fill_value='missing')),
    ]


def _titanic_classification_features():
    f_num = ['fare', 'age']
    f_cat = ['pclass', 'sex']
    features = DF_TITANIC.loc[:, f_num + f_cat]
    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(
        base_preprocessing_steps +
        [('categorical_encode_ordinal', OrdinalEncoder(cols=f_cat))])
    processed_features = preprocessing_pipeline.fit_transform(features)
    return processed_features


def _titanic_classification_target() -> pd.Series:
    target_name = 'survived'
    target = DF_TITANIC.loc[:, target_name]
    target = ScaleConverter(scale='numerical').fit_transform(target)
    return target


def _ameshousing_multiclass_features():
    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    features = DF_AMESHOUSING.loc[:, f_num + f_cat]
    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(
        base_preprocessing_steps +
        [('categorical_encode_ordinal', OrdinalEncoder(cols=f_cat))])
    processed_features = preprocessing_pipeline.fit_transform(features)
    return processed_features


def _ameshousing_regression_features() -> pd.Series:
    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    features = DF_AMESHOUSING.loc[:, f_num + f_cat]
    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(
        base_preprocessing_steps +
        [('categorical_encode_ordinal', OrdinalEncoder(cols=f_cat))])
    processed_features = preprocessing_pipeline.fit_transform(features)
    return processed_features


def _ameshousing_regression_target() -> pd.Series:
    target_name = 'SalePrice'
    target = DF_AMESHOUSING.loc[:, target_name]
    target = ScaleConverter(scale='numerical').fit_transform(target)
    return target


def _ameshousing_regression_fit():
    features = _ameshousing_regression_features()
    target = _ameshousing_regression_target()
    linear_regression = LinearRegression().fit(features, target)
    return linear_regression


AMESHOUSING_REGRESSION_MODEL = _ameshousing_regression_fit()


# FEATURES ####################################################################


@pytest.fixture
def titanic_features() -> pd.DataFrame:
    f_num = ['fare', 'age']
    f_cat = ['pclass', 'sex']
    df = DF_TITANIC.loc[:, f_num + f_cat]
    df = ScaleConverter(column_names=f_num, scale='numerical').fit_transform(df)
    df = ScaleConverter(column_names=f_cat, scale='categorical').fit_transform(df)
    return df


@pytest.fixture
def ameshousing_features() -> pd.DataFrame:
    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    df = DF_AMESHOUSING.loc[:, f_num + f_cat]
    df = ScaleConverter(column_names=f_num, scale='numerical').fit_transform(df)
    df = ScaleConverter(column_names=f_cat, scale='categorical').fit_transform(df)
    return df


@pytest.fixture
def titanic_features_preprocessed() -> pd.DataFrame:
    f_cat = ['pclass', 'sex', 'embarked']
    f_num = ['age', 'sibsp', 'parch', 'fare']
    features = DF_TITANIC.loc[:, f_num + f_cat]
    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(base_preprocessing_steps)
    processed_features = preprocessing_pipeline.fit_transform(features)
    return processed_features


@pytest.fixture
def ameshousing_features_preprocessed():
    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    features = DF_AMESHOUSING.loc[:, f_num + f_cat]
    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(base_preprocessing_steps)
    processed_features = preprocessing_pipeline.fit_transform(features)
    return processed_features


# TARGETS #####################################################################


@pytest.fixture
def titanic_classification_target_numerical() -> pd.Series:
    target_name = 'survived'
    target = DF_TITANIC.loc[:, target_name]
    target = ScaleConverter(scale='numerical').fit_transform(target)
    return target


@pytest.fixture
def titanic_classification_target_string() -> pd.Series:
    target_name = 'survived'
    target = DF_TITANIC.loc[:, target_name]
    target = target.map({True: 'yes', False: 'no'})
    target = ScaleConverter(scale='categorical').fit_transform(target)
    return target


@pytest.fixture
def ameshousing_multiclass_target_string() -> pd.Series:
    target_to_bin = 'SalePrice'
    target_name = 'SalePrice_multiclass_string_levels'
    df = DF_AMESHOUSING.loc[:, [target_to_bin]]
    df[target_name] = QuantileBinner(n_bins=4, output_format='quantiles').fit_transform(df[[target_to_bin]])
    target = ScaleConverter(scale='categorical').fit_transform(df[target_name])
    return target


@pytest.fixture
def ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels() -> pd.Series:
    target_to_bin = 'SalePrice'
    target_name = 'SalePrice_multiclass_fewer_than_ten_levels'
    df = DF_AMESHOUSING.loc[:, [target_to_bin]]
    df[target_name] = QuantileBinner(n_bins=3, output_format='numeric').fit_transform(df[[target_to_bin]])
    target = ScaleConverter(scale='numerical').fit_transform(df[target_name])
    return target


@pytest.fixture
def ameshousing_multiclass_target_numerical_with_more_than_ten_levels() -> pd.Series:
    target_to_bin = 'SalePrice'
    target_name = 'SalePrice_multiclass_more_than_ten_levels'
    df = DF_AMESHOUSING.loc[:, [target_to_bin]]
    df[target_name] = QuantileBinner(n_bins = 11, output_format = 'numeric').fit_transform(df[[target_to_bin]])
    target = ScaleConverter(scale='numerical').fit_transform(df[target_name])
    return target


@pytest.fixture
def ameshousing_regression_target() -> pd.Series:
    target_name = 'SalePrice'
    target = DF_AMESHOUSING.loc[:, target_name]
    target = ScaleConverter(scale='numerical').fit_transform(target)
    return target


# FITS ########################################################################


@pytest.fixture(scope='module')
def titanic_cv_fit_pipeline():
    f_num = ['fare', 'age']
    f_cat = ['pclass', 'sex']
    target_name = 'survived'
    features = DF_TITANIC.loc[:, f_num + f_cat]
    target = DF_TITANIC.loc[:, target_name]

    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    cv_fit_pipeline = Pipeline(
        base_preprocessing_steps +
        [
            ('categorical_encode_ordinal',
             OrdinalEncoder(cols=f_cat)),
            ('cv_fit',
             GridSearchCV(
                 LogisticRegression(penalty='l1',
                                    fit_intercept=True,
                                    solver='liblinear'),
                 param_grid={'C': [2 ** x for x in range(2, -8, -1)]},
                 cv=5,
                 refit=False,
                 scoring=scorer(TargetType.classification),
                 return_train_score=True)
             )
        ]
    )
    cv_fit_pipeline.fit(X=features, y=target)
    return cv_fit_pipeline


@pytest.fixture(scope='module')
def titanic_xgb_fit_pipeline():
    f_num = ['fare', 'age']
    f_cat = ['pclass', 'sex']
    target_name = 'survived'
    features = DF_TITANIC.loc[:, f_num + f_cat]
    target = DF_TITANIC.loc[:, target_name]

    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    xgb_fit_pipeline = Pipeline(
        base_preprocessing_steps +
        [
            ('categorical_encode_ordinal',
             OrdinalEncoder(cols=f_cat)),
            ('xgb_fit',
             # TODO use xgb-customized GridSearchCV
             GridSearchCV(
                 xgb.XGBClassifier(verbosity=0),
                 param_grid = {
                     'n_estimators': [x for x in range(100, 1100, 400)],
                     'learning_rate': [0.1],
                     'max_depth': [3, 6],
                     'min_child_weight': [5, 10],
                     'colsample_bytree': [0.7],
                     'subsample': [0.7],
                     'gamma': [10]
                 },
                 cv=5,
                 refit=False,
                 scoring=scorer(TargetType.classification),
                 return_train_score=True)
             )
        ]
    )
    xgb_fit_pipeline.fit(X=features, y=target)
    return xgb_fit_pipeline


@pytest.fixture(scope='module')
def ameshousing_cv_fit_pipeline():
    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    target_name = 'SalePrice'
    features = DF_AMESHOUSING.loc[:, f_num + f_cat]
    target = DF_AMESHOUSING.loc[:, target_name]

    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    cv_fit_pipeline = Pipeline(
        base_preprocessing_steps +
        [
            ('categorical_encode_ordinal',
             OrdinalEncoder(cols=f_cat)),
            ('cv_fit',
             GridSearchCV(
                 SGDRegressor(penalty='ElasticNet', warm_start=True),
                 {'alpha': [2 ** x for x in range(-4, -12, -1)],
                  'l1_ratio': [0.5, 1]},
                 cv=5,
                 refit=False,
                 scoring=scorer(TargetType.regression),
                 return_train_score=True)
             )
        ]
    )

    cv_fit_pipeline.fit(features, target)
    return cv_fit_pipeline


# SCORES ######################################################################


@pytest.fixture
def titanic_numerical_classification_scores() -> pd.Series:
    features = _titanic_classification_features()
    target = _titanic_classification_target()
    logistic_regression = LogisticRegression().fit(features, target)
    y_hat = logistic_regression.predict_proba(features)
    return y_hat


@pytest.fixture
def titanic_string_classification_scores() -> pd.Series:
    target_name = 'survived'
    target = DF_TITANIC.loc[:, target_name]
    target = target.map({True: 'yes', False: 'no'})
    target = ScaleConverter(scale='categorical').fit_transform(target)

    processed_features = _titanic_classification_features()

    logistic_regression = LogisticRegression().fit(processed_features, target)
    y_hat = logistic_regression.predict_proba(processed_features)
    return y_hat


@pytest.fixture
def ameshousing_string_multiclass_scores() -> pd.Series:
    target_to_bin = 'SalePrice'
    target_name = 'SalePrice_multiclass_string_levels'
    df = DF_AMESHOUSING.loc[:, [target_to_bin]]
    df[target_name] = QuantileBinner(n_bins=4, output_format='quantiles').fit_transform(df[[target_to_bin]])
    target = ScaleConverter(scale='categorical').fit_transform(df[target_name])

    features = _ameshousing_multiclass_features()

    logreg = LogisticRegression().fit(features, target)
    y_hat = logreg.predict_proba(features)
    return y_hat


@pytest.fixture
def ameshousing_numerical_multiclass_scores() -> pd.Series:
    target_to_bin = 'SalePrice'
    target_name = 'SalePrice_multiclass_fewer_than_ten_levels'
    df = DF_AMESHOUSING.loc[:, [target_to_bin]]
    df[target_name] = QuantileBinner(n_bins=3, output_format='numeric').fit_transform(df[[target_to_bin]])
    target = ScaleConverter(scale='numerical').fit_transform(df[target_name])

    features = _ameshousing_multiclass_features()

    logreg = LogisticRegression().fit(features, target)
    y_hat = logreg.predict_proba(features)
    return y_hat


@pytest.fixture
def ameshousing_regression_scores() -> pd.Series:
    features = _ameshousing_regression_features()
    y_hat = AMESHOUSING_REGRESSION_MODEL.predict(features)
    return y_hat


@pytest.fixture
def titanic_numerical_classification_scores_undersampled():
    f_num = ['fare', 'age']
    f_cat = ['pclass', 'sex']
    target_name = 'survived'
    features = DF_TITANIC.loc[:, f_num + f_cat]
    target = DF_TITANIC.loc[:, target_name]

    undersampler = Undersampler(random_state = 1).fit(X = features, y = target)
    features, target = undersampler.transform(features), undersampler.transform(target)

    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(
        base_preprocessing_steps +
        [('categorical_encode_by_target', TargetEncoder(feature_names = f_cat))])
    processed_features = preprocessing_pipeline.fit_transform(features, target)
    logreg = LogisticRegression().fit(processed_features, target)
    y_hat = logreg.predict_proba(processed_features)
    return y_hat


@pytest.fixture
def ameshousing_string_multiclass_scores_undersampled() -> pd.Series:
    f_num = ['Lot_Frontage']
    f_cat = ['Sale_Type']
    features = DF_AMESHOUSING.loc[:, f_num + f_cat]

    target_to_bin = 'SalePrice'
    target_name = 'SalePrice_multiclass_string_levels'
    df = DF_AMESHOUSING.loc[:, [target_to_bin]]
    df[target_name] = QuantileBinner(n_bins=4, output_format='intervals').fit_transform(df.loc[:, [target_to_bin]])
    target = ScaleConverter(column_names=[target_name], scale='categorical').fit_transform(df[target_name])

    sampler = Undersampler(random_state = 1).fit(X = features, y = target)
    sampled_features, sampled_target = sampler.transform(features), sampler.transform(target)

    base_preprocessing_steps = make_base_preprocessing_steps(numerical=f_num, categorical=f_cat)
    preprocessing_pipeline = Pipeline(
        base_preprocessing_steps +
        [('categorical_encode_by_target', TargetEncoder(feature_names = f_cat))])
    processed_features = preprocessing_pipeline.fit_transform(sampled_features, sampled_target)
    logreg = LogisticRegression().fit(processed_features, sampled_target)
    y_hat = logreg.predict_proba(processed_features)
    return y_hat


# LEARNING CURVE ##############################################################


@pytest.fixture
def titanic_learning_curve(titanic_cv_fit_pipeline):
    features = _titanic_classification_features()
    target = _titanic_classification_target()

    return learning_curve(
        estimator=(
            GridSearchCV(
                LogisticRegression(
                    penalty='l1',
                    fit_intercept=True,
                    solver='liblinear'),
                param_grid={'C': [2 ** x for x in range(2, -8, -1)]},
                cv=None)),
        X=features,
        y=target,
        train_sizes=np.append(np.linspace(0.05, 0.1, 5),
                              np.linspace(0.2, 1, 5)),
        cv=None,
        return_times=True
    )
