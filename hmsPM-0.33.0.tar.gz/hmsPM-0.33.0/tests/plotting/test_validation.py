
import pytest

from hmsPM.plotting.validation import ValidationPlotter

from tests.plotting.utils import remove_file, file_tester


def test_validation_plotter_initializes_list_of_variables_correctly():
    vplotter = ValidationPlotter(x_var='x', color_var='col')

    assert vplotter._vars == ['x', 'col']


def test_validation_plotter_raises_key_error_for_invalid_variables(
        titanic_cv_fit_pipeline):
    cv_results_ = titanic_cv_fit_pipeline.named_steps['cv_fit'].cv_results_

    plotter = ValidationPlotter(x_var='invalid_variable')

    with pytest.raises(KeyError) as exception_info:
        plotter.plot(cv_results=cv_results_, metric='auc')

    assert exception_info.value.args[0] == ("Field invalid_variable is missing in cv_results_ "
                                            "(<class 'dict'>)")


def test_validation_plotter_creates_plot_for_classification_cross_validation_results(
        titanic_cv_fit_pipeline):
    cv_results_ = titanic_cv_fit_pipeline.named_steps['cv_fit'].cv_results_

    plotter = ValidationPlotter(x_var='C')
    plot_grid = plotter.plot(cv_results=cv_results_, metric='auc')
    ax = plot_grid[0].axes[0]

    assert ax.axes.xaxis.get_label_text() == "C"
    assert ax.axes.yaxis.get_label_text() == "mean_test_auc"


def test_validation_plotter_creates_pdf_for_classifiacation_cross_validation(
        titanic_cv_fit_pipeline):
    cv_results_ = titanic_cv_fit_pipeline.named_steps['cv_fit'].cv_results_

    file_path = 'validation_plot_for_classification.pdf'
    remove_file(file_path)
    plotter = ValidationPlotter(x_var='C')
    plotter.plot(cv_results=cv_results_, metric='auc', file_path=file_path)

    file_tester(file_path)


def test_validation_plotter_creates_pdf_for_regression_cross_validation(
        ameshousing_cv_fit_pipeline):
    cv_results_ = ameshousing_cv_fit_pipeline.named_steps['cv_fit'].cv_results_

    file_path = 'validation_plot_for_regression.pdf'
    remove_file(file_path)
    plotter = ValidationPlotter(x_var = "alpha", color_var = "l1_ratio")
    plotter.plot(cv_results=cv_results_, metric='spear', file_path=file_path)

    file_tester(file_path)


def test_validation_plotter_creates_pdf_for_classification_generation_gap(
        titanic_xgb_fit_pipeline):
    cv_results_ = titanic_xgb_fit_pipeline.named_steps['xgb_fit'].cv_results_

    file_path = 'generation_gap_for_xgb_classification.pdf'
    remove_file(file_path)
    plotter = ValidationPlotter(x_var="n_estimators",
                                color_var="max_depth",
                                column_var="min_child_weight",
                                row_var="gamma",
                                show_gen_gap=True)
    plotter.plot(cv_results=cv_results_, metric='auc', file_path=file_path)

    file_tester(file_path)
