"""Plotting test utilities

The pdf files created in the unit tests need to be inspected manually.
"""

import os


def remove_file(file_path: str):
    if os.path.exists(file_path):
        os.remove(file_path)


def file_tester(file_path: str):
    assert os.path.isfile(file_path)
    assert os.path.getsize(file_path) > 0
