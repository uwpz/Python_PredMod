
from hmsPM.datatypes import LearningMeasure
from hmsPM.plotting.learning import (
    LearningCurve,
    LearningPerformance,
    LearningScaling,
    LearningPlotter,
)
from tests.plotting.utils import remove_file, file_tester


###############################################################################
# Tests of learning curve


def test_learning_curve_creates_plot(titanic_learning_curve):
    n_train, scores_train, scores_test, _, _ = titanic_learning_curve

    plotter = LearningCurve()
    ax = plotter.plot(n_train=n_train,
                      scores_train=scores_train,
                      scores_test=scores_test)

    assert ax.title.get_text() == 'Learning Curve'
    assert ax.xaxis.get_label_text() == 'Training samples'
    assert ax.yaxis.get_label_text() == 'Score'
    assert ax.get_legend().texts[0].get_text() == 'Training mean'
    assert ax.get_legend().texts[1].get_text() == 'Test mean'


###############################################################################
# Tests of learning performance


def test_learning_performance_creates_plot(titanic_learning_curve):
    _, _, scores_test, times_fits, _ = titanic_learning_curve

    plotter = LearningPerformance()
    ax = plotter.plot(scores_test=scores_test, times_fits=times_fits)

    assert ax.xaxis.get_label_text() == 'Fitting time [s]'
    assert ax.yaxis.get_label_text() == 'Score'
    assert ax.title.get_text() == 'Learning Performance'

###############################################################################
# Tests of learning scaling


def test_learning_scaling_creates_plot(titanic_learning_curve):
    n_train, _, _, times_fits, _ = titanic_learning_curve

    plotter = LearningScaling()
    ax = plotter.plot(n_train=n_train, times_fits=times_fits)

    assert ax.xaxis.get_label_text() == 'Training samples'
    assert ax.yaxis.get_label_text() == 'Fitting time [s]'
    assert ax.title.get_text() == 'Learning Scaling'


###############################################################################
# Tests of learning plotter


def test_learning_plotter_creates_pdf_with_all_learning_measures_by_default(
        titanic_learning_curve):
    n_train, scores_train, scores_test, times_fits, _ = titanic_learning_curve

    file_path = 'learning_plots_default.pdf'
    remove_file(file_path)
    plotter = LearningPlotter()
    plotter.plot(n_train=n_train,
                 scores_train=scores_train,
                 scores_test=scores_test,
                 times_fits=times_fits,
                 file_path=file_path)

    file_tester(file_path=file_path)


def test_learning_plotter_creates_pdf_with_specified_learning_measures(
        titanic_learning_curve):
    n_train, scores_train, scores_test, times_fits, _ = titanic_learning_curve

    file_path = 'learning_plots_specified.pdf'
    remove_file(file_path)
    plotter = LearningPlotter(measures=[LearningMeasure.curve,
                                        LearningMeasure.performance],
                              n_cols=2)
    plotter.plot(n_train=n_train,
                 scores_train=scores_train,
                 scores_test=scores_test,
                 times_fits=times_fits,
                 file_path=file_path)

    file_tester(file_path=file_path)


def test_learning_plotter_creates_pdf_with_specified_learning_measures_as_string(
        titanic_learning_curve):
    n_train, scores_train, scores_test, times_fits, _ = titanic_learning_curve

    file_path = 'learning_plots_specified_strings.pdf'
    remove_file(file_path)
    plotter = LearningPlotter(measures=['curve',
                                        'performance'],
                              n_cols=2)
    plotter.plot(n_train=n_train,
                 scores_train=scores_train,
                 scores_test=scores_test,
                 times_fits=times_fits,
                 file_path=file_path)

    file_tester(file_path=file_path)


def test_learning_plotter_creates_pdf_without_individual_runs(
        titanic_learning_curve):
    n_train, scores_train, scores_test, times_fits, _ = titanic_learning_curve

    file_path = 'learning_plots_simple.pdf'
    remove_file(file_path)
    plotter = LearningPlotter(show_individual_runs=False)
    plotter.plot(n_train=n_train,
                 scores_train=scores_train,
                 scores_test=scores_test,
                 times_fits=times_fits,
                 file_path=file_path)

    file_tester(file_path=file_path)
