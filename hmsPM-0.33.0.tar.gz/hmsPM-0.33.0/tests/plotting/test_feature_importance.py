import pytest
from sklearn.linear_model import LogisticRegression

from hmsPM.plotting.feature_importance import (
    FeatureImportancePlotter
)
from hmsPM.preprocessing.categorical import TargetEncoder
from hmsPM.calculation.feature_importance import calculate_feature_importance_by_permutation


from tests.plotting.utils import remove_file, file_tester


def test_variable_importance_plotter_creates_plot(
        titanic_features_preprocessed, titanic_classification_target_numerical):
    features = (TargetEncoder(feature_names = ['pclass', 'sex', 'embarked'])
                .fit_transform(titanic_features_preprocessed, titanic_classification_target_numerical))
    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)
    varimps = calculate_feature_importance_by_permutation(features = features,
                                                          target = titanic_classification_target_numerical,
                                                          fit = logreg)
    plotter = FeatureImportancePlotter()
    ax = plotter.plot(varimps = varimps)
    assert ax.axes.xaxis.get_label_text() == "importance / cumulative importance in % (-$\\bullet$-)"
    assert ax.axes.yaxis.get_label_text() == "feature"


def test_variable_importance_plotter_creates_plot_for_specified_features_only(
        titanic_features_preprocessed, titanic_classification_target_numerical):
    features = (TargetEncoder(feature_names = ['pclass', 'sex', 'embarked'])
                .fit_transform(titanic_features_preprocessed, titanic_classification_target_numerical))

    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)
    varimps = calculate_feature_importance_by_permutation(features = features,
                                                          target = titanic_classification_target_numerical,
                                                          fit = logreg)
    plotter = FeatureImportancePlotter()
    ax = plotter.plot(varimps = varimps,
                      feature_names = ['parch', 'fare', 'pclass', 'sex'])
    assert ax.axes.get_title() == "Top 4 (of 7) Feature Importances"
    assert ax.axes.xaxis.get_label_text() == "importance / cumulative importance in % (-$\\bullet$-)"
    assert ax.axes.yaxis.get_label_text() == "feature"


def test_variable_importance_plotter_raises_warning_for_invalid_specified_feature_name(
        titanic_features_preprocessed, titanic_classification_target_numerical):
    features = (TargetEncoder(feature_names = ['pclass', 'sex', 'embarked'])
                .fit_transform(titanic_features_preprocessed, titanic_classification_target_numerical))

    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)
    varimps = calculate_feature_importance_by_permutation(features = features,
                                                          target = titanic_classification_target_numerical,
                                                          fit = logreg)
    with pytest.warns(UserWarning) as record:
        plotter = FeatureImportancePlotter()
        plotter.plot(varimps = varimps,
                     feature_names = ['parch', 'fare', 'pclass', 'sex', 'invalid'])

    assert record[0].message.args[0] == ("At least one of the specified feature_names is not a feature name in the "
                                         "passed varimps dataframe. The invalid feature names will be ignored. "
                                         "The invalid feature names are {'invalid'}")


def test_variable_importance_plotter_creates_pdf(
        titanic_features_preprocessed, titanic_classification_target_numerical):
    features = (TargetEncoder(feature_names = ['pclass', 'sex', 'embarked'])
                .fit_transform(titanic_features_preprocessed, titanic_classification_target_numerical))

    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)
    varimps = calculate_feature_importance_by_permutation(features = features,
                                                          target = titanic_classification_target_numerical,
                                                          fit = logreg)
    file_path = 'variable_importance_plot.pdf'
    remove_file(file_path)
    plotter = FeatureImportancePlotter()
    plotter.plot(varimps = varimps,
                 file_path = file_path)
    file_tester(file_path)


def test_variable_importance_plotter_creates_pdf_for_specified_feature_names(
        titanic_features_preprocessed, titanic_classification_target_numerical):
    features = (TargetEncoder(feature_names = ['pclass', 'sex', 'embarked'])
                .fit_transform(titanic_features_preprocessed, titanic_classification_target_numerical))

    logreg = LogisticRegression().fit(features, titanic_classification_target_numerical)
    varimps = calculate_feature_importance_by_permutation(features = features,
                                                          target = titanic_classification_target_numerical,
                                                          fit = logreg)
    file_path = 'variable_importance_plot_for_specified_features.pdf'
    remove_file(file_path)
    plotter = FeatureImportancePlotter()
    plotter.plot(varimps = varimps,
                 feature_names = ['age', 'pclass', 'sex'],
                 file_path = file_path)
    file_tester(file_path)
