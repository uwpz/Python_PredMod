import pytest

from hmsPM.datatypes import FeatureScale
from hmsPM.plotting.correlation import CorrelationPlotter
from hmsPM.utils import select_features_by_scale

from .utils import remove_file, file_tester


def test_correlation_plotter_creates_pdf_with_correlation_plot_for_categorical_features(
        titanic_features):
    categorical_features = select_features_by_scale(features = titanic_features,
                                                    feature_scale = FeatureScale.categorical)
    file_path = 'correlation_plot_for_categorical_features.pdf'
    remove_file(file_path)
    plotter = CorrelationPlotter()
    plotter.plot(features=categorical_features,
                 file_path=file_path)
    file_tester(file_path)


def test_correlation_plotter_creates_pdf_with_correlation_plot_for_numerical_features(
        titanic_features):
    numerical_features = select_features_by_scale(features=titanic_features,
                                                  feature_scale=FeatureScale.numerical)
    file_path = 'correlation_plot_for_numerical_features.pdf'
    remove_file(file_path)
    plotter = CorrelationPlotter()
    plotter.plot(features=numerical_features,
                 file_path=file_path)
    file_tester(file_path)


def test_correlation_plotter_raises_error_for_mixed_feature_scales(
        titanic_features):
    with pytest.raises(ValueError) as exception_info:
        plotter = CorrelationPlotter()
        plotter.plot(features=titanic_features)

    assert exception_info.value.args[0] == ("Input dataframe contains mixed feature scales. Specify feature_scale "
                                            "or input dataframe with only numerical or only categorical features.")


def test_correlation_plotter_raises_error_for_detected_feature_scale_numerical_and_feature_scale_input_categorical(
        titanic_features):
    numerical_features = select_features_by_scale(features = titanic_features,
                                                  feature_scale = FeatureScale.numerical)
    with pytest.raises(ValueError) as exception_info:
        plotter = CorrelationPlotter()
        plotter.plot(features=numerical_features,
                     feature_scale=FeatureScale.categorical)

    assert exception_info.value.args[0] == "Invalid feature_scale input for detected feature scale."


def test_correlation_plotter_raises_error_for_detected_feature_scale_categorical_and_feature_scale_input_numerical(
        titanic_features):
    categorical_features = select_features_by_scale(features = titanic_features,
                                                    feature_scale = FeatureScale.categorical)
    with pytest.raises(ValueError) as exception_info:
        plotter = CorrelationPlotter()
        plotter.plot(features=categorical_features,
                     feature_scale=FeatureScale.numerical)

    assert exception_info.value.args[0] == "Invalid feature_scale input for detected feature scale."


def test_correlation_plotter_raises_error_for_feature_scale_categorical_and_invalid_correlation_type(
        titanic_features):
    categorical_features = select_features_by_scale(features = titanic_features,
                                                    feature_scale = FeatureScale.categorical)
    with pytest.raises(ValueError) as exception_info:
        plotter = CorrelationPlotter(corr_type_numerical='invalid')
        plotter.plot(features=categorical_features)

    assert exception_info.value.args[0] == "'invalid' is not a valid CorrelationTypeNumerical"


def test_correlation_plotter_warns_if_feature_scale_numerical_and_invalid_correlation_type(
        titanic_features):
    numerical_features = select_features_by_scale(features = titanic_features,
                                                  feature_scale = FeatureScale.numerical)
    with pytest.raises(ValueError) as exception_info:
        plotter = CorrelationPlotter(corr_type_categorical='invalid')
        plotter.plot(features=numerical_features)

    assert exception_info.value.args[0] == "'invalid' is not a valid CorrelationTypeCategorical"
