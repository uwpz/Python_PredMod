import numpy as np
from numpy.testing import assert_array_almost_equal

from hmsPM.preprocessing.resample import Undersampler
from hmsPM.calculation.scale import scale_predictions


def test_scale_predictions_scales_predictions_for_classification_target(titanic_features,
                                                                        titanic_classification_target_numerical,
                                                                        titanic_numerical_classification_scores_undersampled):
    expected_mean_predictions = np.array([0.579615, 0.420385])
    sampler = Undersampler(random_state = 1)
    sampler.fit_transform(X = titanic_features, y = titanic_classification_target_numerical)
    b_all, b_sample = sampler.b_all, sampler.b_sample
    scaled_predictions = scale_predictions(y_hat = titanic_numerical_classification_scores_undersampled,
                                           b_sample = b_sample, b_all = b_all)
    scaled_mean_predictions = scaled_predictions.mean(axis=0)
    assert_array_almost_equal(scaled_mean_predictions, expected_mean_predictions)


def test_scale_predictions_scales_predictions_for_multiclass_target(
        ameshousing_features,
        ameshousing_multiclass_target_string,
        ameshousing_string_multiclass_scores_undersampled):
    expected_mean_predictions = np.array([0.25201, 0.24979, 0.24953, 0.24867])
    sampler = Undersampler(random_state = 1)
    sampler.fit_transform(X = ameshousing_features, y = ameshousing_multiclass_target_string)
    b_all, b_sample = sampler.b_all, sampler.b_sample
    scaled_predictions = scale_predictions(y_hat = ameshousing_string_multiclass_scores_undersampled,
                                           b_sample = b_sample, b_all = b_all)
    scaled_mean_predictions = scaled_predictions.mean(axis=0)
    assert_array_almost_equal(scaled_mean_predictions, expected_mean_predictions, decimal=5)
