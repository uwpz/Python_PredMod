"""Tests of calculator classes"""

import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from hmsPM.datasets import load_titanic
from hmsPM.datatypes import (
    FeatureScale,
    CorrelationTypeCategorical,
    CorrelationTypeNumerical,
)
from hmsPM.calculation.correlation import CorrelationMatrixCalculator
from hmsPM.preprocessing.convert import ScaleConverter
from hmsPM.utils import select_features_by_scale


###############################################################################
# Data fixtures


@pytest.fixture
def titanic_features():
    df = load_titanic()
    f_num = ['fare', 'age']
    f_cate = ['pclass', 'sex']
    df = ScaleConverter(column_names=f_num, scale="numerical").fit_transform(df)
    df = ScaleConverter(column_names=f_cate, scale="categorical").fit_transform(df)
    return df.loc[:, f_num + f_cate]


@pytest.fixture
def titanic_features_with_more_features():
    df = load_titanic()
    f_num = ['fare', 'age', 'body']
    f_cate = ['pclass', 'sex', 'boat']
    df = ScaleConverter(column_names=f_num, scale="numerical").fit_transform(df)
    df = ScaleConverter(column_names=f_cate, scale="categorical").fit_transform(df)
    return df.loc[:, f_num + f_cate]


###############################################################################
# Tests of CorrelationMatrixCalculator


def test_correlation_matrix_calculator_creates_correct_contingency_correlation_matrix_for_categorical_features(
        titanic_features):
    categorical_features = select_features_by_scale(features = titanic_features,
                                                    feature_scale = FeatureScale.categorical)
    expected_matrix = pd.DataFrame({'pclass (3)': [1.00000, 0.175097],
                                    'sex (2)': [0.175097, 1.00000]},
                                   index =['pclass (3)', 'sex (2)'])
    calculator = CorrelationMatrixCalculator(corr_type_categorical = 'contingency')
    corr_matrix, corr_type = calculator.create_matrix(features = categorical_features)

    assert_frame_equal(corr_matrix, expected_matrix)
    assert corr_type == CorrelationTypeCategorical.contingency


def test_correlation_matrix_calculator_creates_correct_cramersv_correlation_matrix_for_categorical_features(
        titanic_features):
    categorical_features = select_features_by_scale(features = titanic_features,
                                                    feature_scale = FeatureScale.categorical)
    expected_matrix = pd.DataFrame({'pclass (3)': [1.00000, 0.124773],
                                    'sex (2)': [0.124773, 1.00000]},
                                   index = ['pclass (3)', 'sex (2)'])
    calculator = CorrelationMatrixCalculator(corr_type_categorical = 'cramersv')
    corr_matrix, corr_type = calculator.create_matrix(features = categorical_features)

    assert_frame_equal(corr_matrix, expected_matrix)
    assert corr_type == CorrelationTypeCategorical.cramersv


def test_correlation_matrix_calculator_creates_correct_spearman_correlation_matrix_for_numerical_features(
        titanic_features):
    numerical_features = select_features_by_scale(features = titanic_features,
                                                  feature_scale = FeatureScale.numerical)
    expected_matrix = pd.DataFrame({'fare (NA: 0.1%)': [1.00000, 0.192676],
                                    'age (NA: 20.1%)': [0.192676, 1.00000]},
                                   index = ['fare (NA: 0.1%)', 'age (NA: 20.1%)'])
    calculator = CorrelationMatrixCalculator(corr_type_numerical = 'spearman')
    corr_matrix, corr_type = calculator.create_matrix(features = numerical_features)

    assert_frame_equal(corr_matrix, expected_matrix)
    assert corr_type == CorrelationTypeNumerical.spearman


def test_correlation_matrix_calculator_creates_correct_pearson_correlation_matrix_for_numerical_features(
        titanic_features):
    numerical_features = select_features_by_scale(features = titanic_features,
                                                  feature_scale = FeatureScale.numerical)
    expected_matrix = pd.DataFrame({'fare (NA: 0.1%)': [1.00000, 0.178739],
                                    'age (NA: 20.1%)': [0.178739, 1.00000]},
                                   index = ['fare (NA: 0.1%)', 'age (NA: 20.1%)'])
    calculator = CorrelationMatrixCalculator(corr_type_numerical = 'pearson')
    corr_matrix, corr_type = calculator.create_matrix(features = numerical_features)

    assert_frame_equal(corr_matrix, expected_matrix)
    assert corr_type == CorrelationTypeNumerical.pearson


def test_correlation_matrix_calculator_creates_correct_correlation_matrix_for_manual_cutoff_param(
        titanic_features_with_more_features):
    numerical_features = select_features_by_scale(features = titanic_features_with_more_features,
                                                  feature_scale = FeatureScale.numerical)
    expected_matrix = pd.DataFrame({'fare (NA: 0.1%)': [1.00000, 0.192676],
                                    'age (NA: 20.1%)': [0.192676, 1.00000]},
                                   index = ['fare (NA: 0.1%)', 'age (NA: 20.1%)'])
    calculator = CorrelationMatrixCalculator(cutoff = 0.1)
    corr_matrix, _ = calculator.create_matrix(features = numerical_features)

    assert_frame_equal(corr_matrix, expected_matrix)
