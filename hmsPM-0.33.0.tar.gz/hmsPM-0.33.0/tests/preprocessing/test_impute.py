"""Tests for `hmsPM.preprocessing` imputation functions"""

import pytest

import numpy as np
import pandas as pd
from pandas.testing import (
    assert_frame_equal,
    assert_series_equal,
)
from numpy.testing import assert_array_equal

from hmsPM.preprocessing.impute import Imputer


###############################################################################
# Tests of Imputer


def test_df_imputer_imputes_random_categorical_value_to_data_frame_for_random_strategy():
    test_data = pd.DataFrame({"f_string": ['a', 'b', np.nan, 'a', 'a']})
    expected_result = pd.DataFrame({"f_string": ['a', 'b', 'a', 'a', 'a']})

    np.random.seed(0)  # Set seed to get reproducible results
    imputed_values = Imputer(strategy = "random").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_random_numerical_value_to_data_frame_for_random_strategy():
    test_data = pd.DataFrame({"f_num": [1.0, 1.0, np.nan, 2.0, 3.0]})
    expected_result = pd.DataFrame({"f_num": [1.0, 1.0, 1.0, 2.0, 3.0]})

    np.random.seed(0)  # Set seed to get reproducible results
    imputed_values = Imputer(strategy = "random").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_most_frequent_categorical_value_to_data_frame_for_most_frequent_strategy():
    test_data = pd.DataFrame({"f_string": ['a', 'b', np.nan, 'a', 'a']})
    expected_result = pd.DataFrame({"f_string": ['a', 'b', 'a', 'a', 'a']})

    imputed_values = Imputer(strategy = "most_frequent").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_most_frequent_numerical_value_to_data_frame_for_most_frequent_strategy():
    test_data = pd.DataFrame({"f_num": [1.0, 1.0, np.nan, 2.0, 3.0]})
    expected_result = pd.DataFrame({"f_num": [1.0, 1.0, 1.0, 2.0, 3.0]})

    imputed_values = Imputer(strategy = "most_frequent").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_constant_categorical_value_to_data_frame_for_constant_strategy_with_default_fill_value():
    test_data = pd.DataFrame({"f_string": ['a', 'b', np.nan, 'a', 'a']})
    expected_result = pd.DataFrame({"f_string": ['a', 'b', 'missing_value', 'a', 'a']})

    imputed_values = Imputer(strategy = "constant").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_constant_numerical_value_to_data_frame_for_constant_strategy_with_default_fill_value():
    test_data = pd.DataFrame({"f_num": [1.0, 1.0, np.nan, 2.0, 3.0]})
    expected_result = pd.DataFrame({"f_num": [1.0, 1.0, 0.0, 2.0, 3.0]})

    imputed_values = Imputer(strategy = "constant").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_constant_categorical_value_to_data_frame_for_constant_strategy_with_specified_fill_value():
    test_data = pd.DataFrame({"f_string": ['a', 'b', np.nan, 'a', 'a']})
    expected_result = pd.DataFrame({"f_string": ['a', 'b', 'c', 'a', 'a']})

    imputed_values = Imputer(strategy = "constant", fill_value = "c").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_constant_numerical_value_to_data_frame_for_constant_strategy_with_specified_fill_value():
    test_data = pd.DataFrame({"f_num": [1.0, 1.0, np.nan, 2.0, 3.0]})
    expected_result = pd.DataFrame({"f_num": [1.0, 1.0, 4.0, 2.0, 3.0]})

    imputed_values = Imputer(strategy = "constant", fill_value = 4).fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_mean_value_to_data_frame_for_mean_strategy():
    test_data = pd.DataFrame({"f_num": [1.0, 1.0, np.nan, 2.0, 3.0]})
    expected_result = pd.DataFrame({"f_num": [1.0, 1.0, 1.75, 2.0, 3.0]})

    imputed_values = Imputer(strategy = "mean").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_imputes_median_value_to_data_frame_for_median_strategy():
    test_data = pd.DataFrame({"f_num": [1.0, 1.0, np.nan, 2.0, 3.0]})
    expected_result = pd.DataFrame({"f_num": [1.0, 1.0, 1.5, 2.0, 3.0]})

    imputed_values = Imputer(strategy = "median").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_returns_np_array_for_np_array_input():
    test_data = np.array([[1, 2, np.nan, 1, 3]])
    expected_result = np.array([[1, 2, 4, 1, 3]])

    imputed_values = Imputer(strategy = "constant", fill_value = 4).fit_transform(test_data)

    assert_array_equal(imputed_values, expected_result)


def test_df_imputer_returns_series_for_series_input():
    test_data = pd.Series([1, 2, np.nan, 1, 3])
    expected_result = pd.Series([1.0, 2.0, 4.0, 1.0, 3.0])

    imputed_values = Imputer(strategy = "constant", fill_value = 4).fit_transform(test_data)

    assert_series_equal(imputed_values, expected_result)


def test_df_imputer_returns_original_when_no_missings():
    test_data = pd.DataFrame({"f_string": ['a', 'b', 'c', 'a', 'a']})
    expected_result = pd.DataFrame({"f_string": ['a', 'b', 'c', 'a', 'a']})

    imputed_values = Imputer(strategy = "constant", fill_value = "c").fit_transform(test_data)

    assert_frame_equal(imputed_values, expected_result, check_names=False)


def test_df_imputer_raises_error_for_np_array_input_and_specified_column_names():
    test_data = np.array([[1, 2, np.nan, 1, 3]])

    with pytest.raises(ValueError) as exception_info:
        Imputer(strategy = "mean",
                column_names = ["f_string"]).fit_transform(test_data)

    assert exception_info.value.args[0] == ("Column names cannot be specified for input data of type np.ndarray. "
                                            "Remove column_names parameter or change input data to pd.DataFrame.")
