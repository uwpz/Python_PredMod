"""Tests for `hmsPM.preprocessing` functions for numerical features"""

import pytest

import numpy as np
import pandas as pd
from pandas.testing import (
    assert_frame_equal,
    assert_series_equal,
)
from numpy.testing import (
    assert_array_equal,
    assert_array_almost_equal,
)

from hmsPM.preprocessing.numerical import (
    QuantileBinner,
    Winsorizer,
)


###############################################################################
# Tests of bin_in_quantiles


def test_quantile_binner_bins_numeric_values_to_quantile_intervals_by_default():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10))})

    expected_values = pd.DataFrame({"f_num": pd.Series(['(-0.001, 3.0]'] * 4 + ['(3.0, 6.0]'] * 3 + ['(6.0, 9.0]'] * 3)})

    binned_values = QuantileBinner(n_bins = 3).fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_bins_numeric_values_to_intervals_in_scientific_notation_for_large_values():
    test_data = pd.DataFrame({"f_num": pd.Series([-1e7] + list(range(0, int(1e7), int(1e6))))})

    expected_values = pd.DataFrame({
        "f_num": pd.Series(['(-1.0e+07, 2.3e+06]'] * 4 + ['(2.3e+06, 5.7e+06]'] * 3 + ['(5.7e+06, 9.0e+06]'] * 4)})

    binned_values = QuantileBinner(n_bins = 3).fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_bins_numeric_values_to_numerated_quantiles_for_output_format_quantiles():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10))})

    expected_values = pd.DataFrame({"f_num": pd.Series(['q1'] * 4 + ['q2'] * 3 + ['q3'] * 3)})

    binned_values = QuantileBinner(n_bins = 3, output_format = 'quantiles').fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_bins_numeric_values_to_numerated_levels_for_output_format_numeric():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10))})

    expected_values = pd.DataFrame({"f_num": pd.Series([0, 0, 0, 0, 1, 1, 1, 2, 2, 2])})

    binned_values = QuantileBinner(n_bins = 3, output_format = 'numeric').fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_preserves_missing_values_for_output_format_intervals():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10)).append(pd.Series(np.nan), ignore_index=True)})

    expected_values = pd.DataFrame({"f_num": (pd.Series(['(-0.001, 3.0]'] * 4 + ['(3.0, 6.0]'] * 3 + ['(6.0, 9.0]'] * 3)
                                              .append(pd.Series(np.nan), ignore_index=True))})

    binned_values = QuantileBinner(n_bins = 3, output_format = 'intervals').fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_preserves_missing_values_for_output_format_intervals_and_large_values():
    test_data = pd.DataFrame({
        "f_num": pd.Series(range(0, int(1e7), int(1e6))).append(pd.Series(np.nan), ignore_index=True)})

    expected_values = pd.DataFrame({
        "f_num": (pd.Series(['(-1.0e-03, 3.0e+06]'] * 4 + ['(3.0e+06, 6.0e+06]'] * 3 + ['(6.0e+06, 9.0e+06]'] * 3)
                  .append(pd.Series(np.nan), ignore_index=True))})

    binned_values = QuantileBinner(n_bins = 3).fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_preserves_missing_values_for_output_format_quantiles():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10)).append(pd.Series(np.nan), ignore_index=True)})

    expected_values = pd.DataFrame({"f_num": (pd.Series(['q1'] * 4 + ['q2'] * 3 + ['q3'] * 3)
                                              .append(pd.Series(np.nan), ignore_index=True))})

    binned_values = QuantileBinner(n_bins = 3, output_format = 'quantiles').fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_preserves_missing_values_for_output_format_numeric():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10)).append(pd.Series(np.nan), ignore_index=True)})

    expected_values = pd.DataFrame({"f_num": (pd.Series([0, 0, 0, 0, 1, 1, 1, 2, 2, 2])
                                              .append(pd.Series(np.nan), ignore_index=True))})

    binned_values = QuantileBinner(n_bins = 3, output_format = 'numeric').fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_bins_numeric_columns_only_by_default():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10)),
                              "f_cat": pd.Series(['a', 'a', 'b', 'b', 'c', 'd', 'a', 'a', 'b', 's'])})

    expected_values = pd.DataFrame({"f_num": pd.Series(['(-0.001, 3.0]'] * 4 + ['(3.0, 6.0]'] * 3 + ['(6.0, 9.0]'] * 3),
                                    "f_cat": pd.Series(['a', 'a', 'b', 'b', 'c', 'd', 'a', 'a', 'b', 's'])})

    binned_values = QuantileBinner(n_bins = 3).fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_bins_only_specified_columns():
    test_data = pd.DataFrame({"f_num": pd.Series(range(10)),
                              "f_num2": pd.Series(range(10)),
                              "f_cat": pd.Series(['a', 'a', 'b', 'b', 'c', 'd', 'a', 'a', 'b', 's'])})

    expected_values = pd.DataFrame({"f_num": pd.Series(['(-0.001, 3.0]'] * 4 + ['(3.0, 6.0]'] * 3 + ['(6.0, 9.0]'] * 3),
                                    "f_num2": pd.Series(range(10)),
                                    "f_cat": pd.Series(['a', 'a', 'b', 'b', 'c', 'd', 'a', 'a', 'b', 's'])})

    binned_values = QuantileBinner(n_bins = 3, column_names = "f_num").fit_transform(test_data)

    assert_frame_equal(binned_values, expected_values)


def test_quantile_binner_returns_np_array_for_np_array_input():
    test_data = np.array([range(10)]).transpose()
    expected_values = np.array([['(-0.001, 3.0]'] * 4 + ['(3.0, 6.0]'] * 3 + ['(6.0, 9.0]'] * 3]).transpose()

    binned_values = QuantileBinner(n_bins = 3).fit_transform(test_data)

    assert_array_equal(binned_values, expected_values)


def test_quantile_binner_returns_series_for_series_input():
    test_data = pd.Series(range(10))

    expected_values = pd.Series(['(-0.001, 3.0]'] * 4 + ['(3.0, 6.0]'] * 3 + ['(6.0, 9.0]'] * 3)

    binned_values = QuantileBinner(n_bins = 3).fit_transform(test_data)

    assert_series_equal(binned_values, expected_values)


def test_quantile_binner_raises_error_if_specified_column_is_categorical():
    test_data = pd.DataFrame({"f_int_num": [1, 5, 11, 13],
                              "f_int_cat": ['1', '5', '11', '13']})

    with pytest.raises(ValueError) as exception_info:
        QuantileBinner(n_bins = 3, column_names = "f_int_cat").fit_transform(test_data)

    assert exception_info.value.args[0] == ("At least one of the specified columns is categorical, but class only "
                                            "works for numerical columns.")


def test_quantile_binner_raises_error_if_specified_column_is_categorical_for_np_array_input_and_specified_column_names():
    test_data = np.array([[1, 5, 11, 13]])

    with pytest.raises(ValueError) as exception_info:
        QuantileBinner(n_bins = 3, column_names = "f_num").fit_transform(test_data)

    assert exception_info.value.args[0] == ("Column names cannot be specified for input data of type np.ndarray. "
                                            "Remove column_names parameter or change input data to pd.DataFrame.")


def test_quantile_binner_raises_error_for_invalid_param_output_format():
    test_data = np.array([[1, 5, 11, 13]])
    with pytest.raises(ValueError) as exception_info:
        QuantileBinner(output_format = "invalid_format").fit_transform(test_data)

    assert exception_info.value.args[0] == ("Invalid output_format parameter, must be 'intervals', 'quantiles', "
                                            "or 'numeric'.")


###############################################################################
# Tests of winsorize


def test_winsorizer_clips_automatically_only_columns_with_numerical_values():
    test_data = pd.DataFrame({"f_int_num": [1, 5, 11, 13],
                              "f_float_num": [1.1, 5.1, 11.1, 13.1],
                              "f_int_cat": ['1', '5', '11', '13']})

    expected_values = pd.DataFrame({'f_int_num': [1.6, 5.0, 11.0, 12.7],
                                    'f_float_num': [1.7, 5.1, 11.1, 12.8],
                                    'f_int_cat': ['1', '5', '11', '13']})

    winsorized_values = Winsorizer(quantiles = (0.05, 0.95)).fit_transform(test_data)

    assert_frame_equal(winsorized_values, expected_values)


def test_winsorizer_clips_only_specified_columns():
    test_data = pd.DataFrame({"f_int_num": [1, 5, 11, 13],
                              "f_float_num": [1.1, 5.1, 11.1, 13.1],
                              "f_int_cat": ['1', '5', '11', '13']})

    expected_values = pd.DataFrame({'f_int_num': [1.6, 5.0, 11.0, 12.7],
                                    'f_float_num': [1.1, 5.1, 11.1, 13.1],
                                    'f_int_cat': ['1', '5', '11', '13']})

    winsorized_values = Winsorizer(quantiles = (0.05, 0.95), column_names = ["f_int_num"]).fit_transform(test_data)

    assert_frame_equal(winsorized_values, expected_values)


def test_winsorizer_returns_np_array_for_np_array_input():
    test_data = np.array([[1, 1.1],
                          [5, 5.1],
                          [11, 11.1],
                          [13, 13.1]])

    expected_values = np.array([[1.6, 1.7],
                                [5.0, 5.1],
                                [11.0, 11.1],
                                [12.7, 12.8]])

    imputed_values = Winsorizer(quantiles = (0.05, 0.95)).fit_transform(test_data)

    assert_array_almost_equal(imputed_values, expected_values, decimal = 10)


def test_winsorizer_warns_if_quantiles_are_not_specified():
    test_data = pd.DataFrame({"f_int_num": [1, 5, 11, 13],
                              "f_float_num": [1.1, 5.1, 11.1, 13.1]})

    with pytest.warns(UserWarning) as record:
        Winsorizer().fit_transform(test_data)

    assert len(record) == 1
    assert record[0].message.args[0] == "The quantiles parameter was not specified; original columns returned."


def test_winsorizer_raises_error_if_specified_column_is_categorical():
    test_data = pd.DataFrame({"f_int_num": [1, 5, 11, 13],
                              "f_int_cat": ['1', '5', '11', '13']})

    with pytest.raises(ValueError) as exception_info:
        Winsorizer(column_names = ["f_int_cat"]).fit_transform(test_data)

    assert exception_info.value.args[0] == ("At least one of the specified columns is categorical, but class only "
                                            "works for numerical columns.")


def test_winsorizer_raises_error_if_specified_column_is_categorical_for_np_array_input_and_specified_column_names():
    test_data = np.array([[1, 5, 11, 13]])

    with pytest.raises(ValueError) as exception_info:
        Winsorizer(column_names = ["f_string"]).fit_transform(test_data)

    assert exception_info.value.args[0] == ("Column names cannot be specified for input data of type np.ndarray. "
                                            "Remove column_names parameter or change input data to pd.DataFrame.")
