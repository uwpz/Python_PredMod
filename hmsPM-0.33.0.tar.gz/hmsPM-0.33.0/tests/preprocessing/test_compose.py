"""Tests for `hmsPM.preprocessing` functions to compose multiple estimators"""

import pytest
from numpy.testing import assert_array_equal
from pandas.testing import (
    assert_frame_equal,
)

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.compose import make_column_selector
from imblearn.pipeline import Pipeline as imbPipeline

from hmsPM.preprocessing.categorical import (
    CategoryCollapser,
    TargetEncoder,
)
from hmsPM.preprocessing.numerical import (
    Winsorizer,
    QuantileBinner,
)
from hmsPM.preprocessing.compose import (
    ColumnTransformer,
)
from hmsPM.preprocessing.convert import (
    ScaleConverter,
    MatrixConverter,
)
from hmsPM.preprocessing.impute import (
    Imputer,
)
from hmsPM.preprocessing.resample import (
    Undersampler,
)


###############################################################################
# Tests of ColumnTransformer


def test_df_column_transformer_works_with_sklearn_pipeline_for_remainder_passthrough():
    test_data = pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_float_num": [1.1, 5.1, 11.1, 13.1],
    })
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
        "f_float_num": [1.1, 5.1, 11.1, 13.1],
    })

    transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('cat', transformer, ['f_int_num'])],
        remainder = 'passthrough')

    processed_data = ct.fit_transform(test_data)

    assert_frame_equal(processed_data, expected_data)


def test_df_column_transformer_works_with_sklearn_pipeline_for_remainder_sklearn_transformer():
    test_data = pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', np.nan, '13'],
    })
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
        "f_int_cat": ['1', '5', 'missing_remainder', '13'],
    })

    transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('cat', transformer, ['f_int_num'])],
        remainder = SimpleImputer(strategy = 'constant', fill_value = 'missing_remainder'))

    processed_data = ct.fit_transform(test_data)

    assert_frame_equal(processed_data, expected_data)


def test_df_column_transformer_works_with_sklearn_pipeline_for_remainder_hmspm_transformer():
    test_data = pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', '11', '13'],
    })
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
        "f_int_cat": [1, 5, 11, 13],
    })

    transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('cat', transformer, ['f_int_num'])],
        remainder = ScaleConverter(scale = "numerical"))

    processed_data = ct.fit_transform(test_data)

    assert_frame_equal(processed_data, expected_data)


def test_df_column_transformer_works_with_sklearn_pipeline_for_remainder_drop_by_default():
    test_data = pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', '11', '13'],
    })
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
    })

    transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('cat', transformer, ['f_int_num'])])

    processed_data = ct.fit_transform(test_data)

    assert_frame_equal(processed_data, expected_data)


def test_df_column_transformer_works_with_sklearn_pipeline_for_column_selector_by_dtype():
    test_data = pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', '11', '13'],
    })
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
        "f_int_cat": [1, 5, 11, 13],
    })

    cat_selector_dtype = make_column_selector(dtype_include = np.number)
    num_selector_dtype = make_column_selector(dtype_include = object)

    numerical_transformer = Pipeline(steps = [
        ('convert_scale_to_num', ScaleConverter(scale = "numerical")),
    ])
    categorical_transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('num', numerical_transformer, num_selector_dtype),
            ('cat', categorical_transformer, cat_selector_dtype)])

    processed_data = ct.fit_transform(test_data)

    assert_frame_equal(processed_data, expected_data)


def test_df_column_transformer_works_with_sklearn_pipeline_for_column_selector_by_pattern():
    test_data = pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', '11', '13'],
    })
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
        "f_int_cat": [1, 5, 11, 13],
    })

    cat_selector_pattern = make_column_selector(pattern = '^(?!.*bool).*num.*$')
    num_selector_pattern = make_column_selector(pattern = '^(?!.*bool).*cat.*$')

    numerical_transformer = Pipeline(steps = [
        ('convert_scale_to_num', ScaleConverter(scale = "numerical")),
    ])
    categorical_transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('num', numerical_transformer, num_selector_pattern),
            ('cat', categorical_transformer, cat_selector_pattern)])

    processed_data = ct.fit_transform(test_data)

    assert_frame_equal(processed_data, expected_data)


def test_df_column_transformer_returns_array_for_array_input():
    test_data = np.array([['1', 12.0, '1.1', 1.0],
                          ['5', np.nan, '5.1', 5.0],
                          ['11', 11.0, '11.1', 3.0]])

    expected_data = np.array([[12.0, '1', '1.1', 1.0],
                              [11.5, '5', '5.1', 5.0],
                              [11.0, '11', '11.1', 3.0]])

    transformer = Pipeline(steps = [
        ('impute_median', Imputer(strategy = 'median')),
    ])

    ct = ColumnTransformer(
        transformers = [
            ('num', transformer, [1])],
        remainder = 'passthrough')

    processed_data = ct.fit_transform(test_data)

    assert_array_equal(processed_data, expected_data)

###############################################################################
# Test data


@pytest.fixture
def target_for_transformer_testing():
    return pd.Series([1, 0, 1, 1], name = "target")


@pytest.fixture
def features_for_transformer_testing():
    return pd.DataFrame({
        "f_int_num": [1, 5, 11, 13],
        "f_int_cat": ['1', '5', '11', '11'],
        "f_float_num_with_missings": [1.0, 5.0, np.nan, 13.0],
        "f_float_cat_with_missings": ['1', '5', np.nan, '13'],
        "f_string": ['a', 'a', 'b', 'a'],
        "f_string_with_missing": ['a', np.nan, 'b', 'a'],
        "f_to_bin": [1, 2, 3, 4],
    })


###############################################################################
# Tests of preprocessing transformers within scikit-learn pipeline


def test_preprocessing_transformers_work_within_sklearn_pipeline_for_dataframe_input(
        target_for_transformer_testing, features_for_transformer_testing):
    expected_data = pd.DataFrame({
        "f_int_num": ['1', '5', '11', '13'],
        "f_int_cat": [1.6, 5.0, 11.0, 11.0],
        "f_float_num_with_missings": ['1.0', '5.0', 'missing', '13.0'],
        "f_float_cat_with_missings": [1.0, 5.0, 5.0, 13.0],
        "f_string": ['a', 'a', '_OTHER_', 'a'],
        "f_string_with_missing": [1, 1, 2, 1],
        "f_to_bin": ['(0.999, 2.5]', '(0.999, 2.5]', '(2.5, 4.0]', '(2.5, 4.0]'],
    })

    cols_cat = ['f_int_num', 'f_float_num_with_missings']
    cols_num = ['f_int_cat', 'f_float_cat_with_missings']
    cols_impute_median = ['f_string_with_missing', 'f_float_cat_with_missings']
    cols_impute_missing = ['f_float_num_with_missings']
    cols_encode = ['f_string_with_missing']
    cols_collapse = ['f_string']
    cols_winsorize = ['f_int_cat']
    cols_bins = ['f_to_bin']

    preprocessing_pipeline = Pipeline([
        ("convert_numerical_features", ScaleConverter(column_names=cols_num,
                                                      scale="numerical")),
        ("convert_categorical_features", ScaleConverter(column_names=cols_cat,
                                                        scale="categorical")),
        ("bin_categorical_features", QuantileBinner(column_names=cols_bins,
                                                    n_bins=2)),
        ("encode_string_features", TargetEncoder(feature_names=cols_encode)),
        ("impute_missing", Imputer(column_names=cols_impute_missing,
                                   strategy="constant",
                                   fill_value="missing")),
        ("impute_median", Imputer(column_names=cols_impute_median,
                                  strategy="median")),
        ("collapse_categories", CategoryCollapser(column_names=cols_collapse,
                                                  n_top=1)),
        ("winsorize", Winsorizer(column_names=cols_winsorize,
                                 quantiles=(0.05, 0.95)))
    ])
    processed_data = preprocessing_pipeline.fit_transform(features_for_transformer_testing,
                                                          target_for_transformer_testing)

    assert_frame_equal(processed_data, expected_data, check_dtype = False)


def test_preprocessing_transformers_work_within_sklearn_pipeline_for_dataframe_input_with_sparse_matrix_converter(
        target_for_transformer_testing, features_for_transformer_testing):
    expected_data = sparse.csr_matrix([[1.6, 1., 1., 1., 0., 0., 0., 1., 0., 0., 0., 1., 0., 1., 0.],
                                       [5.0, 5., 1., 0., 1., 0., 0., 0., 1., 0., 0., 1., 0., 1., 0.],
                                       [11.0, 5., 2., 0., 0., 1., 0., 0., 0., 1., 0., 0., 1., 0., 1.],
                                       [11.0, 13., 1., 0., 0., 0., 1., 0., 0., 0., 1., 1., 0., 0., 1.]])

    cols_cat = ['f_int_num', 'f_float_num_with_missings']
    cols_num = ['f_int_cat', 'f_float_cat_with_missings']
    cols_impute_median = ['f_string_with_missing', 'f_float_cat_with_missings']
    cols_impute_missing = ['f_float_num_with_missings']
    cols_encode = ['f_string_with_missing']
    cols_collapse = ['f_string']
    cols_winsorize = ['f_int_cat']
    cols_bins = ['f_to_bin']

    preprocessing_pipeline = Pipeline([
        ("convert_numerical_features", ScaleConverter(column_names = cols_num,
                                                      scale = "numerical")),
        ("convert_categorical_features", ScaleConverter(column_names = cols_cat,
                                                        scale = "categorical")),
        ("bin_categorical_features", QuantileBinner(column_names = cols_bins,
                                                    n_bins = 2)),
        ("encode_string_features", TargetEncoder(feature_names = cols_encode)),
        ("impute_missing", Imputer(column_names = cols_impute_missing,
                                   strategy = "constant",
                                   fill_value = "missing")),
        ("impute_median", Imputer(column_names = cols_impute_median,
                                  strategy = "median")),
        ("collapse_categories", CategoryCollapser(column_names = cols_collapse,
                                                  n_top = 1)),
        ("winsorize", Winsorizer(column_names = cols_winsorize,
                                 quantiles = (0.05, 0.95))),
        ("create_sparse_matrix", MatrixConverter())
    ])
    processed_data = preprocessing_pipeline.fit_transform(features_for_transformer_testing,
                                                          target_for_transformer_testing)

    assert_array_equal(processed_data.todense(), expected_data.todense())


def test_preprocessing_transformers_work_within_sklearn_pipeline_for_array_input():
    target = np.array([1, 0, 1, 1])
    features = np.array([[1, 1],
                         [5, 1],
                         [11, np.nan],
                         [13, 1]])
    expected_data = np.array([['(1.149, 2.0]', '(0.999, 1.85]'],
                              ['_OTHER_', '(0.999, 1.85]'],
                              ['(1.149, 2.0]', '(0.999, 1.85]'],
                              ['_OTHER_', '(0.999, 1.85]']])

    preprocessing_pipeline = Pipeline([
        ("convert_categorical_features", ScaleConverter(scale="categorical")),
        ("encode_string_features", TargetEncoder()),
        ("impute_missing", Imputer(strategy="constant",
                                   fill_value=2)),
        ("winsorize", Winsorizer(quantiles=(0.05, 0.95))),
        ("bin_categorical_features", QuantileBinner(n_bins=3)),
        ("collapse_categories", CategoryCollapser(n_top=1)),
    ])
    processed_data = preprocessing_pipeline.fit_transform(features, target)

    assert_array_equal(processed_data, expected_data)


###############################################################################
# Tests of preprocessing transformers within column transformer pipeline


def test_preprocessing_transformers_work_within_column_transformer_for_dataframe_input(
        target_for_transformer_testing, features_for_transformer_testing):
    expected_data = pd.DataFrame({
        "f_int_num": [1, 4, 2, 3],
        "f_float_num_with_missings": [1, 4, 3, 2],
        "f_float_cat_with_missings": ['q1', 'q1', 'q1', '_OTHER_'],
    })

    # specify columns to be used in numerical and categorical transformers
    cols_cat = ['f_int_num', 'f_float_num_with_missings']
    cols_num = ['f_float_cat_with_missings']

    feature_names = cols_cat + cols_num

    # Get separate dataframe for all features and series for target column
    features = features_for_transformer_testing.loc[:, feature_names]

    # specify transformers for numerical and categorical feature scales separately
    numerical_transformer = Pipeline(steps = [
        ('convert_scale_to_num', ScaleConverter(scale = "numerical")),
        ('impute_median', Imputer(strategy = 'median')),
        ('winsorize', Winsorizer(quantiles = (0.05, 0.95))),
        ('bin_to_quantiles', QuantileBinner(n_bins = 3, output_format = 'quantiles')),
        ('collapse_categories', CategoryCollapser(n_top = 1))
    ])
    categorical_transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
        ('impute_missing', Imputer(strategy = 'constant', fill_value = 'missing')),
        ('encode_string_features', TargetEncoder()),
    ])

    # specify which transformers should work on which columns
    ct = ColumnTransformer(
        transformers = [
            ('num', numerical_transformer, cols_num),
            ('cat', categorical_transformer, cols_cat)])

    processed_data = ct.fit_transform(features, target_for_transformer_testing)

    assert_frame_equal(processed_data, expected_data)


def test_preprocessing_transformers_work_within_column_transformer_for_array_input():
    target = np.array([1, 0, 1, 1])
    features = np.array([[1, 1.0, '1'],
                         [5, 5.0, '5'],
                         [11, np.nan, np.nan],
                         [13, 13.0, '13']])
    expected_data = np.array([[1, 1, 'q1'],
                              [4, 4, 'q1'],
                              [2, 3, 'q1'],
                              [3, 2, '_OTHER_']], dtype = object)

    # specify transformers for numerical and categorical feature scales separately
    numerical_transformer = Pipeline(steps = [
        ('convert_scale_to_num', ScaleConverter(scale = "numerical")),
        ('impute_median', Imputer(strategy = 'median')),
        ('winsorize', Winsorizer(quantiles = (0.05, 0.95))),
        ('bin_to_quantiles', QuantileBinner(n_bins = 3, output_format = 'quantiles')),
        ('collapse_categories', CategoryCollapser(n_top = 1))
    ])
    categorical_transformer = Pipeline(steps = [
        ('scale_to_cat', ScaleConverter(scale = "categorical")),
        ('impute_missing', Imputer(strategy = 'constant', fill_value = 'missing')),
        ('encode_string_features', TargetEncoder()),
    ])

    # specify which transformers should work on which columns
    ct = ColumnTransformer(
        transformers = [
            ('cat', categorical_transformer, [0, 1]),
            ('num', numerical_transformer, [2])
        ])

    processed_data = ct.fit_transform(features, target)

    assert_array_equal(processed_data, expected_data)


###############################################################################
# Test data for imblearn pipeline


@pytest.fixture
def target_for_transformer_testing_in_imblearn_pipeline():
    return pd.Series([1, 0, 0, 1, 1], name = "target")


@pytest.fixture
def features_for_transformer_testing_in_imblearn_pipeline():
    return pd.DataFrame({
        "f_int_num": [1, 5, 11, 13, 13],
        "f_int_cat": ['1', '5', '11', '11', '11'],
        "f_float_num_with_missings": [1.0, 5.0, np.nan, 13.0, 13.0],
        "f_float_cat_with_missings": ['1', '5', np.nan, '13', '13'],
        "f_string": ['a', 'a', 'b', 'a', 'a'],
        "f_string_with_missing": ['a', np.nan, 'b', 'a', 'a'],
        "f_to_bin": [1, 2, 3, 4, 4],
    })


###############################################################################
# Tests of preprocessing transformers within imblearn pipeline


def test_preprocessing_transformers_work_within_imblearn_pipeline_for_dataframe_input(
        target_for_transformer_testing_in_imblearn_pipeline, features_for_transformer_testing_in_imblearn_pipeline):
    expected_data = pd.DataFrame({
        "f_int_num": ['13', '1', '5', '11'],
        "f_int_cat": [11.0, 1.8, 5.0, 11.0],
        "f_float_num_with_missings": ['13.0', '1.0', '5.0', 'missing'],
        "f_float_cat_with_missings": [13.0, 1.0, 5.0, 9.0],
        "f_string": ['a', 'a', 'a', '_OTHER_'],
        "f_string_with_missing": [1, 1, 1, 2],
        "f_to_bin": ['(3.0, 4.0]', '(0.999, 3.0]', '(0.999, 3.0]', '(0.999, 3.0]'],
    })

    cols_cat = ['f_int_num', 'f_float_num_with_missings']
    cols_num = ['f_int_cat', 'f_float_cat_with_missings']
    cols_impute_median = ['f_string_with_missing', 'f_float_cat_with_missings']
    cols_impute_missing = ['f_float_num_with_missings']
    cols_encode = ['f_string_with_missing']
    cols_collapse = ['f_string']
    cols_winsorize = ['f_int_cat']
    cols_bins = ['f_to_bin']

    preprocessing_pipeline = imbPipeline([
        ("convert_numerical_features", ScaleConverter(column_names=cols_num,
                                                      scale="numerical")),
        ("convert_categorical_features", ScaleConverter(column_names=cols_cat,
                                                        scale="categorical")),
        ("bin_categorical_features", QuantileBinner(column_names=cols_bins,
                                                    n_bins=2)),
        ("encode_string_features", TargetEncoder(feature_names=cols_encode)),
        ("impute_missing", Imputer(column_names=cols_impute_missing,
                                   strategy="constant",
                                   fill_value="missing")),
        ("impute_median", Imputer(column_names=cols_impute_median,
                                  strategy="median")),
        ("collapse_categories", CategoryCollapser(column_names=cols_collapse,
                                                  n_top=1)),
        ("winsorize", Winsorizer(column_names=cols_winsorize,
                                 quantiles=(0.05, 0.95))),
        ("undersample", Undersampler(random_state = 1)),
    ])
    processed_features = preprocessing_pipeline.fit_transform(features_for_transformer_testing_in_imblearn_pipeline,
                                                              target_for_transformer_testing_in_imblearn_pipeline)
    processed_features.reset_index(drop = True, inplace = True)

    assert_frame_equal(processed_features, expected_data, check_dtype = False)
