import pytest

import numpy as np
import pandas as pd

from hmsPM.preprocessing.missing import remove_na


def test_remove_na_removes_missing_values_from_single_list(titanic_features):
    with pytest.warns(UserWarning):
        non_missing_values = remove_na(titanic_features.iloc[:, 0].tolist())

    assert type(non_missing_values) is list
    assert not any(pd.isnull(non_missing_values))


def test_remove_na_removes_missing_values_from_single_numpy_array(titanic_features):
    with pytest.warns(UserWarning):
        non_missing_values = remove_na(titanic_features.iloc[:, 0].values)

    assert type(non_missing_values) is np.ndarray
    assert not any(pd.isnull(non_missing_values))


def test_remove_na_removes_missing_values_from_single_pandas_series(titanic_features):
    with pytest.warns(UserWarning):
        non_missing_values = remove_na(titanic_features.iloc[:, 0])

    assert type(non_missing_values) is pd.Series
    assert not any(pd.isnull(non_missing_values))


def test_remove_na_removes_missing_values_from_single_multidimensional_list(titanic_features):
    with pytest.warns(UserWarning):
        non_missing_values = remove_na(titanic_features.values.tolist())

    assert type(non_missing_values) is list
    assert not any(np.sum(pd.isnull(non_missing_values), axis=1) > 0)


def test_remove_na_removes_missing_values_from_single_multidimensional_numpy_array(titanic_features):
    with pytest.warns(UserWarning):
        non_missing_values = remove_na(titanic_features.values)

    assert type(non_missing_values) is np.ndarray
    assert not any(np.sum(pd.isnull(non_missing_values), axis=1) > 0)


def test_remove_na_removes_missing_values_from_single_multidimensional_pandas_dataframe(titanic_features):
    with pytest.warns(UserWarning):
        non_missing_values = remove_na(titanic_features)

    assert type(non_missing_values) is pd.DataFrame
    assert not any(np.sum(pd.isnull(non_missing_values), axis=1) > 0)


def test_remove_na_warns_if_a_single_value_was_removed(titanic_features):
    with pytest.warns(UserWarning) as record:
        remove_na(titanic_features.iloc[:, 0])

    assert len(record) == 1
    assert record[0].message.args[0] == 'Removed 1 row with missing values in fare'


def test_remove_na_warns_if_all_values_are_removed(titanic_features):
    a = np.array([None, None, None])

    with pytest.warns(UserWarning) as record:
        remove_na(a)

    assert len(record) == 1
    assert record[0].message.args[0] == 'All values are missing. Removed all values.'


def test_remove_na_warns_if_and_how_many_values_are_removed(titanic_features):
    with pytest.warns(UserWarning) as record:
        remove_na(titanic_features)

    assert len(record) == 1
    assert record[0].message.args[0] == 'Removed 264 rows with missing values in fare, age'


def test_remove_na_raises_error_if_input_arrays_have_different_lengths(titanic_features):
    a = titanic_features.iloc[:, 0]
    b = titanic_features.iloc[0:3, 1]

    with pytest.raises(ValueError) as exception_info:
        remove_na(a, b)

    assert exception_info.value.args[0] == 'x and y need to have the same length'


def test_remove_na_removes_missing_values_from_pandas_series_and_1d_numpy_array(titanic_features):
    a = titanic_features.iloc[:, 0]
    b = titanic_features.iloc[:, 1].values

    with pytest.warns(UserWarning):
        a_non_missing_values, b_non_missing_values = remove_na(a, b)

    assert type(a_non_missing_values) is pd.Series
    assert type(b_non_missing_values) is np.ndarray
    assert a_non_missing_values.shape[0] == b_non_missing_values.shape[0]
    assert not any(pd.isnull(a_non_missing_values))
    assert not any(pd.isnull(b_non_missing_values))


def test_remove_na_removes_missing_values_from_pandas_series_and_2d_numpy_array(titanic_features):
    a = titanic_features.iloc[:, 0]
    b = titanic_features.iloc[:, 1:3].values

    with pytest.warns(UserWarning):
        a_non_missing_values, b_non_missing_values = remove_na(a, b)

    assert type(a_non_missing_values) is pd.Series
    assert type(b_non_missing_values) is np.ndarray
    assert a_non_missing_values.shape[0] == b_non_missing_values.shape[0]
    assert not any(pd.isnull(a_non_missing_values))
    assert not any(np.sum(pd.isnull(b_non_missing_values), axis=1) > 0)
