import pytest

import numpy as np
import pandas as pd
from numpy.testing import (
    assert_array_almost_equal,
    assert_array_equal,
)

from hmsPM.preprocessing.resample import Undersampler


def test_undersampler_fit_generates_sample_index(
        titanic_features,
        titanic_classification_target_numerical):
    sampler = Undersampler()

    sampler.fit(X = titanic_features,
                y = titanic_classification_target_numerical)
    sample_index = sampler.sample_index

    sampled_features = titanic_features.iloc[sample_index]
    sampled_target = titanic_classification_target_numerical[sample_index]

    assert len(sampled_features) == len(sampled_target)


def test_undersampler_transform_can_be_applied_to_both_dataframes_and_series(
        titanic_features,
        titanic_classification_target_numerical):
    sampler = Undersampler()

    sampler.fit(X = titanic_features,
                y = titanic_classification_target_numerical)

    sampled_features = sampler.transform(titanic_features)
    sampled_target = sampler.transform(titanic_classification_target_numerical)

    assert len(sampled_features) == len(sampled_target)


def test_undersampler_generates_equalised_sampled_class_proportions_by_default_to_minority_class(
        titanic_features,
        titanic_classification_target_numerical):
    expected_proportions = np.array([0.5, 0.5])
    n_classes = titanic_classification_target_numerical.nunique()
    n_minority = titanic_classification_target_numerical.value_counts().min()
    sampler = Undersampler()

    X_sampled = sampler.fit_transform(X = titanic_features, y = titanic_classification_target_numerical)
    sampled_proportions = sampler.b_sample

    assert X_sampled.shape[0] == n_classes * n_minority
    assert_array_almost_equal(sampled_proportions, expected_proportions)


def test_undersampler_generates_sampled_class_proportions_for_specified_sampling_ratio(
        titanic_features,
        titanic_classification_target_numerical):
    expected_proportions = np.array([0.54545455, 0.45454545])
    sampler = Undersampler(n_max_per_level=600)

    X_sampled = sampler.fit_transform(X = titanic_features, y = titanic_classification_target_numerical)
    sampled_proportions = sampler.b_sample

    assert X_sampled.shape[0] == 1100
    assert_array_almost_equal(sampled_proportions, expected_proportions)


def test_undersampler_generates_original_class_proportions(
        titanic_features,
        titanic_classification_target_numerical):
    expected_proportions = np.array([0.618029, 0.381971])
    sampler = Undersampler()

    sampler.fit_transform(X = titanic_features, y = titanic_classification_target_numerical)
    sampled_proportions = sampler.b_all

    assert_array_almost_equal(sampled_proportions, expected_proportions)


def test_undersampler_generates_equalised_sampled_class_proportions_by_default_for_multiclass_target(
        ameshousing_features,
        ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels):
    expected_proportions = np.array([0.333333, 0.333333, 0.333333])
    sampler = Undersampler()

    sampler.fit_transform(X = ameshousing_features,
                          y = ameshousing_multiclass_target_numerical_with_fewer_than_ten_levels)
    sampled_proportions = sampler.b_sample

    assert_array_almost_equal(sampled_proportions, expected_proportions)


def test_undersampler_samples_input_data(
        titanic_features,
        titanic_classification_target_numerical):
    expected_df_shape = (1000, 5)
    sampler = Undersampler()

    sampled_data = sampler.fit_transform(X = pd.concat([titanic_features, titanic_classification_target_numerical]),
                                         y = titanic_classification_target_numerical)

    assert sampled_data.shape == expected_df_shape


def test_undersampler_returns_array_for_array_input():
    expected_data = np.array([['b', 'bb'],
                              ['a', 'bb']],
                             dtype=object)
    features = np.array([['a', 'aa'],
                         ['a', 'bb'],
                         ['b', 'bb'],
                         ['a', 'aa']])
    target = np.array([1, 0, 1, 1])
    sampler = Undersampler(random_state = 3)

    X = sampler.fit_transform(X = features, y = target)

    assert_array_equal(X, expected_data)


def test_undersampler_raises_error_for_regression_target_type(
        ameshousing_features,
        ameshousing_regression_target):
    with pytest.raises(ValueError) as exception_info:
        Undersampler().fit_transform(X = ameshousing_features, y = ameshousing_regression_target)

    assert exception_info.value.args[0] == ("Regression target detected. Undersampling can only "
                                            "be performed on (multiclass) classification targets.")
