========================
HMS Predictive Modeling
========================


Toolbox for predictive modelling.

* Free software: GNU General Public License v3

* Examples: Step-by-step tutorials on how to use hmsPM can be found in the JupyterLab Notebooks in the `notebooks`
  folder of this package.


About
--------

Existing Python packages for predictive modelling, such as scikit-learn and its extensions under
scikit-learn-contribute, offer powerful tools for the development of predictive models.

Many of these tools require a large amount of manual input, especially when regularly working with different types of
data. In particular, producing plots to facilitate the predictive modelling process often calls for the use of multiple
plotting libraries in combination with predictive modelling packages. Users therefore often need to manually create and
assemble according functions. This complicates the automation that may be desired in the processes involved in the
predictive modelling workflow.

The aim of hmsPM is to provide predictive modelling tools to allow the user to

* process data efficiently and create necessary plots for each step of the predictive modelling workflow, including

    - data exploration
    - model comparison
    - model interpretation

* produce relevant plots effectively, without the need to hand-craft them based on multiple plot libraries,

* generate many of these plots efficiently, and

* automate the complete predictive modelling process to facilitate quick and reliable results with minimal effort for
  new datasets.

hmsPM achieves these aims by providing

1. tools for generic and automated data-processing that automatically detect feature scales and target types, and

2. plots that make use of this automatic data detection to pave the way for the development of the desired predictive models.


Features
--------

hmsPM features the following three sub-packages:

:ref:`calculation<hmsPM.calculation>`
    Includes calculators to derive metrics relevant for predictive modelling.
:ref:`preprocessing<hmsPM.preprocessing>`
    Includes transformers for data-preprocessing. All transformers can be used in combination with the transformers from
    the scikit-learn library, as well as with scikit-learn pipelines.
:ref:`plotting<hmsPM.plotting>`
    Includes plotters generating `matplotlib` plots relevant for predictive modelling.


Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
