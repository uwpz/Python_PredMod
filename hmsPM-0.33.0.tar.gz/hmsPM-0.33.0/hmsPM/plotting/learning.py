"""Visualizations of learning measures"""

from abc import ABC, abstractmethod
from typing import List, Optional, Union

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.axes import Axes

from hmsPM.datatypes import (
    Color,
    Colors,
    PlotGrids,
    PlotFunctionCall,
    LearningMeasure,
    LearningMeasures,
)
from hmsPM.plotting.axes import create_axes
from hmsPM.plotting.grid import PlotGridBuilder
from hmsPM.plotting.output import save_plot_grids_to_pdf


class ILearningCurve(ABC):
    """Interface for learning curve plotter

    :param colors: Colors
    :param show_individual_runs: Show individual cross validation runs
    :param show_grid: Show grid lines on plot
    """
    def __init__(self,
                 colors: Colors = sns.color_palette('colorblind'),
                 show_individual_runs: bool = True,
                 show_grid: bool = True):
        self.colors = colors
        self.show_individual_runs = show_individual_runs
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             n_train: int,
             scores_train: np.array,
             scores_test: np.array,
             ax: Optional[Axes] = None
             ) -> Axes:
        """Create learning curve

        :param n_train: Number of training samples
        :param scores_train: Scores on training sets
        :param scores_test: Scores on test sets
        :param ax: Optional axes object to draw the plot onto
        :return: Axes
        """
        pass


class LearningCurve(ILearningCurve):
    """Learning curve"""

    def plot(self,
             n_train: int,
             scores_train: np.array,
             scores_test: np.array,
             ax: Optional[Axes] = None
             ) -> Axes:
        if ax is None:
            ax = create_axes()
        stats = self._prepare_stats(n_train=n_train,
                                    scores_train=scores_train,
                                    scores_test=scores_test)
        ax = self._plot_learning_curve(ax=ax,
                                       stats=stats,
                                       scores_train=scores_train,
                                       scores_test=scores_test)
        ax = self._format_plot(ax=ax)
        return ax

    @staticmethod
    def _prepare_stats(n_train: np.array,
                       scores_train: np.array,
                       scores_test: np.array) -> pd.DataFrame:
        stats = (
            pd.DataFrame({
                'n_train': n_train,
                'scores_train_mean': np.mean(scores_train, axis=1),
                'scores_test_mean': np.mean(scores_test, axis=1),
                'scores_train_std': np.std(scores_train, axis=1),
                'scores_test_std': np.std(scores_test, axis=1)})
            .assign(
                scores_train_lower = lambda df: df.scores_train_mean - df.scores_train_std,
                scores_train_upper = lambda df: df.scores_train_mean + df.scores_train_std,
                scores_test_lower = lambda df: df.scores_test_mean - df.scores_test_std,
                scores_test_upper = lambda df: df.scores_test_mean + df.scores_test_std))
        return stats

    def _plot_learning_curve(self,
                             ax: Axes,
                             stats: pd.DataFrame,
                             scores_train: np.array,
                             scores_test: np.array) -> Axes:
        if self.show_individual_runs:
            for scores in scores_train.T:
                ax.plot(stats.n_train,
                        scores,
                        '-',
                        color=self.colors[0],
                        alpha=0.1)
            for scores in scores_test.T:
                ax.plot(stats.n_train,
                        scores,
                        '-',
                        color=self.colors[1],
                        alpha=0.1)
        # Mean scores
        ax.plot(stats.n_train,
                stats.scores_train_mean,
                'o-',
                color=self.colors[0],
                label='Training mean')
        ax.plot(stats.n_train,
                stats.scores_test_mean,
                'o-',
                color=self.colors[1],
                label='Test mean')
        return ax

    def _format_plot(self, ax: Axes) -> Axes:
        ax.set_title('Learning Curve')
        ax.set_xlabel('Training samples')
        ax.set_ylabel('Score')
        ax.legend(loc='best')
        ax.grid(self.show_grid)
        return ax


class ILearningPerformance(ABC):
    """Interface for learning performance plotter

    :param color: Color
    :param show_individual_runs: Show individual cross validation runs
    :param show_grid: Show grid lines on plot
    """
    def __init__(self,
                 color: Color = sns.color_palette('colorblind')[0],
                 show_individual_runs: bool = False,
                 show_grid: bool = True):
        self.color = color
        self.show_individual_runs = show_individual_runs
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             scores_test: np.array,
             times_fits: np.array,
             ax: Optional[Axes] = None
             ) -> Axes:
        """Create learning curve

        :param scores_test: Scores on test sets
        :param times_fits: Fitting times in seconds
        :param ax: Optional axes object to draw the plot onto
        :return: Axes
        """
        pass


class LearningPerformance(ILearningPerformance):
    """Learning performance"""

    def plot(self,
             scores_test: np.array,
             times_fits: np.array,
             ax: Optional[Axes] = None
             ) -> Axes:
        if ax is None:
            ax = create_axes()
        stats = self._prepare_stats(scores_test=scores_test,
                                    times_fits=times_fits)
        ax = self._plot_learning_performance(ax=ax,
                                             stats=stats,
                                             scores_test=scores_test)
        ax = self._format_plot(ax=ax)
        return ax

    @staticmethod
    def _prepare_stats(scores_test: np.array,
                       times_fits: np.array
                       ) -> pd.DataFrame:
        stats = (
            pd.DataFrame({
                'times_fits_mean': np.mean(times_fits, axis=1),
                'scores_test_mean': np.mean(scores_test, axis=1),
                'scores_test_std': np.std(scores_test, axis=1)})
            .assign(
                scores_test_lower = lambda df: df.scores_test_mean - df.scores_test_std,
                scores_test_upper = lambda df: df.scores_test_mean + df.scores_test_std))
        return stats

    def _plot_learning_performance(self,
                                   ax: Axes,
                                   stats: pd.DataFrame,
                                   scores_test: np.array,
                                   ) -> Axes:
        if self.show_individual_runs:
            for scores in scores_test.T:
                ax.plot(stats.times_fits_mean,
                        scores,
                        '-',
                        color=self.color,
                        alpha=0.1)
        # Mean scores
        ax.plot(stats.times_fits_mean,
                stats.scores_test_mean,
                'o-',
                color=self.color)
        return ax

    def _format_plot(self, ax: Axes) -> Axes:
        ax.set_title('Learning Performance')
        ax.set_xlabel('Fitting time [s]')
        ax.set_ylabel('Score')
        ax.grid(self.show_grid)
        return ax


class ILearningScaling(ABC):
    """Interface for learning scaling plotter

    :param color: Color
    :param show_individual_runs: Show individual cross validation runs
    :param show_grid: Show grid lines on plot
    """
    def __init__(self,
                 color: Color = sns.color_palette('colorblind')[0],
                 show_individual_runs: bool = False,
                 show_grid: bool = True):
        self.color = color
        self.show_individual_runs = show_individual_runs
        self.show_grid = show_grid

    @abstractmethod
    def plot(self,
             scores_test: np.array,
             times_fits: np.array,
             ax: Optional[Axes] = None
             ) -> Axes:
        """Create learning scaling

        :param scores_test: Scores on test sets
        :param times_fits: Fitting times in seconds
        :param ax: Optional axes object to draw the plot onto
        :return: Axes
        """
        pass


class LearningScaling(ILearningScaling):

    def plot(self,
             n_train: int,
             times_fits: np.array,
             ax: Optional[Axes] = None
             ) -> Axes:
        if ax is None:
            ax = create_axes()
        stats = self._prepare_stats(n_train=n_train,
                                    times_fits=times_fits)
        ax = self._plot_learning_scaling(ax=ax,
                                         stats=stats,
                                         times_fits=times_fits)
        ax = self._format_plot(ax=ax)
        return ax

    @staticmethod
    def _prepare_stats(n_train: np.array,
                       times_fits: np.array
                       ) -> pd.DataFrame:
        stats = (
            pd.DataFrame({
                'n_train': n_train,
                'times_fits_mean': np.mean(times_fits, axis=1),
                'times_fits_std': np.std(times_fits, axis=1)})
            .assign(
                times_fits_lower = lambda df: df.times_fits_mean - df.times_fits_std,
                times_fits_upper = lambda df: df.times_fits_mean + df.times_fits_std))
        return stats

    def _plot_learning_scaling(self,
                               ax: Axes,
                               stats: pd.DataFrame,
                               times_fits: np.array) -> Axes:
        if self.show_individual_runs:
            for times_fit in times_fits.T:
                ax.plot(stats.n_train,
                        times_fit,
                        '-',
                        color=self.color,
                        alpha=0.1)
        # Mean fitting times
        ax.plot(stats.n_train,
                stats.times_fits_mean,
                'o-',
                color=self.color)
        return ax

    def _format_plot(self, ax: Axes) -> Axes:
        ax.set_title('Learning Scaling')
        ax.set_xlabel('Training samples')
        ax.set_ylabel('Fitting time [s]')
        ax.grid(self.show_grid)
        return ax


class LearningPlotter:
    """Create (multiple) learning measure plot(s)

    :param measures: List of learning measures (curve, performance, scaling)
    :param colors: Colors
    :param show_individual_runs: Show individual cross validation runs
    :param show_grid: Show grid lines on plots
    :param n_rows: Number of rows on figure
    :param n_cols: Number of cols on figure
    :param w: Figure width in inches
    :param h: Figure height in inches
    """

    def __init__(self,
                 measures: Union[str, LearningMeasure, LearningMeasures] = "all",
                 colors: Colors = sns.color_palette('colorblind'),
                 show_individual_runs: bool = True,
                 show_grid: bool = True,
                 n_rows: int = 1,
                 n_cols: int = 3,
                 w: float = 11.69,
                 h: float = 8.27):
        self.plotter_learning_curve: ILearningCurve = LearningCurve()
        self.plotter_learning_performance: ILearningPerformance = LearningPerformance()
        self.plotter_learning_scaling: ILearningScaling = LearningScaling()

        self.measures = measures
        self.colors = colors
        self.show_individual_runs = show_individual_runs
        self.show_grid = show_grid

        self._plot_grid_builder = PlotGridBuilder(n_rows= n_rows,
                                                  n_cols= n_cols,
                                                  w = w,
                                                  h = h)

    @property
    def measures(self):
        return self._measures

    @measures.setter
    def measures(self, measures):
        self._measures = self._convert_measures(measures=measures)

    @property
    def colors(self):
        return self._colors

    @colors.setter
    def colors(self, colors):
        self._colors = colors
        self.plotter_learning_curve.colors = colors
        self.plotter_learning_performance.color = colors[0]
        self.plotter_learning_scaling.color = colors[0]

    @property
    def show_individual_runs(self):
        return self._show_individual_runs

    @show_individual_runs.setter
    def show_individual_runs(self, show_individual_runs):
        self._show_individual_runs = show_individual_runs
        self.plotter_learning_curve.show_individual_runs = show_individual_runs
        self.plotter_learning_performance.show_individual_runs = show_individual_runs
        self.plotter_learning_scaling.show_individual_runs = show_individual_runs

    @property
    def show_grid(self):
        return self._show_grid

    @show_grid.setter
    def show_grid(self, show_grid):
        self._show_grid = show_grid
        self.plotter_learning_curve.show_grid = show_grid
        self.plotter_learning_performance.show_grid = show_grid
        self.plotter_learning_scaling.show_grid = show_grid

    @property
    def n_rows(self):
        return self._plot_grid_builder.n_rows

    @n_rows.setter
    def n_rows(self, n_rows):
        self._plot_grid_builder.n_rows = n_rows

    @property
    def n_cols(self):
        return self._plot_grid_builder.n_cols

    @n_cols.setter
    def n_cols(self, n_cols):
        self._plot_grid_builder.n_cols = n_cols

    @property
    def w(self):
        return self._plot_grid_builder.w

    @w.setter
    def w(self, w):
        self._plot_grid_builder.w = w

    @property
    def h(self):
        return self._plot_grid_builder.h

    @h.setter
    def h(self, h):
        self._plot_grid_builder.h = h

    def plot(self,
             n_train: int,
             scores_train: np.array,
             scores_test: np.array,
             times_fits: np.array,
             file_path: Optional[str] = None
             ) -> PlotGrids:
        """Create learning plots

        :param n_train: Number of trainings samples used for learning curve
        :param scores_train: Scores on training sets
        :param scores_test: Scores on test sets
        :param times_fits: Fitting times in seconds
        :param file_path: Output file path
        :return: Plot
        """
        plot_calls = self.create_plot_calls(n_train=n_train,
                                            scores_test=scores_test,
                                            scores_train=scores_train,
                                            times_fits=times_fits)
        plot_grids = self._plot_grid_builder.build(plot_calls=plot_calls)

        if file_path:
            save_plot_grids_to_pdf(plot_grids=plot_grids, file_path=file_path)

        return plot_grids

    @staticmethod
    def _convert_measures(measures: Union[str, List[str], LearningMeasure, LearningMeasures]
                          ) -> LearningMeasures:
        if measures == "all":
            return [LearningMeasure.curve,
                    LearningMeasure.performance,
                    LearningMeasure.scaling]
        if isinstance(measures, str):
            return [LearningMeasure[measures]]
        if isinstance(measures, list):
            return [LearningMeasure[measure] if isinstance(measure, str) else measure
                    for measure in measures]
        raise TypeError('measures must be list of LearningMeasure')

    def create_plot_calls(self,
                          n_train: np.array,
                          scores_test: np.array,
                          scores_train: np.array,
                          times_fits: np.array):
        plot_calls_by_measure = {
            LearningMeasure.curve:
                PlotFunctionCall(
                    function=self.plotter_learning_curve.plot,
                    kwargs={'n_train': n_train,
                            'scores_train': scores_train,
                            'scores_test': scores_test}
                ),
            LearningMeasure.performance:
                PlotFunctionCall(
                    function=self.plotter_learning_performance.plot,
                    kwargs={'scores_test': scores_test,
                            'times_fits': times_fits}
                ),
            LearningMeasure.scaling:
                PlotFunctionCall(
                    function=self.plotter_learning_scaling.plot,
                    kwargs={'n_train': n_train,
                            'times_fits': times_fits}
                )
        }
        return [plot_call for measure, plot_call in plot_calls_by_measure.items()
                if measure in self.measures]
