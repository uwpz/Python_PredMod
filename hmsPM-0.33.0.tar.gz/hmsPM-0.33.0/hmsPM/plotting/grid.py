"""Page plotting"""

from more_itertools import chunked
from typing import Union, Tuple, Callable

import numpy as np
from matplotlib import pyplot as plt
from matplotlib.axes import Axes
from matplotlib.figure import Figure

from hmsPM.datatypes import PlotGrid, PlotGrids, PlotFunctionCalls, SinglePlot


class PlotGridBuilder:
    """
    Creates plots and arranges plot grid(s) as specified by style parameters.

    :param n_rows: Number of rows on PDF page
    :param n_cols: Number of cols on PDF page
    :param w: PDF width in inches
    :param h: PDF height in inches
    """

    def __init__(self,
                 n_rows: int = 1,
                 n_cols: int = 1,
                 w: float = 8,
                 h: float = 6):
        self.n_rows = n_rows
        self.n_cols = n_cols
        self.w = w
        self.h = h

    def build(self, plot_calls: PlotFunctionCalls) -> PlotGrids:
        """
        Build one or multiple plot grid(s) with multiple plots.

        :param plot_calls: List of plot function calls with the according arguments
        :return: List of figures and list of subplot axes; each list element corresponds to one page. With multiple
            subplots per page, the Axes object is an array of Axes objects.
        """

        n_plots_per_page = self.n_rows * self.n_cols
        plot_grids = [
            self._plot_grid(plot_calls = plot_calls_per_page, n_plots_per_page = n_plots_per_page)
            for i_page, plot_calls_per_page in enumerate(chunked(plot_calls, n = n_plots_per_page))
        ]
        return plot_grids

    def _plot_grid(self, plot_calls: PlotFunctionCalls, n_plots_per_page: int) -> PlotGrid:
        fig, ax = self._create_multi_plot_page(n_rows=self.n_rows, n_cols=self.n_cols)
        self._set_page_format(fig=fig, w=self.w, h=self.h)
        for i_plot_on_page, plot_call in enumerate(plot_calls):
            plot_ax = self._extract_plot_axis(ax, i_plot_on_page)
            plot_call.function(ax=plot_ax, **plot_call.kwargs)
        self._remove_unused_axes(ax=ax,
                                 n_plots_on_page=len(plot_calls),
                                 n_plots_per_page=n_plots_per_page)
        self._finalize_page(fig=fig)
        return PlotGrid(figure=fig, axes=ax)

    @staticmethod
    def _extract_plot_axis(ax: Union[Axes, np.ndarray], i_plot_on_page: int) -> Axes:
        if isinstance(ax, np.ndarray):
            return ax.flat[i_plot_on_page]
        else:
            return ax

    @staticmethod
    def _create_multi_plot_page(n_rows: int, n_cols: int) -> Union[Tuple[Figure, Axes], Tuple[Figure, np.ndarray]]:
        """
        Create new page with multiple subplots.

        The second tuple value is either a single Axes object in case of a
        single plot or a np.ndarray of Axes for multiple plots.

        :return: Figure and axes
        """
        fig, ax = plt.subplots(nrows = n_rows, ncols = n_cols)
        return fig, ax

    @staticmethod
    def _set_page_format(fig, w: float, h: float):
        fig.set_size_inches(w = w, h = h)

    @staticmethod
    def _remove_unused_axes(ax: Union[Axes, np.ndarray], n_plots_on_page: int, n_plots_per_page: int):
        for i_unused_axis in range(n_plots_on_page, n_plots_per_page):
            ax.flat[i_unused_axis].axis("off")

    @staticmethod
    def _finalize_page(fig: Figure):
        fig.tight_layout()


class SinglePlotBuilder:
    """
    Creates single plot as specified by style parameters.

    :param w: PDF width in inches
    :param h: PDF height in inches
    """

    def __init__(self,
                 w: float = 8,
                 h: float = 6):
        self.w = w
        self.h = h

    def build(self, plot_function: Callable, **kwargs) -> SinglePlot:
        """
        Build pages with single plot

        :param plot_function: Plot function with the according arguments
        :param kwargs: Arguments accepted by the passed plot function
        :return: List of figures and list of subplot axes; each list element corresponds to one page. With multiple
            subplots per page, the Axes object is an array of Axes objects.
        """
        fig, ax = plt.subplots()
        fig.set_size_inches(w = self.w, h = self.h)

        ax = plot_function(ax = ax, **kwargs)

        fig.tight_layout()

        return SinglePlot(figure = fig, axes = ax)
