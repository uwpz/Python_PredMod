"""Correlation plotting"""

from typing import Optional, Union

import pandas as pd
import seaborn as sns
from matplotlib.axes import Axes

from hmsPM.calculation.correlation import CorrelationMatrixCalculator
from hmsPM.datatypes import (
    CorrelationTypeCategorical,
    CorrelationTypeNumerical,
    FeatureScale,
    SinglePlot,
)
from hmsPM.plotting.grid import SinglePlotBuilder


class CorrelationPlotter:
    """
    Creates a correlation plot of input features according to given style parameters.

    Uses :class:`hmsPM.plotting.grid.SinglePlotBuilder` for plot initialisation and layout, and uses functions from
    `hmsPM.plotting.output` to save PDF file.

    :param cutoff: Cutoff threshold for features to be included in correlation
        plot - default = 0.
    :param n_cluster: Number of clusters for reordering of correlation matrix
    :param corr_type_categorical: Correlation type for categorical features:
        ``contingency``, ``cramersv`` - default = ``contingency``;
    :param corr_type_numerical: Correlation type for numerical features:
        ``spearman``, ``pearson`` - default = ``spearman``
    :param w: PDF width in inches
    :param h: PDF height in inches
    """

    def __init__(self,
                 cutoff: float = 0,
                 n_cluster: int = 5,
                 corr_type_categorical: Union[CorrelationTypeCategorical, str] = 'contingency',
                 corr_type_numerical: Union[CorrelationTypeNumerical, str] = 'spearman',
                 w: float = 8,
                 h: float = 6):
        super().__init__()
        self._correlation_matrix_calculator = CorrelationMatrixCalculator(cutoff = cutoff,
                                                                          n_cluster = n_cluster,
                                                                          corr_type_categorical = corr_type_categorical,
                                                                          corr_type_numerical = corr_type_numerical)
        self.cutoff = cutoff

        self._single_plot_builder = SinglePlotBuilder(w=w, h=h)

    @property
    def cutoff(self):
        return self._cutoff

    @cutoff.setter
    def cutoff(self, cutoff):
        self._cutoff = cutoff
        self._correlation_matrix_calculator.cutoff = cutoff

    @property
    def n_cluster(self):
        return self._correlation_matrix_calculator.n_cluster

    @n_cluster.setter
    def n_cluster(self, n_cluster):
        self._correlation_matrix_calculator.n_cluster = n_cluster

    @property
    def corr_type_categorical(self):
        return self._correlation_matrix_calculator.corr_type_categorical

    @corr_type_categorical.setter
    def corr_type_categorical(self, corr_type_categorical):
        self._correlation_matrix_calculator.corr_type_categorical = corr_type_categorical

    @property
    def corr_type_numerical(self):
        return self._correlation_matrix_calculator.corr_type_numerical

    @corr_type_numerical.setter
    def corr_type_numerical(self, corr_type_numerical):
        self._correlation_matrix_calculator.corr_type_numerical = corr_type_numerical

    @property
    def w(self):
        return self._single_plot_builder.w

    @w.setter
    def w(self, w):
        self._single_plot_builder.w = w

    @property
    def h(self):
        return self._single_plot_builder.h

    @h.setter
    def h(self, h):
        self._single_plot_builder.h = h

    def plot(self,
             features: Union[pd.Series, pd.DataFrame],
             feature_scale: Optional[Union[FeatureScale, str]] = None,
             file_path: Optional[str] = None) -> SinglePlot:
        """
        Create correlation plot for given features.

        The feature scale for the correlation calculation is detected
        automatically if all columns of the features dataframe are of the same
        scale. If the features are of mixed scales the :attr:`feature_scale`
        parameter needs to be specified.

        The created plot can be saved as PDF files by specifying the
        :attr:`file_path` parameter.

        :param features: Pandas dataframe with feature variables
        :param feature_scale: Feature scale (``numerical`` or ``categorical``)
            which is used to create correct correlation plot when input
            features have mixed feature scales - default = ``None``
        :param file_path: Output file path - default = ``None``
        :return: Plot for given features
        """
        page = self._single_plot_builder.build(plot_function=self._plot_correlation,
                                               features=features,
                                               feature_scale=feature_scale)

        if file_path:
            page.figure.savefig(file_path)

        return page

    def _plot_correlation(
            self,
            ax: Axes,
            features: pd.DataFrame,
            feature_scale: Optional[Union[FeatureScale, str]] = None) -> Axes:
        """
        Return correlation plot for given categorical features.

        :param ax: Axes
        :param features: Pandas dataframe with categorical features
        :return: Figure and axis
        """
        df_corr, corr_type = self._correlation_matrix_calculator.create_matrix(features = features,
                                                                               feature_scale = feature_scale)
        sns.heatmap(df_corr, annot = True, fmt = ".2f", cmap = "Blues", ax = ax)
        ax.set_yticklabels(labels = ax.get_yticklabels(), rotation = 0)
        ax.set_xticklabels(labels = ax.get_xticklabels(), rotation = 90)
        ax.set_title(f"{corr_type.name} (cutoff at {str(self.cutoff)})")
        return ax
