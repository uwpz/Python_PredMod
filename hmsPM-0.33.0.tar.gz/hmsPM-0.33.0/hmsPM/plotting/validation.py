"""Cross validation plotting"""

import re
from typing import Any, Dict, Optional
import warnings

import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.figure import Figure

from hmsPM.plotting.output import save_plot_grids_to_pdf
from hmsPM.datatypes import PlotGrid, PlotGrids
from hmsPM.utils import check_fields


class ValidationPlotter:
    """Create validation plot from scikit-learn cv results

    :param x_var: Feature
    :param column_var: Variable for column faceting
    :param style_var: Variable for color distinction
    :param row_var: Variable for row faceting
    :param color_var: Variable for color distinction
    :param show_gen_gap: Show generalization gap between train and test folds if true
    :param w: PDF width in inches
    :param h: PDF height in inches
    """

    def __init__(self,
                 x_var,
                 color_var: Optional[str] = None,
                 style_var: Optional[str] = None,
                 column_var: Optional[str] = None,
                 row_var: Optional[str] = None,
                 show_gen_gap: bool = False,
                 w: float = 11.69,
                 h: float = 8.27):
        self.x_var = x_var
        self.color_var = color_var
        self.style_var = style_var
        self.column_var = column_var
        self.row_var = row_var
        self.show_generalization_gap = show_gen_gap
        self.w = w
        self.h = h

        self._vars = [var for var in [x_var, color_var, style_var, column_var, row_var]
                      if var is not None]

        if self.show_generalization_gap and self.style_var:
            warnings.warn('The style_var is not used for a generalization gap plot')

    def plot(self,
             cv_results: Dict[str, Any],
             metric: str,
             file_path: Optional[str] = None
             ) -> PlotGrids:
        """Create validation plot from scikit-learn cv results

        :param cv_results: scikit-learn cross-validation results
        :param metric: Metric name
        :param file_path: Output file path
        :return: Plot
        """
        if self.show_generalization_gap:
            cv_data = self._prepare_generalization_gap_data(cv_results=cv_results, metric=metric)
            fig_gg = self._plot_generalization_gap(cv_data=cv_data, metric=metric)
            fig_ggd = self._plot_generalization_gap_difference(cv_data=cv_data, metric=metric)
            fig_gg.set_size_inches(w=self.w, h=self.h)
            fig_gg.tight_layout()
            fig_ggd.set_size_inches(w=self.w, h=self.h)
            fig_ggd.tight_layout()
            plot_grids = [PlotGrid(figure=fig_gg, axes=fig_gg.axes),
                          PlotGrid(figure=fig_ggd, axes=fig_ggd.axes)]
        else:
            cv_data = self._prepare_validation_data(cv_results=cv_results)
            fig = self._plot_validation(cv_data=cv_data, metric=metric)
            fig.set_size_inches(w=self.w, h=self.h)
            fig.tight_layout()
            plot_grids = [PlotGrid(figure=fig, axes=fig.axes)]

        if file_path:
            save_plot_grids_to_pdf(plot_grids=plot_grids, file_path=file_path)

        return plot_grids

    @staticmethod
    def _normalize_key_names(cv_results: Dict[str, Any]) -> Dict[str, Any]:
        cv_results = {re.sub('param_', '', key): value
                      for key, value in cv_results.items()}
        return cv_results

    def _prepare_validation_data(self, cv_results: Dict[str, Any]) -> pd.DataFrame:
        cv_results = self._normalize_key_names(cv_results)
        check_fields(data=cv_results, fields=self._vars, var_name='cv_results_')

        df_cv_results = pd.DataFrame.from_dict(cv_results)
        return df_cv_results

    def _prepare_generalization_gap_data(self, cv_results: Dict[str, Any], metric: str) -> pd.DataFrame:
        df_cv_results = self._prepare_validation_data(cv_results=cv_results)
        df_cv_results = (
            df_cv_results
            .rename(columns={"mean_test_" + metric: "test",
                             "mean_train_" + metric: "train"})
            .assign(train_test_score_diff=lambda x: x.train - x.test)
            .reset_index(drop=True))
        df_gen_gap = pd.melt(
            df_cv_results,
            id_vars=np.setdiff1d(df_cv_results.columns.values, ["test", "train"]),
            value_vars=["test", "train"],
            var_name="fold",
            value_name="score")
        return df_gen_gap

    def _hue(self, cv_results: pd.DataFrame) -> Optional[pd.Series]:
        hue = "#" + cv_results[self.color_var].astype('str') if self.color_var is not None else None
        return hue

    def _plot_validation(self,
                         cv_data: pd.DataFrame,
                         metric: str
                         ) -> Figure:
        style = cv_data[self.style_var] if self.style_var is not None else None
        return self._plot_facet_grid(
            cv_results=cv_data,
            x=self.x_var,
            y="mean_test_" + metric,
            style=style
        )

    def _plot_generalization_gap(self,
                                 cv_data: pd.DataFrame,
                                 metric: str
                                 ) -> Figure:
        return self._plot_facet_grid(
            cv_results=cv_data,
            x=self.x_var,
            y="score",
            y_label=metric,
            style=cv_data["fold"]
        )

    def _plot_generalization_gap_difference(self,
                                            cv_data: pd.DataFrame,
                                            metric: str,
                                            ) -> Figure:
        return self._plot_facet_grid(
            cv_results=cv_data,
            x=self.x_var,
            y="train_test_score_diff",
            y_label=metric + "_diff (train vs. test)"
        )

    def _plot_facet_grid(self,
                         cv_results: pd.DataFrame,
                         x: str,
                         y: str,
                         y_label: Optional[str] = None,
                         style: Optional[Any] = None,
                         **kwargs
                         ) -> Figure:
        y_label = y if y_label is None else y_label
        facet_grid = (
            sns.FacetGrid(
                cv_results,
                col=self.column_var,
                row=self.row_var,
                margin_titles=True,
                **kwargs
            )
            .map(
                sns.lineplot, x, y,
                hue=self._hue(cv_results),
                style=style,
                marker="o"
            )
            .add_legend()
            .set_ylabels(y_label)
        )
        return facet_grid.fig
