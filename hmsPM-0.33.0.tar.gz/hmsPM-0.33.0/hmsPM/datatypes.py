"""Types"""
from enum import Enum
from typing import Any, Callable, Dict, List, NamedTuple, Union, Tuple

import numpy as np
from matplotlib.axes import Axes
from matplotlib.figure import Figure


AxisLimits = Tuple[float, float]
AxesLimits = Tuple[float, float, float, float]
Color = Union[str, Tuple[float]]
Colors = Union[List[str], List[Tuple[float]]]
Ticks = List[float]


class SinglePlot(NamedTuple):
    figure: Figure
    axes: Axes


class PlotGrid(NamedTuple):
    figure: Figure
    axes: np.ndarray  # of Axes


PlotGrids = List[PlotGrid]


class PlotFunctionCall(NamedTuple):
    function: Callable
    kwargs: Dict[str, Any]


PlotFunctionCalls = List[PlotFunctionCall]


class FeatureScale(Enum):
    numerical = 'numerical'
    categorical = 'categorical'


class TargetType(Enum):
    classification = 'classification'
    multiclass = 'multiclass'
    regression = 'regression'


class CorrelationType(Enum):
    pass


class CorrelationTypeCategorical(CorrelationType):
    contingency = 'contingency'
    cramersv = 'cramersv'


class CorrelationTypeNumerical(CorrelationType):
    spearman = 'spearman'
    pearson = 'pearson'


class Dimension(Enum):
    x = 'x'
    y = 'y'


class InputDataType(Enum):
    pd_dataframe = 'pd.Dataframe'
    pd_series = 'pd.Series'
    np_ndarray = 'np.ndarray'
    none = 'none'


class LearningMeasure(Enum):
    curve = "learning_curve",
    performance = "learning_performance"
    scaling = "learning_scaling"


LearningMeasures = List[LearningMeasure]


class PerformanceMeasure(Enum):
    prediction_distribution = "prediction_distribution"
    roc_curve = "roc_curve"
    calibration = "calibration_curve"
    confusion_matrix = "confusion_matrix"
    precision_recall = "precision_recall_curve"
    precision = "precision_curve"
    model_metrics = "model_metrics_table"
    barplot_true = "barplot_true_labels_by_predicted_labels"
    barplot_pred = "barplot_predicted_labels_by_true_labels"
    observed_fitted = "scatterplot_observed_vs_fitted"
    residuals_fitted = "scatterplot_residuals_vs_fitted"
    abs_residuals_fitted = "scatterplot_absolute_residuals_vs_fitted"
    rel_residuals_fitted = "scatterplot_relative_residuals_vs_fitted"
    all = "all_metrics"
