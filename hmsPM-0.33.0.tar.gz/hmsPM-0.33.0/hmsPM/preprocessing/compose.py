"""Composing of multiple estimators"""

from typing import List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer as SKColumnTransformer

from hmsPM.utils import (
    detect_input_data_type,
)
from hmsPM.datatypes import (
    InputDataType,
)


class ColumnTransformer(SKColumnTransformer):
    """
    Applies transformers to columns of pandas DataFrame.

    This class uses the ColumnTransformer from scikit-learn to apply transformers to columns of a pandas DataFrame.

    Unlike the scikit-learn ColumnTransformer this class accepts pandas dataframe only and doesn't accept arrays;
    it returns a dataframe with the column names and dtypes of the input dataframe preserved (unless their scales
    were converted in the process of the transformation).

    All other parameters of this class are the same as those of the scikit-learn ColumnTransformer. For a description
    of the parameters, refer to the scikit-learn `docu
    <https://scikit-learn.org/stable/modules/generated/sklearn.compose.ColumnTransformer.html>`_.
    """
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._input_data_type = None

    def fit(self, *_):
        return self

    def fit_transform(self,
                      X: Union[pd.DataFrame, np.ndarray],
                      y: Optional[pd.Series] = None) -> pd.DataFrame:
        """
        Uses the fit_transform method from the scikit-learn ColumnTransformer to transform the columns in the
        input data according to attributes passed to the transformer. The transformed data is a numpy array but for a
        pandas dataframe input it is converted to a dataframe in which original column names and dtypes
        are preserved.

        Note that the fit_transform method from the scikit-learn ColumnTransformer returns an array in which
        all numerical columns are of dtype float. This means that in the returned dataframe of this method columns
        expected to be dtype int will be dtype float.

        :param X: Pandas data frame or numpy array to be transformed
        :param y: Pandas series or numpy array with target values used by some transformers; default = None
        :return: Transformed data frame
        """
        self._input_data_type = detect_input_data_type(x = X)

        if self._input_data_type == InputDataType.pd_series:
            raise TypeError("Input data to be transformed needs to be a dataframe or an array.")

        X_transformed = super().fit_transform(X, y)

        if self._input_data_type == InputDataType.pd_dataframe:
            # retrieve column names passed to transformer in the order required to create dataframe from transformed
            # matrix
            column_names_passed, column_names_dropped = self._get_column_names(X)
            column_names_reordered = column_names_passed + column_names_dropped
            column_names_original_order = list(X.columns.values)
            if self.remainder == 'drop':
                column_names_reordered = column_names_passed
                column_names_original_order = list(X.columns.drop(column_names_dropped).values)

            X_transformed = self._convert_array_to_dataframe(matrix_transformed=X_transformed,
                                                             column_names=column_names_reordered)

            # preserve index and column order of original data frame
            X_transformed = X_transformed.reindex_like(X).loc[:, column_names_original_order]
        return X_transformed

    @staticmethod
    def _convert_array_to_dataframe(matrix_transformed: np.ndarray, column_names: List[str]) -> pd.DataFrame:
        """
        Loops through column_names to create a dataframe from each column of matrix_transformed. This ensures that the
        dtypes from the matrix are preserved in the resulting dataframe and that the dataframe has the correct column
        names.

        The column_names parameter needs to be in the correct order so that the columns of the matrix_transformed are
        assigned the correct column names in the dataframe.

        :param matrix_transformed: Array returned from scikit-learn ColumnTransformer.fit_transform to be transformed
            to a dataframe
        :param column_names: Column names for the dataframe returned by the method
        :return: Pandas dataframe
        """
        df_transformed = pd.DataFrame()
        columns = matrix_transformed.transpose().tolist()
        for column, column_name in zip(columns, column_names):
            column_series = pd.Series(column, name = column_name)
            df_transformed = pd.concat([df_transformed, column_series], axis = 1)
        return df_transformed

    def _get_column_names(self, df: pd.DataFrame) -> Tuple[list, list]:
        """
        Extracts the column names that were passed to the column transformer in the order in which they were passed
        and returns them in this order; followed by the remaining column names of the dataframe that was passed
        to the transformer.

        :param df: Pandas dataframe that was passed to the transformer
        :return: Tuple of lists with names of columns passed and dropped
        """
        # access columns that were passed to transformers
        self._validate_column_callables(df)
        columns_list = self._columns
        column_names_passed = [column
                               for columns_sublist in columns_list
                               for column in columns_sublist]

        # create list of columns that were NOT passed to transformer
        column_names_dropped = list(df.columns.drop(column_names_passed).values)

        return column_names_passed, column_names_dropped
