"""Preprocessing of categorical features"""

import warnings
from typing import Any, Dict, List, Optional, Union, Iterable

import numpy as np
import pandas as pd
from sklearn.base import (
    BaseEstimator,
    TransformerMixin,
)

from hmsPM.utils import (
    detect_input_data_type,
)
from hmsPM.datatypes import (
    FeatureScale,
    InputDataType,
)
from hmsPM.preprocessing.base import PreprocessorMixin


class CategoryCollapser(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Collapses categorical variables of (specified) columns within input data to the specified number of the most
    frequent categories.

    This transformer can be used within a scikit-learn Pipeline.

    The transformation is performed on the categorical columns of the input data by default. Alternatively, the
    user can specify the columns to be converted by using the column_names parameter; note that the
    column_names parameter only works when the input data is a pandas data frame.

    By default, the top 10 most frequent categories are left intact for each column (n_top = 10) and all other less
    populated categories are grouped into one. Alternatively, the n_top parameter can be specified by the user.

    The grouped category is given the label "_OTHER_" by default which can be manually specified by using the
    'other_label' parameter.

    :param n_top: Integer specifying the n most frequent categories that should be retained; default = 10
    :param other_label: String label given to the new category consisting of all collapsed categories; default =
        '_OTHER_'
    :param column_names: List of column names to be transformed. If not specified all categorical columns will be
        transformed; default = None
    """
    def __init__(self,
                 n_top: Optional[int] = 10,
                 other_label: Optional[str] = "_OTHER_",
                 column_names: Optional[Union[str, List[str]]] = None):
        self.other_label = other_label
        self.n_top = n_top
        self.column_names = self._convert_column_names(column_names)
        self._top_categories: Dict[str, Any] = {}
        self._input_data_type = InputDataType.none

    def fit(self, X: Union[pd.DataFrame, pd.Series, np.ndarray], *_):
        """
        Fit the categories that will be collapsed on the (specified) categorical columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        """
        self._input_data_type = detect_input_data_type(x = X)

        df = self._convert_input_data_to_data_frame(X = X)

        self.column_names = self._validate_column_names(df = df,
                                                        column_names = self.column_names,
                                                        feature_scale = FeatureScale.categorical,
                                                        input_data_type = self._input_data_type)

        df_selected = self._select_columns(df=df, column_names = self.column_names)

        self._top_categories = self._get_top_categories(df = df_selected)

        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Perform collapsing of categories on the (specified) categorical columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Transformed pandas data frame, pandas series, or numpy array
        """
        df = self._convert_input_data_to_data_frame(X = X)

        df = df.apply(self._collapse_categories, top_categories=self._top_categories)

        X = self._convert_data_frame_to_input_data_type(df=df, input_data_type = self._input_data_type)

        return X

    def _collapse_categories(self, x: pd.Series, top_categories: dict) -> pd.Series:
        if x.name in top_categories.keys():
            is_missing = x.isna().to_numpy()
            is_in_top_categories = np.in1d(x, top_categories[x.name])
            is_in_top_categories_or_missing = is_missing | is_in_top_categories
            x.where(is_in_top_categories_or_missing,
                    other = self.other_label,
                    inplace = True)
        return x

    def _get_columns_with_too_many_categories(self, df: pd.DataFrame) -> List[str]:
        n_categories_per_column = df.apply(lambda x: x.unique().size).sort_values(ascending = False)

        columns_to_collapse = list(n_categories_per_column[n_categories_per_column > self.n_top].index.values)
        return columns_to_collapse

    def _get_top_categories(self, df: pd.DataFrame) -> Dict[str, Any]:
        columns_with_too_many_categories = self._get_columns_with_too_many_categories(df=df)

        top_categories = {column: df[column].value_counts().index.values[:self.n_top]
                          for column in columns_with_too_many_categories}
        return top_categories


class TargetEncoder(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Encodes categorical features within input data, by arranging with regard to the average target value before
    assigning consecutive numbers.

    This encoder can be used within a scikit-learn Pipeline.

    The fit method fits the encoder according to the given features and target. The encoding dictionary can be found in
    the target_encoding attribute. It contains the feature names as the keys and a dictionary for each feature name
    which maps the original label to the encoded label.

    By default, the function uses all rows to create the encoding. Alternatively, the subset_index parameter can be
    used to ensure only a subset of the input data is used to create the encoding. Note that it is advisable to
    create the target encoding on a subset of the data and to 'burn' the data used for the encoding subsequently, as
    they may lead to overfitting and should be disregarded for the further analytical process.

    The encoding is created for all categorical columns of the input features by default. Alternatively, the
    user can specify the features to be included in the encoding by using the feature_names parameter; note that the
    feature_names parameter only works when the input data is a pandas data frame.

    :param target_encoding: Dictionary to specify encoding. Each key has to be a feature name and each value has to be
        a dictionary with a mapping for each category. Example mapping:
        {'col1': {'a': 1, 'a': 2},
        'col2': {'aa': 1, 'bb': 2}}
    :param subset_index: Row index to create subset of the input data which is used to create encoding
    :param feature_names: List of feature names to be included in encoding. If not specified all categorical features
        will be used; default = None
    :param encode_missing: Boolean value to specify whether missing values should be encoded. If True, will encode
        missings as new category -2; default = False
    :param encode_unknown: Boolean value to specify whether unknown feature categories should be encoded. If true, will
        encode unknowns as new category -1, default = True
    """
    def __init__(self,
                 target_encoding: Optional[dict] = None,
                 subset_index: Optional[Iterable[int]] = None,
                 feature_names: Optional[Union[str, List[str]]] = None,
                 encode_missing: bool = False,
                 encode_unknown: bool = True):
        self._target_encoding = target_encoding
        self.subset_index = subset_index
        self.feature_names = self._convert_column_names(feature_names)
        self.encode_missing = encode_missing
        self.encode_unknown = encode_unknown
        self._input_data_type_features = InputDataType.none
        self._input_data_type_target = InputDataType.none

    @property
    def target_encoding(self):
        return self._target_encoding

    def fit(self, X: Union[pd.DataFrame, pd.Series, np.ndarray],
            y: Union[pd.Series, np.ndarray], *_):
        """
        Fit the target encoding that will be applied to the (specified) categorical columns of the input data.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :param y: Pandas series or numpy array with target variable
        """
        self._input_data_type_features = detect_input_data_type(x = X)
        self._input_data_type_target = detect_input_data_type(x = y)

        df = self._convert_input_data_to_data_frame(X = X)
        y = self._convert_input_data_to_series(x = y, name = "target")

        self.feature_names = self._validate_column_names(df = df,
                                                         column_names = self.feature_names,
                                                         feature_scale = FeatureScale.categorical,
                                                         input_data_type = self._input_data_type_features)

        df_encoding = self._prepare_encoding_data(features=df, target=y)

        self._target_encoding = self._create_target_encoding(df=df_encoding, feature_names=self.feature_names)
        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Perform target encoding on the (specified) categorical columns of the input data.

        :param df: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Transformed pandas data frame, pandas series, or numpy array
        """
        df = self._convert_input_data_to_data_frame(X = X)

        # update target encoding to handle unknowns in data
        self._target_encoding = self._update_target_encoding(df = df,
                                                             target_encoding = self.target_encoding,
                                                             encode_unknown = self.encode_unknown)

        df_encoded = df[self.feature_names].apply(self._encode_feature,
                                                  target_encoding=self.target_encoding)

        self._set_columns(df = df, df_replace = df_encoded, column_names = self.feature_names)

        X = self._convert_data_frame_to_input_data_type(df=df, input_data_type = self._input_data_type_features)

        return X

    def _create_target_encoding(self, df: pd.DataFrame, feature_names: List[str]) -> dict:
        if self.target_encoding is None:
            df_subset = self._subset_dataframe(df = df, subset_index = self.subset_index)
            target_encoding = {}
            for feature_name in feature_names:
                target_encoding[feature_name] = (df_subset.reset_index(drop = True)
                                                 .groupby(feature_name, as_index = False)["target_class"].agg("mean")
                                                 .sort_values("target_class", ascending = False)
                                                 .assign(rank = lambda x: np.arange(len(x)) + 1)
                                                 .set_index(feature_name)["rank"]
                                                 .to_dict())
        else:
            self._check_target_encoding(target_encoding = self.target_encoding, feature_names = feature_names)
            target_encoding = self.target_encoding
        target_encoding = self._treat_missing_values(target_encoding = target_encoding,
                                                     encode_missing = self.encode_missing)
        return target_encoding

    def _check_target_encoding(self, target_encoding: dict, feature_names: List[str]):
        if not isinstance(target_encoding, dict):
            raise ValueError("Target encoding must be of type dictionary.")
        for key, value in target_encoding.items():
            if not isinstance(value, dict):
                raise ValueError("At least one of the values in the specified encoding dictionary is an invalid type. "
                                 "Values must be dictionaries with mappings of the original categories to the encoded "
                                 "categories.")
            if key not in feature_names:
                raise ValueError(f"The key '{key}' in the specified encoding dictionary is not a valid column "
                                 "name of the passed features.")
        unspecified_columns = set(feature_names) - set(target_encoding.keys())
        if len(unspecified_columns) > 0:
            warnings.warn(f"Not all feature are specified in the encoding dictionary. The original feature(s) will be "
                          f"returned. The unspecified columns are {unspecified_columns}")
            # update feature names according to keys in specified target encoding
            self.feature_names = list(target_encoding.keys())

    @staticmethod
    def _encode_feature(x: pd.Series, target_encoding: dict) -> pd.Series:
        return x.map(target_encoding[x.name])

    @staticmethod
    def _prepare_encoding_data(features: pd.DataFrame, target: pd.Series) -> pd.DataFrame:
        df = features.copy()
        df["target_class"] = target
        if target.nunique() > 2:
            # Take majority class in case of MULTICLASS target
            df["target_class"] = np.where(target == target.value_counts().values[0], 1, 0)
        return df

    @staticmethod
    def _subset_dataframe(df: pd.DataFrame, subset_index: Optional[Iterable[int]] = None) -> pd.DataFrame:
        df_subset = df
        if subset_index is not None:
            df_subset = df.iloc[subset_index, :].reset_index(drop = True)
        return df_subset

    @staticmethod
    def _treat_missing_values(target_encoding: dict, encode_missing: bool) -> dict:
        if encode_missing:
            for encoding in target_encoding.values():
                encoding[np.nan] = -2
        return target_encoding

    @staticmethod
    def _update_target_encoding(df: pd.DataFrame, target_encoding: dict, encode_unknown: bool) -> dict:
        for key, value in target_encoding.items():
            feature_categories = df[key].dropna().unique()
            encoding_categories = np.fromiter(value.keys(), dtype = '<U9')
            unknown_categories = np.setdiff1d(feature_categories, encoding_categories)
            if unknown_categories.size > 0:
                for unknown in unknown_categories.tolist():
                    if encode_unknown:
                        value[unknown] = -1
                    else:
                        value[unknown] = np.nan
        return target_encoding
