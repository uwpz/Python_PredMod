"""Converting of data types"""

from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.base import (
    BaseEstimator,
    TransformerMixin,
)
from sklearn.preprocessing import OneHotEncoder

from hmsPM.preprocessing.base import PreprocessorMixin
from hmsPM.utils import (
    detect_input_data_type,
    get_column_names_by_scale,
)
from hmsPM.datatypes import (
    InputDataType,
    FeatureScale,
)


class ScaleConverter(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Converts scale of given features within input data

    This converter can be used within a scikit-learn Pipeline.

    The scale conversion is performed on all columns of the input data by default. Alternatively, the
    user can specify the columns to be converted by using the column_names parameter; note that the
    column_names parameter only works when the input data is a pandas data frame.

    :param column_names: List of column names to be transformed. If not specified all columns will be
        converted; default = None
    :param scale: Feature scale: 'numerical' or 'categorical'
    """
    def __init__(self,
                 scale: Union[str, FeatureScale],
                 column_names: Optional[List[str]] = None):
        self.column_names = self._convert_column_names(column_names)
        self.scale = FeatureScale(scale)

        self._input_data_type: InputDataType = InputDataType.none

    def fit(self, *_):
        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Perform scale conversion on the (specified) columns of the input data. Columns are converted to 'numerical' or
        'categorical' depending on the scale parameter.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Transformed pandas data frame, pandas series, or numpy array
        """
        self._input_data_type = detect_input_data_type(x = X)

        df = self._convert_input_data_to_data_frame(X = X)

        self.column_names = self._validate_column_names(df = df,
                                                        column_names = self.column_names,
                                                        input_data_type = self._input_data_type)

        df_selected = self._select_columns(df=df, column_names = self.column_names)

        if self.scale == FeatureScale.numerical:
            if self._input_data_type == InputDataType.np_ndarray:
                df_selected.replace('nan', np.nan, inplace = True)
            df_converted = df_selected.apply(pd.to_numeric)
            bool_cols = df_converted.dtypes == np.bool
            df_converted.loc[:, bool_cols] = df_converted.loc[:, bool_cols].astype('int64')
        if self.scale == FeatureScale.categorical:
            df_converted = df_selected.astype('str')
            df_converted = df_converted.replace("nan", np.nan)

        self._set_columns(df = df, df_replace = df_converted, column_names = self.column_names)

        X = self._convert_data_frame_to_input_data_type(df=df, input_data_type = self._input_data_type)

        return X


class MatrixConverter(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Converts input data to sparse matrix.

    This converter can be used within a scikit-learn Pipeline.

    By default, a sparse matrix is created from the input data. Alternatively, a dense matrix can be created if the
    :attr:`sparse` parameter is set to False.

    :param sparse: Boolean to specify output format of matrix, if true output matrix is sparse - default = ``True``.
    """
    def __init__(self,
                 to_sparse: bool = True):
        self.to_sparse = to_sparse

        self.column_names_num: List[str] = []
        self.column_names_cat: List[str] = []
        self.categories_categorical_features: Dict[str, Any] = {}
        self._input_data_type = InputDataType.none

    def fit(self, X: Union[pd.DataFrame, pd.Series, np.ndarray], *_):
        """
        Fit conversion of input data into (sparse) matrix.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        """
        df = self._convert_input_data_to_data_frame(X = X)

        self.column_names_num = get_column_names_by_scale(features = df,
                                                          feature_scale = FeatureScale.numerical)
        self.column_names_cat = get_column_names_by_scale(features = df,
                                                          feature_scale = FeatureScale.categorical)

        if self.column_names_cat is not None and len(self.column_names_cat) > 0:
            self.categories_categorical_features = {x: df[x].unique() for x in self.column_names_cat}

        return self

    def transform(self,
                  X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[sparse.csr_matrix, np.ndarray]:
        """
        Perform conversion of input data into (sparse) matrix.

        :param X: Pandas data frame, pandas series, or numpy array to be transformed
        :return: Matrix
        """
        m_num = None
        m_cat = None

        df = self._convert_input_data_to_data_frame(X = X)

        if self.column_names_num is not None and len(self.column_names_num) > 0:
            m_num = self._convert_to_numerical_matrix(df=df[self.column_names_num],
                                                      to_sparse=self.to_sparse)

        if self.column_names_cat is not None and len(self.column_names_cat) > 0:
            m_cat = self._convert_to_categorical_matrix(df=df[self.column_names_cat],
                                                        category_values=self.categories_categorical_features.values(),
                                                        to_sparse=self.to_sparse)

        matrix = self._stack_matrices(m_cat=m_cat, m_num=m_num, to_sparse=self.to_sparse)

        return matrix

    @staticmethod
    def _stack_matrices(m_cat: Union[sparse.csr_matrix, np.ndarray],
                        m_num: Union[sparse.csr_matrix, np.ndarray],
                        to_sparse: bool):
        if to_sparse:
            matrix = sparse.hstack([m_num, m_cat], format = "csr")
        else:
            matrix = np.hstack([m_num, m_cat])
        return matrix

    @staticmethod
    def _convert_to_numerical_matrix(df: pd.DataFrame,
                                     to_sparse: bool) -> Union[sparse.csr_matrix, np.ndarray]:
        if to_sparse:
            m_num = sparse.csr_matrix(df.values)
        else:
            m_num = df.to_numpy()
        return m_num

    @staticmethod
    def _convert_to_categorical_matrix(df: pd.DataFrame,
                                       category_values: np.ndarray,
                                       to_sparse: bool) -> Union[sparse.csr_matrix, np.ndarray]:
        enc = OneHotEncoder(categories = list(category_values), sparse = to_sparse)
        m_cat = enc.fit_transform(df, y = None)
        return m_cat
