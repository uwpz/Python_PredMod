"""Resampling for imbalanced data"""

from typing import Optional, Union

import pandas as pd
import numpy as np
from sklearn.base import (
    BaseEstimator,
    TransformerMixin,
)

from hmsPM.utils import detect_target_type
from hmsPM.datatypes import TargetType
from hmsPM.preprocessing.base import PreprocessorMixin


class Undersampler(BaseEstimator, TransformerMixin, PreprocessorMixin):
    """
    Undersample imbalanced data

    Data are undersampled by each target value up to the specified maximum number of samples per target level by
    randomly picking sample values without replacement in order to deal with highly imbalanced target classes. Hence,
    this transformer can only be applied to (multiclass) classification targets.

    If not specified, the maximum number of samples per target level n_max_per_level is set to the number of the
    minority class.

    In addition, the original (:attr:`b_all`) and sampled (:attr:`b_sample`) target class proportions are determined.

    :param n_max_per_level: Maximum number of samples per target level
    :param random_state: Determine random number generation for reproducible results
    """
    def __init__(self,
                 n_max_per_level: Optional[int] = None,
                 random_state: Optional[Union[int, np.random.RandomState]] = None):
        self.n_max_per_level = n_max_per_level
        self.random_state = random_state

        self.b_sample: Optional[np.ndarray] = None
        self.b_all: Optional[np.ndarray] = None
        self.sample_index: Optional[np.ndarray] = None

    def fit(self, X: Union[pd.DataFrame, pd.Series, np.ndarray], y: Union[pd.Series, np.ndarray], *_):
        if y is None:
            raise ValueError('Undersampling requires a (multiclass) classification target.')

        self._check_target_type(target = y)
        y_name = y.name if isinstance(y, pd.Series) else 'target'
        y = self._convert_input_data_to_series(x = y, name = y_name)
        df = self._convert_input_data_to_data_frame(X = X)

        n_max_per_level = self.n_max_per_level
        if n_max_per_level is None:
            # Set default maximum number of samples per target level to count of minority class
            n_max_per_level = y.value_counts().min()

        self.sample_index = self._undersample_index(X = df, y = y,
                                                    n_max_per_level=n_max_per_level,
                                                    random_state=self.random_state)

        self.b_all = self._calculate_class_proportion(y = y)
        self.b_sample = self._calculate_class_proportion(y = y[self.sample_index])
        return self

    def transform(self, X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> Union[pd.DataFrame, pd.Series, np.ndarray]:
        """
        Undersample data.

        :param X: Features to be sampled
        :return: Sampled features
        """
        if isinstance(X, pd.DataFrame):
            return X.iloc[self.sample_index]
        return X[self.sample_index]

    @staticmethod
    def _check_target_type(target: Union[pd.Series, np.ndarray]):
        target_type = detect_target_type(x = target)
        if target_type == TargetType.regression:
            raise ValueError("Regression target detected. "
                             "Undersampling can only be performed on (multiclass) classification targets.")

    @staticmethod
    def _calculate_class_proportion(y: pd.Series) -> np.array:
        class_counts = y.value_counts().values
        return class_counts / len(y)

    def _undersample_index(self,
                           X: pd.DataFrame,
                           y: pd.Series,
                           n_max_per_level: int,
                           random_state: Optional[Union[int, np.random.RandomState]] = None
                           ) -> pd.DataFrame:
        sample_index = (
            # get index
            pd.Series(X.index)
            # stratify by target values
            .groupby(y)
            # sample by target level stratum
            .apply(self._sample_stratum, n_max_per_level = n_max_per_level, random_state = random_state)
            # remove grouped target value index
            .reset_index(drop = True)
            # shuffle sampled indices from different target values
            .sample(frac = 1, random_state = random_state)
            .astype(int)
            .values)
        return sample_index

    @staticmethod
    def _sample_stratum(x: pd.Series,
                        n_max_per_level: int,
                        random_state: Optional[Union[int, np.random.RandomState]] = None):
        return x.sample(n = min(n_max_per_level, x.shape[0]),
                        replace = False,
                        random_state = random_state)
