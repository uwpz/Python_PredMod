import warnings
from typing import Optional, Union

import numpy as np
import pandas as pd


def is_na_row(x: Union[list, np.ndarray, pd.Series, pd.DataFrame]):
    """Detect missing values in array (rows)"""
    missing_index = pd.isnull(x)
    if missing_index.ndim > 1:
        missing_index = (np.sum(missing_index, axis=1) > 0)
    return missing_index


def is_na_col(x: Union[list, np.ndarray, pd.Series, pd.DataFrame]):
    """Detect missing values in array (rows)"""
    missing_index = pd.isnull(x)
    if missing_index.ndim > 1:
        missing_index = (np.sum(missing_index, axis=0) > 0)
    else:
        missing_index = np.array([(missing_index.sum() > 0)])
    return missing_index


def _subset_values(x, index):
    """Subset values of array-like object by boolean index"""
    if type(x) is list:
        return [e for e, select in zip(x, index) if select]
    return x[index]


def _get_names(x) -> np.ndarray:
    if isinstance(x, pd.Series):
        return np.array([x.name])
    if isinstance(x, pd.DataFrame):
        return x.columns.values
    return np.array([])


def remove_na(x: Union[list, np.ndarray, pd.Series, pd.DataFrame],
              y: Optional[Union[list, np.ndarray, pd.Series, pd.DataFrame]] = None,
              warn: bool = True):
    """
    Remove missing values from array (rows)

    If another array object is passed, missing values/rows from both arrays are removed. Both arrays needs to have the
    same length. The original data types are preserved.

    :param x: Array to-be-cleaned
    :param y: Optional array to-be-cleaned together with x
    :param warn: Raise warnings if values are removed
    :return: (Tuple of) Array(s) without missing values
    """
    rows_with_missings = is_na_row(x)
    names = np.array([])
    if isinstance(x, pd.Series) or isinstance(x, pd.DataFrame):
        names = _get_names(x)[is_na_col(x)]
    if y is not None:
        if len(x) != len(y):
            raise ValueError('x and y need to have the same length')
        y_rows_with_missings = is_na_row(y)
        rows_with_missings = rows_with_missings | y_rows_with_missings
        if isinstance(y, pd.Series) or isinstance(y, pd.DataFrame):
            names = np.append(names, _get_names(y)[is_na_col(y)])
    n_missings = sum(rows_with_missings)
    if warn and n_missings == len(x):
        warnings.warn('All values are missing. Removed all values.', UserWarning)
    elif warn and n_missings:
        name_list = names.tolist()
        warnings.warn(f'Removed {n_missings} row' +
                      ('s' if n_missings > 1 else '') +
                      ' with missing values' +
                      (f' in {", ".join(name_list)}' if name_list else ''),
                      UserWarning)
    x = _subset_values(x, ~ rows_with_missings)
    if y is not None:
        y = _subset_values(y, ~ rows_with_missings)
        return x, y
    return x
