"""Base functionalities for hmsPM.preprocessing"""

from typing import Optional, List, Union

import pandas as pd
import numpy as np

from hmsPM.datatypes import (
    InputDataType,
    FeatureScale,
)
from hmsPM.utils import (
    select_features_by_scale,
    detect_feature_scales,
    detect_input_data_type,
)


class PreprocessorMixin:
    """Mixin class for transformers in hmsPM.preprocessing."""

    @staticmethod
    def _convert_data_frame_to_input_data_type(df: pd.DataFrame, input_data_type: InputDataType) -> Union[pd.DataFrame,
                                                                                                          pd.Series,
                                                                                                          np.ndarray]:
        if input_data_type == InputDataType.np_ndarray:
            df = df.to_numpy()
        if input_data_type == InputDataType.pd_series:
            remove_series_name = type(df.columns) == pd.RangeIndex
            df = df.iloc[:, 0]
            if remove_series_name:
                df.name = None
        return df

    @staticmethod
    def _convert_series_to_input_data_type(y: pd.Series, input_data_type: InputDataType) -> Union[pd.Series,
                                                                                                  np.ndarray]:
        if input_data_type == InputDataType.np_ndarray:
            y = y.to_numpy()
        return y

    @staticmethod
    def _convert_input_data_to_data_frame(X: Union[pd.DataFrame, pd.Series, np.ndarray]) -> pd.DataFrame:
        df = pd.DataFrame(X)
        if isinstance(X, np.ndarray):
            df = pd.DataFrame()
            # Transpose to extract columns to loop through - needed to preserve dtypes of columns
            columns = X.transpose().tolist()
            for col_idx, column in enumerate(columns):
                column_series = pd.Series(column, name = col_idx)
                df = pd.concat([df, column_series], axis = 1)
        return df

    @staticmethod
    def _convert_input_data_to_series(x: Union[pd.DataFrame, pd.Series, np.ndarray], name = str) -> pd.Series:
        if isinstance(x, np.ndarray):
            if len(np.shape(x)) > 1:
                raise ValueError(
                    "Can't convert input data to series; data must be 1-dimensional.")
            x = pd.Series(x, name = name)
        if isinstance(x, pd.DataFrame):
            if len(x.columns) > 1:
                raise ValueError(
                    "Can't convert input data to series; data must be 1-dimensional.")
            x = x.iloc[:, 0]
        return x

    @staticmethod
    def _select_columns(df: pd.DataFrame, column_names: List[str]) -> pd.DataFrame:
        if len(column_names) == 0:
            return df
        return df.loc[:, column_names]

    @staticmethod
    def _set_columns(df: pd.DataFrame, df_replace: Union[pd.DataFrame, np.array], column_names: List[str]):
        n_column_names = len(column_names)

        data_type_replace = detect_input_data_type(df_replace)
        n_columns_replace = 0
        if data_type_replace == InputDataType.pd_dataframe:
            n_columns_replace = len(df_replace.columns)
        elif data_type_replace == InputDataType.np_ndarray:
            n_columns_replace = np.size(df_replace, 1)

        if not n_column_names == n_columns_replace:
            raise ValueError("Number of column names and number of columns to be replaced is inconsistent. Can't "
                             "replace columns.")

        invalid_column_names = np.setdiff1d(column_names, df.columns)
        if len(invalid_column_names) > 0:
            raise ValueError("At least one of the column names that is trying to be accessed in the dataframe does not"
                             "exist in the original dataframe. Can't replace columns.")

        df.loc[:, column_names] = df_replace

    @staticmethod
    def _convert_column_names(column_names: Optional[Union[str, List[str]]] = None) -> List[str]:
        if column_names is None:
            return []
        if isinstance(column_names, str):
            return [column_names]
        if all(isinstance(column_name, str) for column_name in column_names):
            return column_names
        raise TypeError('column_names needs to be a list of strings')

    @staticmethod
    def _validate_column_names(df: pd.DataFrame,
                               column_names: List[str],
                               input_data_type: InputDataType,
                               feature_scale: Optional[FeatureScale] = None) -> List[str]:

        erroneous_feature_scale_lookup = {FeatureScale.numerical: FeatureScale.categorical,
                                          FeatureScale.categorical: FeatureScale.numerical}

        if len(column_names) == 0:
            valid_columns = df
            if feature_scale is not None:
                valid_columns = select_features_by_scale(features = df, feature_scale = feature_scale)
            column_names = list(valid_columns.columns.values)
        else:
            if input_data_type == InputDataType.np_ndarray:
                raise ValueError("Column names cannot be specified for input data of type np.ndarray. Remove "
                                 "column_names parameter or change input data to pd.DataFrame.")
            if feature_scale is not None:
                column_scales = detect_feature_scales(df.loc[:, column_names])
                erronous_feature_scale = erroneous_feature_scale_lookup[feature_scale]
                if erronous_feature_scale in column_scales:
                    raise ValueError("At least one of the specified columns is " + str(erronous_feature_scale.name) +
                                     ", but class only works for " + str(feature_scale.name) + " columns.")
        return column_names
