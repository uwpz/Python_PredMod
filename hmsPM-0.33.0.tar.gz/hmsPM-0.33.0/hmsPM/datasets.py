"""Example datasets"""

from os.path import dirname, join

import pandas as pd


def _get_dataset_file_path(file_name: str) -> str:
    return join(dirname(__file__), '..', 'hmsPM-datasets', file_name)


def load_dataset(name: str) -> pd.DataFrame:
    """
    Load dataset by name

    Available datasets:
    - titanic
    - ameshousing

    :param name: Dataset name
    :return: pandas data frame with dataset
    """
    dataset_loader = {
        'titanic': load_titanic,
        'ameshousing': load_ameshousing,
    }
    if name not in dataset_loader:
        raise KeyError(f'Unknown dataset {name}. Available datasets are {", ".join(dataset_loader.keys())}.')
    return dataset_loader[name]()


def load_titanic() -> pd.DataFrame:
    """
    Load and return the titanic dataset (classification)

    The titanic dataset is an example binary classification dataset
    used to predict the outcome variable 'survived'.

    =================   ==============
    Target variable           survived
    Classes                          2
    Samples total                 1309
    # of features                   13
    =================   ==============

    :return: pandas data frame with titanic dataset
    """
    file_path = _get_dataset_file_path('titanic.csv')
    return pd.read_csv(file_path)


def load_ameshousing() -> pd.DataFrame:
    """
    Load and return the ameshousing dataset (regression)

    The ameshousing dataset is an example regression dataset
    used to predict the outcome variable 'SalePrice'.

    =================   ==============
    Target variable          SalePrice
    Samples total                 2930
    # of features                   81
    =================   ==============

    :return: pandas data frame with ameshousing dataset
    """
    file_path = _get_dataset_file_path('ameshousing.csv')
    return pd.read_csv(file_path)
