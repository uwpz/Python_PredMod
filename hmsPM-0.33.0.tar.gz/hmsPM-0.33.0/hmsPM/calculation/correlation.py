"""Correlation calculators"""

from typing import Union, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import fcluster, ward
from scipy.stats import chi2_contingency

from hmsPM.calculation.base import ICorrelationMatrixCalculator
from hmsPM.datatypes import (
    CorrelationType,
    CorrelationTypeCategorical,
    CorrelationTypeNumerical,
    FeatureScale,
)
from hmsPM.utils import FeatureCatalog


def cluster_matrix(matrix: pd.DataFrame, n_cluster: int) -> pd.DataFrame:
    new_order = matrix.columns.values[
        fcluster(ward(1 - np.triu(matrix)), n_cluster, criterion='maxclust').argsort()]
    matrix = matrix.loc[new_order, new_order]
    return matrix


def filter_matrix(matrix: pd.DataFrame, cutoff: float) -> pd.DataFrame:
    i_above_cutoff = (matrix.max(axis=1) > cutoff).values
    matrix = matrix.loc[i_above_cutoff, i_above_cutoff]
    np.fill_diagonal(matrix.values, 1)
    return matrix


def subtract_identity_matrix(matrix: pd.DataFrame,
                             row_and_col_names: dict) -> pd.DataFrame:
    number_of_features = matrix.shape[0]
    idenity_matrix = pd.DataFrame(np.identity(number_of_features),
                                  columns=row_and_col_names, index=row_and_col_names)
    idenity_matrix.rename(columns=row_and_col_names, index=row_and_col_names, inplace=True)
    hollow_matrix = matrix.subtract(idenity_matrix)
    return hollow_matrix


class CorrelationMatrixCalculatorCategorical(ICorrelationMatrixCalculator):

    def __init__(self,
                 corr_type: Union[CorrelationTypeCategorical, str] = 'contingency',
                 cutoff: float = 0,
                 n_cluster: int = 5):
        super().__init__(corr_type=corr_type,
                         cutoff=cutoff,
                         n_cluster=n_cluster)
        self.corr_type: CorrelationTypeCategorical = CorrelationTypeCategorical(corr_type)

    def create_matrix(self, features: pd.DataFrame) -> Tuple[pd.DataFrame, CorrelationTypeCategorical]:
        """
        Create correlation matrix for given categorical features using correlation type 'contingency' or 'cramersv'.

        :param features: Pandas dataframe with categorical features
        :return: Pandas dataframe of correlation matrix
        """
        matrix = self._calculate_correlation_matrix_categorical(features = features, corr_type = self.corr_type)

        # Create row and column names
        number_of_feature_levels = self._get_number_of_levels(features[matrix.columns.values])
        name_mappings = self._create_matrix_names_mappings(matrix, number_of_feature_levels)
        matrix.rename(columns = name_mappings, index = name_mappings, inplace = True)

        matrix = filter_matrix(matrix=matrix, cutoff=self.cutoff)
        matrix = cluster_matrix(matrix=matrix, n_cluster=self.n_cluster)

        return matrix, self.corr_type

    @staticmethod
    def _calculate_correlation_matrix_categorical(features: pd.DataFrame, corr_type: CorrelationTypeCategorical):
        feature_names = pd.Series(features.columns)
        number_of_features = len(feature_names)
        matrix = pd.DataFrame(np.zeros([number_of_features, number_of_features]),
                              index=feature_names, columns=feature_names)
        for i in range(number_of_features):
            for j in range(i + 1, number_of_features):
                frequencies = pd.crosstab(features.iloc[:, i], features.iloc[:, j])
                n = np.sum(frequencies.values)
                m = min(frequencies.shape)
                chi2 = chi2_contingency(frequencies)[0]

                if corr_type == CorrelationTypeCategorical.contingency:
                    matrix.iloc[i, j] = round(np.sqrt(chi2 / (n + chi2)) * np.sqrt(m / (m - 1)), 6)
                elif corr_type == CorrelationTypeCategorical.cramersv:
                    matrix.iloc[i, j] = round(np.sqrt(chi2 / (n * (m - 1))), 6)

                matrix.iloc[j, i] = matrix.iloc[i, j]
        return matrix

    @staticmethod
    def _get_number_of_levels(df: pd.DataFrame) -> np.array:
        number_of_feature_levels = df.nunique().astype("str").values
        return number_of_feature_levels

    @staticmethod
    def _create_matrix_names_mappings(matrix: pd.DataFrame, number_of_feature_levels: np.array) -> dict:
        new_column_names = matrix.columns.values + " (" + number_of_feature_levels + ")"
        name_mappings = dict(zip(matrix.columns.values, new_column_names))
        return name_mappings


class CorrelationMatrixCalculatorNumerical(ICorrelationMatrixCalculator):

    def __init__(self,
                 corr_type: Union[CorrelationTypeNumerical, str] = 'spearman',
                 cutoff: float = 0,
                 n_cluster: int = 5):
        super().__init__(corr_type=corr_type,
                         cutoff=cutoff,
                         n_cluster=n_cluster)
        self.corr_type: CorrelationTypeNumerical = CorrelationTypeNumerical(corr_type)

    def create_matrix(self, features: pd.DataFrame) -> Tuple[pd.DataFrame, CorrelationTypeNumerical]:
        """
        Create correlation matrix for given numerical features using correlation type 'spearman' or 'pearson'.

        :param features: Pandas dataframe with numerical features
        :return: Pandas dataframe of correlation matrix
        """
        matrix = self._calculate_correlation_matrix_numerical(features = features, corr_type = self.corr_type)

        # Create row and column names
        proportion_of_missings = self._get_missing_ratio(features = features[matrix.columns.values])
        name_mappings = self._create_matrix_names_mappings(matrix, proportion_of_missings)
        matrix.rename(columns = name_mappings, index = name_mappings, inplace = True)

        # create hollow matrix to allow filtering
        matrix = subtract_identity_matrix(matrix=matrix,
                                          row_and_col_names=name_mappings)

        matrix = filter_matrix(matrix=matrix, cutoff=self.cutoff)
        matrix = cluster_matrix(matrix=matrix, n_cluster=self.n_cluster)

        return matrix, self.corr_type

    @staticmethod
    def _calculate_correlation_matrix_numerical(features: pd.DataFrame, corr_type: CorrelationTypeNumerical):
        matrix = round(abs(features.corr(method=corr_type.value)), 6)
        return matrix

    @staticmethod
    def _get_missing_ratio(features: pd.DataFrame) -> np.array:
        proportion_of_missings = features.isnull().mean()
        return proportion_of_missings

    @staticmethod
    def _create_matrix_names_mappings(matrix: pd.DataFrame, proportion_of_missings: np.array) -> dict:
        new_column_names = (matrix.columns.values + " (NA: " +
                            (proportion_of_missings * 100).round(1).astype("str").values + "%)")
        name_mappings = dict(zip(matrix.columns.values, new_column_names))
        return name_mappings


class CorrelationMatrixCalculator(FeatureCatalog):
    """
    Creates a correlation matrix for input features.

    The appropriate correlation type is automatically chosen based on the feature scale. Alternatively, the
    correlation type can be specified by the user using the :attr:`corr_type_categorical` parameter (for categorical
    features) or the :attr:`corr_type_numerical` parameter (for numerical features).

    :param corr_type_categorical: Correlation type for categorical features:
        'contingency', 'cramersv' - default = 'contingency';
    :param corr_type_numerical: Correlation type for numerical features:
        'spearman', 'pearson' - default = 'spearman'
    :param cutoff: Cutoff threshold for features to be included in correlation plot; default = 0
    :param n_cluster: Number of clusters for reordering of correlation matrix; default = 5
    """

    def __init__(self,
                 corr_type_categorical: Union[CorrelationTypeCategorical, str] = 'contingency',
                 corr_type_numerical: Union[CorrelationTypeNumerical, str] = 'spearman',
                 cutoff: float = 0,
                 n_cluster: int = 5):
        super().__init__()

        self.calculator_categorical = CorrelationMatrixCalculatorCategorical(corr_type=corr_type_categorical)
        self.calculator_numerical = CorrelationMatrixCalculatorNumerical(corr_type=corr_type_numerical)

        self.cutoff = cutoff
        self.n_cluster = n_cluster

    @property
    def cutoff(self):
        return self._cutoff

    @cutoff.setter
    def cutoff(self, cutoff: float):
        self._cutoff = cutoff
        self.calculator_categorical.cutoff = cutoff
        self.calculator_numerical.cutoff = cutoff

    @property
    def n_cluster(self):
        return self._n_cluster

    @n_cluster.setter
    def n_cluster(self, n_cluster: int):
        self._n_cluster = n_cluster
        self.calculator_categorical.n_cluster = n_cluster
        self.calculator_numerical.n_cluster = n_cluster

    @property
    def corr_type_categorical(self):
        return self.calculator_categorical.corr_type

    @corr_type_categorical.setter
    def corr_type_categorical(self, corr_type: Union[CorrelationTypeCategorical, str]):
        self.calculator_categorical.corr_type = CorrelationTypeCategorical(corr_type)

    @property
    def corr_type_numerical(self):
        return self.calculator_numerical.corr_type

    @corr_type_numerical.setter
    def corr_type_numerical(self, corr_type: Union[CorrelationTypeNumerical, str]):
        self.calculator_numerical.corr_type = CorrelationTypeNumerical(corr_type)

    def create_matrix(
            self,
            features: pd.DataFrame,
            feature_scale: Optional[Union[FeatureScale, str]] = None) -> Tuple[pd.DataFrame, CorrelationType]:
        """
        Create correlation matrix appropriate for feature scale.

        :param features: Pandas dataframe with feature variables
        :param feature_scale: Feature scale ('numerical' or 'categorical') which is used to create correct correlation
            plot when input features have mixed feature scales; default = None
        :return: Pandas dataframe
        """
        calculation_method = self._select_case(features=features, feature_scale=feature_scale)
        return calculation_method(features=features)

    # Implementation of feature catalog functions ######################

    def _categorical_feature(self):
        return self.calculator_categorical.create_matrix

    def _numerical_feature(self):
        return self.calculator_numerical.create_matrix
