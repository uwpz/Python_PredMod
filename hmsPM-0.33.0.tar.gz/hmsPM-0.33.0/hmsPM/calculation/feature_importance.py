"""Feature importance calculators"""

import warnings
from typing import Optional, Union

import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.metrics import roc_auc_score

from hmsPM.calculation.base import IUnivariateFeatureImportanceCalculator
from hmsPM.datatypes import TargetType
from hmsPM.preprocessing import (
    encode_to_numerical_target,
    Imputer,
    QuantileBinner,
    remove_na,
    ScaleConverter,
)
from hmsPM.utils import FeatureTargetCatalog


###############################################################################
# Univariate feature importance


class UnivariateFeatureImportanceCalculatorMixin:

    @staticmethod
    def _format_variable_importance(feature_name: str,
                                    varimp: float,
                                    n_digits: int):
        varimp_formatted = pd.Series({feature_name: round(varimp, n_digits)})
        return varimp_formatted


class CategoricalCalculatorMixin:

    @staticmethod
    def _create_target_scores(feature: pd.Series,
                              target: pd.Series) -> pd.Series:
        y_score = target.groupby(feature).transform("mean")
        return y_score


class NumericalCalculatorMixin:

    @staticmethod
    def _bin_numerical_features(feature: pd.Series, n_bins: int) -> pd.Series:
        binned_numerical_feature = (QuantileBinner(n_bins=n_bins, output_format="intervals")
                                    .fit_transform(feature))
        return binned_numerical_feature


class ClassificationCalculatorMixin:

    @staticmethod
    def _calculate_feature_importance(y_true: pd.Series,
                                      y_score: Union[pd.Series, pd.DataFrame]) -> float:
        varimp = roc_auc_score(y_true, y_score)
        return varimp

    @staticmethod
    def _ensure_classification_numerical_target(target: pd.Series) -> pd.Series:
        is_numerical_target = np.issubdtype(target.dtype, np.number)
        if not is_numerical_target:
            target = encode_to_numerical_target(target)
            warnings.warn("Detected string classification target. Encoded as binary classification target with "
                          "minority class assumed to be the target class (minority class = 1).",
                          UserWarning)
        return target


class MulticlassCalculatorMixin:

    @staticmethod
    def _calculate_feature_importance(y_true: pd.Series,
                                      y_score: Union[pd.Series, pd.DataFrame]) -> float:
        varimp = roc_auc_score(y_true, y_score)
        return varimp

    @staticmethod
    def _ensure_string_target(target: pd.Series) -> pd.Series:
        is_numerical_target = np.issubdtype(target.dtype, np.number)
        if is_numerical_target:
            target = (ScaleConverter(column_names=[str(target.name)], scale="categorical")
                      .fit_transform(pd.DataFrame(target))).iloc[:, 0]
        return target

    @staticmethod
    def _create_target_scores(feature: pd.Series,
                              target: pd.Series,
                              y_true: pd.Series) -> pd.DataFrame:
        frequencies = pd.crosstab(feature, target)
        target_frequencies = frequencies.sum(axis=1)
        feature_proportions_by_target = frequencies.div(target_frequencies, axis=0)
        y_score = (
            pd.DataFrame(feature)
              .reset_index()
              .merge(feature_proportions_by_target.reset_index(), how="inner")
              .sort_values("index")
              .reset_index(drop=True)[y_true.columns.values])
        return y_score

    @staticmethod
    def _create_dummy_variables(target: pd.Series) -> pd.Series:
        dummy_variables = target.str.get_dummies()
        return dummy_variables


class RegressionCalculatorMixin:

    @staticmethod
    def _calculate_feature_importance(y_true: pd.Series,
                                      y_score: pd.Series) -> float:
        varimp = (abs(pd.DataFrame({"y_true": y_true, "y_score": y_score})
                      .corr(method="spearman")
                      .values[0, 1]))
        return varimp


class UnivariateFeatureImportanceCalculatorCategoricalClassification(IUnivariateFeatureImportanceCalculator,
                                                                     UnivariateFeatureImportanceCalculatorMixin,
                                                                     CategoricalCalculatorMixin,
                                                                     ClassificationCalculatorMixin):

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        if self.imputer:
            feature = self.imputer.fit_transform(feature)
        feature, target = remove_na(x=feature, y=target)
        y_true = self._ensure_classification_numerical_target(target)
        y_score = self._create_target_scores(feature=feature, target=y_true)
        varimp = self._calculate_feature_importance(y_true = y_true,
                                                    y_score = y_score)
        varimp_formatted = self._format_variable_importance(feature_name=str(feature.name),
                                                            varimp=varimp,
                                                            n_digits=self.n_digits)
        return varimp_formatted


class UnivariateFeatureImportanceCalculatorCategoricalMulticlass(IUnivariateFeatureImportanceCalculator,
                                                                 UnivariateFeatureImportanceCalculatorMixin,
                                                                 MulticlassCalculatorMixin):

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        if self.imputer:
            feature = self.imputer.fit_transform(feature)
        feature, target = remove_na(x=feature, y=target)
        target = self._ensure_string_target(target=target)
        y_true = self._create_dummy_variables(target=target)
        y_score = self._create_target_scores(feature=feature,
                                             target=target,
                                             y_true=y_true)
        varimp = self._calculate_feature_importance(y_true = y_true,
                                                    y_score = y_score)
        varimp_formatted = self._format_variable_importance(feature_name=str(feature.name),
                                                            varimp=varimp,
                                                            n_digits=self.n_digits)
        return varimp_formatted


class UnivariateFeatureImportanceCalculatorCategoricalRegression(IUnivariateFeatureImportanceCalculator,
                                                                 UnivariateFeatureImportanceCalculatorMixin,
                                                                 CategoricalCalculatorMixin,
                                                                 RegressionCalculatorMixin):

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        if self.imputer:
            feature = self.imputer.fit_transform(feature)
        feature, target = remove_na(x=feature, y=target)
        y_true = target
        y_score = self._create_target_scores(feature=feature, target=target)
        varimp = self._calculate_feature_importance(y_true=y_true, y_score=y_score)
        varimp_formatted = self._format_variable_importance(feature_name=str(feature.name),
                                                            varimp=varimp,
                                                            n_digits=self.n_digits)
        return varimp_formatted


class UnivariateFeatureImportanceCalculatorNumericalClassification(IUnivariateFeatureImportanceCalculator,
                                                                   UnivariateFeatureImportanceCalculatorMixin,
                                                                   NumericalCalculatorMixin,
                                                                   CategoricalCalculatorMixin,
                                                                   ClassificationCalculatorMixin):

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        if self.imputer:
            feature = self.imputer.fit_transform(feature)
        feature, target = remove_na(x=feature, y=target)
        binned_numerical_feature = self._bin_numerical_features(feature=feature, n_bins=self.n_bins)
        y_true = self._ensure_classification_numerical_target(target)
        y_score = self._create_target_scores(target=y_true,
                                             feature=binned_numerical_feature)
        varimp = self._calculate_feature_importance(y_true = y_true,
                                                    y_score = y_score)
        varimp_formatted = self._format_variable_importance(feature_name=str(feature.name),
                                                            varimp=varimp,
                                                            n_digits=self.n_digits)
        return varimp_formatted


class UnivariateFeatureImportanceCalculatorNumericalMulticlass(IUnivariateFeatureImportanceCalculator,
                                                               UnivariateFeatureImportanceCalculatorMixin,
                                                               NumericalCalculatorMixin,
                                                               MulticlassCalculatorMixin):

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        if self.imputer:
            feature = self.imputer.fit_transform(feature)
        feature, target = remove_na(x=feature, y=target)
        target = self._ensure_string_target(target=target)
        binned_numerical_feature = self._bin_numerical_features(feature=feature, n_bins=self.n_bins)
        y_true = self._create_dummy_variables(target=target)
        y_score = self._create_target_scores(feature=binned_numerical_feature,
                                             target=target,
                                             y_true=y_true)
        varimp = self._calculate_feature_importance(y_true = y_true,
                                                    y_score = y_score)
        varimp_formatted = self._format_variable_importance(feature_name=str(feature.name),
                                                            varimp=varimp,
                                                            n_digits=self.n_digits)
        return varimp_formatted


class UnivariateFeatureImportanceCalculatorNumericalRegression(IUnivariateFeatureImportanceCalculator,
                                                               UnivariateFeatureImportanceCalculatorMixin,
                                                               RegressionCalculatorMixin):

    def calculate(self, feature: pd.Series, target: pd.Series) -> pd.Series:
        if self.imputer:
            feature = self.imputer.fit_transform(feature)
        y_score, y_true = remove_na(x=feature, y=target)
        varimp = self._calculate_feature_importance(y_true=y_true, y_score=y_score)
        varimp_formatted = self._format_variable_importance(feature_name=str(feature.name),
                                                            varimp=varimp,
                                                            n_digits=self.n_digits)
        return varimp_formatted


class UnivariateFeatureImportanceCalculator(FeatureTargetCatalog):
    """
    Calculates univariate feature importance for given feature(s) against target.

    To calculate the feature importance(s) this class automatically detects feature scale and target type and
    utilises the appropriate calculation function.

    :param n_bins: Number of bins created for numerical variables before univariate calculation is done by
        calculating the prediction as the average target value per bin
    :param n_digits: Number of digits to which variable importance is rounded
    :param impute_missings: Impute missing values before calculating the univariate feature importance
    """
    def __init__(self,
                 n_bins: int = 10,
                 n_digits: int = 3,
                 impute_missings: bool = True):
        super().__init__()

        self.calculator_categorical_classification = UnivariateFeatureImportanceCalculatorCategoricalClassification()
        self.calculator_categorical_multiclass = UnivariateFeatureImportanceCalculatorCategoricalMulticlass()
        self.calculator_categorical_regression = UnivariateFeatureImportanceCalculatorCategoricalRegression()
        self.calculator_numerical_classification = UnivariateFeatureImportanceCalculatorNumericalClassification()
        self.calculator_numerical_multiclass = UnivariateFeatureImportanceCalculatorNumericalMulticlass()
        self.calculator_numerical_regression = UnivariateFeatureImportanceCalculatorNumericalRegression()

        self.n_bins = n_bins
        self.n_digits = n_digits
        self.impute_missings = impute_missings

    @property
    def n_bins(self):
        return self._n_bins

    @n_bins.setter
    def n_bins(self, n_bins: int):
        self._n_bins = n_bins
        self.calculator_numerical_classification.n_bins = n_bins
        self.calculator_numerical_multiclass.n_bins = n_bins

    @property
    def n_digits(self):
        return self._n_digits

    @n_digits.setter
    def n_digits(self, n_digits: int):
        self._n_digits = n_digits
        self.calculator_categorical_classification.n_digits = n_digits
        self.calculator_categorical_multiclass.n_digits = n_digits
        self.calculator_categorical_regression.n_digits = n_digits
        self.calculator_numerical_classification.n_digits = n_digits
        self.calculator_numerical_multiclass.n_digits = n_digits
        self.calculator_numerical_regression.n_digits = n_digits

    @property
    def impute_missings(self):
        return self._impute_missings

    @impute_missings.setter
    def impute_missings(self, impute_missings: bool):
        self._impute_missings = impute_missings
        if impute_missings is False:
            self.calculator_categorical_classification.imputer = None
            self.calculator_categorical_multiclass.imputer = None
            self.calculator_categorical_regression.imputer = None
            self.calculator_numerical_classification.imputer = None
            self.calculator_numerical_multiclass.imputer = None
            self.calculator_numerical_regression.imputer = None
        else:
            self.calculator_categorical_classification.imputer = Imputer(strategy='constant')
            self.calculator_categorical_multiclass.imputer = Imputer(strategy='constant')
            self.calculator_categorical_regression.imputer = Imputer(strategy='constant')
            self.calculator_numerical_classification.imputer = Imputer(strategy='mean')
            self.calculator_numerical_multiclass.imputer = Imputer(strategy='mean')
            self.calculator_numerical_regression.imputer = Imputer(strategy='mean')

    def calculate(self,
                  features: Union[pd.Series, pd.DataFrame, np.ndarray],
                  target: Union[pd.Series, np.ndarray],
                  target_type: Optional[Union[TargetType, str]] = None) -> pd.Series:
        """
        Perform calculation of variable importances for each feature in features.

        :param features: Pandas dataframe or series with feature(s) for which variable importance is calculated
        :param target: Pandas series of target variable
        :param target_type: Target type ('multiclass', 'classification', or 'regression') which overwrites target type
            detected from 'target' param; default = None
        :return: Pandas series with variable importances with an entry for the value of each feature in features
        """
        if isinstance(features, pd.Series) or isinstance(features, np.ndarray):
            features = pd.DataFrame(features)
        if isinstance(target, np.ndarray):
            target = pd.Series(target)

        if features.isnull().values.any() and self.impute_missings:
            warnings.warn(
                "At least one of the input features has missing values. Missing values will automatically be imputed.",
                UserWarning)

        varimps = pd.Series(dtype=float)
        for _, feature in features.items():
            # TODO Raise warning about string classification target only once
            varimp_calculator = self._select_case(feature=feature, target=target, target_type=target_type)
            varimp = varimp_calculator.calculate(feature=feature, target=target)
            varimps = varimps.append(varimp)
        varimps.sort_values(ascending = False, inplace = True)
        return varimps

    # Implementation of feature-target catalog functions ######################

    def _categorical_feature_classification_target(self):
        return self.calculator_categorical_classification

    def _categorical_feature_multiclass_target(self):
        return self.calculator_categorical_multiclass

    def _categorical_feature_regression_target(self):
        return self.calculator_categorical_regression

    def _numerical_feature_classification_target(self):
        return self.calculator_numerical_classification

    def _numerical_feature_multiclass_target(self):
        return self.calculator_numerical_multiclass

    def _numerical_feature_regression_target(self):
        return self.calculator_numerical_regression


###############################################################################
# Feature importance by permutation


def calculate_feature_importance_by_permutation(features: Union[pd.Series, pd.DataFrame],
                                                target: pd.Series,
                                                fit: object,
                                                scoring: Optional[str] = None,
                                                random_seed: int = 999,
                                                n_repeats: int = 5,
                                                n_jobs: Optional[int] = None) -> pd.DataFrame:
    """
    Calculate permutation importance for feature evaluation.

    This function uses the scikit-learn `permutation_importance` and converts the array output into a pandas dataframe.

    The parameters are the same as those accepted by `permutation_importance`. For more details on the parameters and
    functionality, refer to the scikit-learn
    `permutation importance documentation
    <https://scikit-learn.org/stable/modules/generated/sklearn.inspection.permutation_importance.html>`_.

    To evaluate the difference in the model performance, the function uses the default scorer of the estimator passed
    to the :attr:`fit` parameter. Alternatively, the :attr:`scoring` parameter can be used to specify a different
    scorer. Refer to the scikit-learn `scoring parameter documentation
    <https://scikit-learn.org/stable/modules/model_evaluation.html#scoring-parameter>`_ for a full list of the possible
    scorers.

    :param target: Pandas series with target values
    :param features: Pandas series or pandas dataframe with feature column(s)
    :param fit: An estimator that has already been fitted and is compatible with :attr:`scoring`
    :param scoring: Scorer to use. It can be a single string  or a callable. If None, the estimator’s default scorer
        is used.
    :param random_seed: Pseudo-random number generator to control the permutations of each feature. Pass an int to get
        reproducible results across function calls.
    :param n_repeats: Number of times to permute a feature - default = ``5``
    :param n_jobs: The number of jobs to use for the computation. ``None`` means 1, -1 means using all processors.
        See `scikit-learn glossary <https://scikit-learn.org/stable/glossary.html#term-n-jobs>`_ for more details -
        default = ``None``
    :return: Pandas dataframe with variable importances
    """

    varimps = permutation_importance(estimator=fit,
                                     X=features,
                                     y=target,
                                     scoring=scoring,
                                     n_repeats=n_repeats,
                                     random_state=random_seed,
                                     n_jobs=n_jobs)

    # Create df of performance differences and calculate importance
    df_varimps = (pd.DataFrame({"feature": features.columns,
                                "performance_difference": np.maximum(0, varimps['importances_mean'])})
                  .sort_values(["performance_difference"], ascending = False).reset_index(drop = False)
                  .assign(importance = lambda x: (100 * x["performance_difference"]
                                                  / max(x["performance_difference"])))
                  .assign(importance_cum = lambda x: (100 * x["performance_difference"].cumsum()
                                                      / sum(x["performance_difference"])))
                  .assign(importance_sumnormed = lambda x: (100 * x["performance_difference"]
                                                            / sum(x["performance_difference"]))))

    return df_varimps
