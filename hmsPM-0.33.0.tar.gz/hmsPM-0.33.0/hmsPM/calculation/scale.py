"""Scaling calculators"""

import numpy as np


def scale_predictions(y_hat: np.ndarray,
                      b_sample: np.ndarray,
                      b_all: np.ndarray) -> np.ndarray:
    """
    Rescale predictions to rewind undersampling

    :param y_hat: Numpy array of predictions
    :param b_sample: Numpy array with proportions of target class in undersampled data
    :param b_all: Numpy array with proportions of target class in original data
    :return: Pandas series or numpy array of rescaled predictions
    """
    y_hat_is_1dim = (y_hat.ndim == 1)

    # convert y_hat to 2-dimensional array with predictions for both classes if y_hat is 1-dimensional
    if y_hat_is_1dim:
        y_hat = np.column_stack((1 - y_hat, y_hat))

    rescaling = (y_hat * b_all) / b_sample
    yhat_rescaled = (rescaling.T / rescaling.sum(axis = 1)).T  # transposing is needed for casting

    if y_hat_is_1dim:
        yhat_rescaled = yhat_rescaled[:, 1]
    return yhat_rescaled
