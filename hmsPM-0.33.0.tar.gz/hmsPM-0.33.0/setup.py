#!/usr/bin/env python

"""The setup script."""

from setuptools import setup, find_packages

with open('README.rst') as readme_file:
    readme = readme_file.read()

with open('HISTORY.rst') as history_file:
    history = history_file.read()

requirements = [
    'category-encoders',
    'imbalanced-learn',
    'joblib',
    'matplotlib>=3.2.1',
    'more-itertools',
    'numpy',
    'pandas',
    'scipy',
    'seaborn<=0.11',
    'sklearn',
    'statsmodels',  # required for plotting with seaborn
    'xlrd',  # required by pandas.read_excel
]

setup_requirements = ['pytest-runner', ]

test_requirements = ['pytest>=3', ]

setup(
    author="Arno Becker",
    author_email='arno.becker@analytical-software.de',
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Natural Language :: English',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
    ],
    description="Toolbox for predictive modelling.",
    install_requires=requirements,
    license="GNU General Public License v3",
    long_description=readme + '\n\n' + history,
    include_package_data=True,
    keywords='hmsPM',
    name='hmsPM',
    packages=find_packages(include=['hmsPM', 'hmsPM.*']),
    setup_requires=setup_requirements,
    test_suite='tests',
    tests_require=test_requirements,
    url='',
    version='0.33.0',
    zip_safe=False,
    package_data={
        'hmsPM': [
            '../hmsPM-datasets/*.csv',
            '../hmsPM-notebooks/data/*.xlsx',
            '../hmsPM-notebooks/*.py',
            '../hmsPM-notebooks/*.ipynb'
        ]
    }
)
